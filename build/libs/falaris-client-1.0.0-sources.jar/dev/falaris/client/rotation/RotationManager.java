package dev.falaris.client.rotation;

import java.util.Optional;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

public final class RotationManager {
    private Rotation target;
    private int remainingTicks;
    private float maxStep = 12.0f;

    public void rotateTo(float yaw, float pitch, int ticks) {
        this.target = new Rotation(yaw, class_3532.method_15363(pitch, -90.0f, 90.0f));
        this.remainingTicks = Math.max(1, ticks);
    }

    public void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null || target == null) {
            return;
        }

        float yawDelta = class_3532.method_15393(target.yaw() - player.method_36454());
        float pitchDelta = target.pitch() - player.method_36455();
        float yawStep = class_3532.method_15363(yawDelta / remainingTicks, -maxStep, maxStep);
        float pitchStep = class_3532.method_15363(pitchDelta / remainingTicks, -maxStep, maxStep);

        player.method_36456(player.method_36454() + yawStep);
        player.method_36457(class_3532.method_15363(player.method_36455() + pitchStep, -90.0f, 90.0f));

        remainingTicks--;
        if (remainingTicks <= 0) {
            target = null;
        }
    }

    public Optional<Rotation> getTarget() {
        return Optional.ofNullable(target);
    }

    public float getMaxStep() {
        return maxStep;
    }

    public void setMaxStep(float maxStep) {
        this.maxStep = Math.max(1.0f, maxStep);
    }
}
