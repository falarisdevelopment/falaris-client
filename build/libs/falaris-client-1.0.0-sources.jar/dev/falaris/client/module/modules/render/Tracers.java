package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class Tracers extends RenderModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum tracer range.", 128.0, 8.0, 256.0));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Trace to players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Trace to hostile mobs.", true));

    public Tracers() {
        super("Tracers", "Draws thin 3D tracer paths toward entities.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        class_243 eyes = client.field_1724.method_33571();
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309) || entity == client.field_1724 || client.field_1724.method_5858(entity) > range.get() * range.get()) {
                continue;
            }
            if (entity instanceof class_1657 && !players.enabled() || entity instanceof class_1588 && !hostiles.enabled()) {
                continue;
            }

            drawSegmentedTracer(context, eyes, entity.method_5829().method_1005(), entity instanceof class_1657
                    ? RenderUtil.Color.rgba(122, 156, 255, 180)
                    : RenderUtil.Color.rgba(255, 92, 122, 180));
        }
    }

    private void drawSegmentedTracer(WorldRenderContext context, class_243 start, class_243 end, RenderUtil.Color color) {
        class_243 delta = end.method_1020(start);
        for (int i = 0; i < 20; i++) {
            class_243 point = start.method_1019(delta.method_1021(i / 20.0));
            RenderUtil.drawBox(context, class_238.method_30048(point, 0.035, 0.035, 0.035), color);
        }
    }
}
