package dev.falaris.client.module.modules.combat;

import dev.falaris.client.rotation.RotationManager;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_746;

final class CombatUtil {
    private CombatUtil() {
    }

    static List<class_1309> livingTargets(class_310 client, double range, boolean players, boolean hostiles, boolean passives, boolean walls) {
        class_746 player = client.field_1724;
        if (player == null || client.field_1687 == null) {
            return List.of();
        }

        class_238 box = player.method_5829().method_1014(range);
        return client.field_1687.method_8390(class_1309.class, box, entity -> isValidTarget(player, entity, range, players, hostiles, passives, walls));
    }

    static Optional<class_1309> bestLivingTarget(class_310 client, double range, boolean players, boolean hostiles, boolean passives, boolean walls, String priority) {
        class_746 player = client.field_1724;
        if (player == null) {
            return Optional.empty();
        }

        Comparator<class_1309> comparator = switch (priority) {
            case "Health" -> Comparator.comparingDouble(class_1309::method_6032);
            case "Angle" -> Comparator.comparingDouble(entity -> angleTo(player, entity.method_33571()));
            default -> Comparator.comparingDouble(player::method_5739);
        };

        return livingTargets(client, range, players, hostiles, passives, walls).stream().min(comparator);
    }

    static List<class_1511> crystals(class_310 client, double range, boolean walls) {
        class_746 player = client.field_1724;
        if (player == null || client.field_1687 == null) {
            return List.of();
        }

        return client.field_1687.method_8390(class_1511.class, player.method_5829().method_1014(range), crystal -> {
            if (!crystal.method_5805() || player.method_5858(crystal) > range * range) {
                return false;
            }
            return walls || player.method_6057(crystal);
        });
    }

    static Optional<class_1511> bestCrystal(class_310 client, double range, boolean walls) {
        class_746 player = client.field_1724;
        if (player == null) {
            return Optional.empty();
        }

        return crystals(client, range, walls).stream().min(Comparator.comparingDouble(player::method_5739));
    }

    static boolean isValidTarget(class_746 player, class_1309 entity, double range, boolean players, boolean hostiles, boolean passives, boolean walls) {
        if (entity == player || !entity.method_5805() || entity.method_31481() || player.method_5858(entity) > range * range) {
            return false;
        }
        if (!walls && !player.method_6057(entity)) {
            return false;
        }
        if (entity instanceof class_1657) {
            return players;
        }
        if (entity instanceof class_1588) {
            return hostiles;
        }
        return passives;
    }

    static float[] rotationsTo(class_746 player, class_243 target) {
        class_243 eyes = player.method_33571();
        double diffX = target.field_1352 - eyes.field_1352;
        double diffY = target.field_1351 - eyes.field_1351;
        double diffZ = target.field_1350 - eyes.field_1350;
        double horizontal = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float) class_3532.method_15338(Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, horizontal));
        return new float[] { yaw, class_3532.method_15363(pitch, -90.0f, 90.0f) };
    }

    static double angleTo(class_746 player, class_243 target) {
        float[] rotations = rotationsTo(player, target);
        float yawDelta = Math.abs(class_3532.method_15393(rotations[0] - player.method_36454()));
        float pitchDelta = Math.abs(rotations[1] - player.method_36455());
        return yawDelta + pitchDelta;
    }

    static void face(RotationManager rotationManager, class_746 player, class_243 target, double speed) {
        float[] rotations = rotationsTo(player, target);
        rotationManager.setMaxStep((float) speed);
        rotationManager.rotateTo(rotations[0], rotations[1], Math.max(1, (int) Math.ceil(20.0 / Math.max(1.0, speed))));
    }

    static void attack(class_310 client, class_1297 entity) {
        if (client.field_1724 == null || client.field_1761 == null) {
            return;
        }

        client.field_1761.method_2918(client.field_1724, entity);
        client.field_1724.method_6104(class_1268.field_5808);
    }

    static int findItem(class_746 player, class_1792 item) {
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = player.method_31548().method_5438(slot);
            if (stack.method_31574(item)) {
                return slot;
            }
        }
        return -1;
    }

    static boolean selectHotbarSlot(class_746 player, int slot) {
        if (slot < 0 || slot > 8) {
            return false;
        }
        player.method_31548().method_61496(slot);
        return true;
    }

    static Optional<class_2338> nearestBlock(class_310 client, class_2248 block, double range) {
        class_746 player = client.field_1724;
        if (player == null || client.field_1687 == null) {
            return Optional.empty();
        }

        class_2338 origin = player.method_24515();
        int radius = class_3532.method_15384(range);
        class_2338 best = null;
        double bestDistance = Double.MAX_VALUE;
        for (class_2338 pos : class_2338.method_25996(origin, radius, radius, radius)) {
            if (!client.field_1687.method_8320(pos).method_27852(block)) {
                continue;
            }
            double distance = player.method_5707(class_243.method_24953(pos));
            if (distance < bestDistance && distance <= range * range) {
                best = pos.method_10062();
                bestDistance = distance;
            }
        }
        return Optional.ofNullable(best);
    }

    static boolean interactBlock(class_310 client, class_2338 pos, class_2350 side) {
        if (client.field_1724 == null || client.field_1761 == null) {
            return false;
        }

        class_243 hit = class_243.method_24953(pos).method_1019(class_243.method_24954(side.method_62675()).method_1021(0.5));
        class_3965 result = new class_3965(hit, side, pos, false);
        client.field_1761.method_2896(client.field_1724, class_1268.field_5808, result);
        client.field_1724.method_6104(class_1268.field_5808);
        return true;
    }

}
