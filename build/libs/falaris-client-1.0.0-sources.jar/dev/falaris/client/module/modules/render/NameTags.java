package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import java.util.ArrayList;
import java.util.List;

public final class NameTags extends RenderModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum nametag render range.", 96.0, 8.0, 256.0));
    private final DoubleSetting scale = setting(new DoubleSetting("Scale", "Base nametag scale.", 0.025, 0.01, 0.08));
    private final BooleanSetting playersOnly = setting(new BooleanSetting("Players Only", "Only show player nametags.", true));
    private final BooleanSetting health = setting(new BooleanSetting("Health", "Show health and absorption.", true));
    private final BooleanSetting armor = setting(new BooleanSetting("Armor", "Show armor slots.", true));
    private final BooleanSetting inventory = setting(new BooleanSetting("Inventory Preview", "Show hotbar inventory preview.", true));
    private final BooleanSetting distance = setting(new BooleanSetting("Distance", "Show distance to entity.", true));

    public NameTags() {
        super("NameTags", "Advanced nametags with health, armor, and inventory preview.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309 living) || entity == client.field_1724 || !entity.method_5805()) {
                continue;
            }
            if (playersOnly.enabled() && !(entity instanceof class_1657)) {
                continue;
            }
            if (client.field_1724.method_5858(entity) > range.get() * range.get()) {
                continue;
            }

            RenderUtil.drawNametag(
                    context,
                    entity,
                    lines(client, living),
                    RenderUtil.Color.rgba(8, 10, 18, 130),
                    0xFFFFFFFF,
                    0.6,
                    scale.get()
            );
        }
    }

    private List<String> lines(class_310 client, class_1309 entity) {
        List<String> lines = new ArrayList<>();
        StringBuilder title = new StringBuilder(entity.method_5477().getString());
        if (distance.enabled() && client.field_1724 != null) {
            title.append(" [").append(Math.round(client.field_1724.method_5739(entity))).append("m]");
        }
        lines.add(title.toString());

        if (health.enabled()) {
            float hp = entity.method_6032() + entity.method_6067();
            lines.add("HP " + Math.round(hp * 10.0f) / 10.0f + " / " + Math.round(entity.method_6063() * 10.0f) / 10.0f);
        }
        if (armor.enabled()) {
            lines.add("Armor "
                    + slot(entity, class_1304.field_6169) + " | "
                    + slot(entity, class_1304.field_6174) + " | "
                    + slot(entity, class_1304.field_6172) + " | "
                    + slot(entity, class_1304.field_6166));
        }
        if (inventory.enabled() && entity instanceof class_1657 player) {
            StringBuilder preview = new StringBuilder("Inv ");
            for (int i = 0; i < 9; i++) {
                class_1799 stack = player.method_31548().method_5438(i);
                if (!stack.method_7960()) {
                    preview.append("[").append(RenderUtil.compactItem(stack)).append("] ");
                }
            }
            lines.add(preview.toString().trim());
        }
        return lines;
    }

    private String slot(class_1309 entity, class_1304 slot) {
        return RenderUtil.compactItem(entity.method_6118(slot));
    }
}
