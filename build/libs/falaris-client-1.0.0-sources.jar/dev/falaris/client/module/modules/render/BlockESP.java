package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.StringSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class BlockESP extends RenderModule {
    private final StringSetting blocks = setting(new StringSetting("Blocks", "Comma-separated block ids to highlight.", "minecraft:diamond_ore,minecraft:deepslate_diamond_ore,minecraft:ancient_debris"));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Block scan range.", 32.0, 4.0, 96.0));

    public BlockESP() {
        super("BlockESP", "Highlights configured blocks nearby.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        Set<class_2248> targets = parseTargets();
        int radius = (int) Math.ceil(range.get());
        class_2338 origin = client.field_1724.method_24515();
        for (class_2338 pos : class_2338.method_25996(origin, radius, radius, radius)) {
            if (client.field_1724.method_5707(pos.method_46558()) > range.get() * range.get()) {
                continue;
            }
            if (targets.contains(client.field_1687.method_8320(pos).method_26204())) {
                RenderUtil.drawBlockBox(context, pos, RenderUtil.Color.rgba(118, 156, 255, 220));
            }
        }
    }

    private Set<class_2248> parseTargets() {
        Set<class_2248> result = new HashSet<>();
        for (String raw : blocks.get().split(",")) {
            String id = raw.trim().toLowerCase(Locale.ROOT);
            if (!id.isEmpty()) {
                class_7923.field_41175.method_17966(class_2960.method_60654(id)).ifPresent(result::add);
            }
        }
        return result;
    }
}
