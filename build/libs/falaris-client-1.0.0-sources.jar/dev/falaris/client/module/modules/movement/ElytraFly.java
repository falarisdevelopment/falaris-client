package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_310;

public final class ElytraFly extends MovementModule {
    private final DoubleSetting speed = setting(new DoubleSetting("Speed", "Forward elytra flight speed.", 1.6, 0.1, 6.0));
    private final DoubleSetting verticalSpeed = setting(new DoubleSetting("Vertical Speed", "Manual climb/drop speed.", 0.6, 0.05, 3.0));
    private final DoubleSetting glide = setting(new DoubleSetting("Glide", "Downward glide when no vertical key is held.", -0.02, -0.2, 0.2));
    private final BooleanSetting autoStart = setting(new BooleanSetting("Auto Start", "Starts fall flying when airborne.", true));
    private final IntegerSetting startDelay = setting(new IntegerSetting("Start Delay", "Ticks between start-flying packets.", 10, 1, 40));
    private final IntegerSetting startJitter = setting(new IntegerSetting("Start Jitter", "Random extra ticks for auto start.", 4, 0, 20));

    public ElytraFly() {
        super("ElytraFly", "Controlled powered movement while using an elytra.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) {
            return;
        }

        if (autoStart.enabled() && !client.field_1724.method_24828() && !client.field_1724.method_6128() && ready(startDelay.get(), startJitter.get())) {
            client.field_1724.field_3944.method_52787(new class_2848(client.field_1724, class_2848.class_2849.field_12982));
        }

        if (!client.field_1724.method_6128()) {
            return;
        }

        class_243 look = client.field_1724.method_5720().method_1029();
        double y = glide.get();
        if (client.field_1690.field_1903.method_1434()) {
            y = verticalSpeed.get();
        } else if (client.field_1690.field_1832.method_1434()) {
            y = -verticalSpeed.get();
        }

        class_243 input = MovementUtil.inputVelocity(client.field_1724, speed.get(), false, client);
        if (input.method_37268() <= 0.0001) {
            input = new class_243(look.field_1352 * speed.get(), 0.0, look.field_1350 * speed.get());
        }

        client.field_1724.method_18800(input.field_1352, y, input.field_1350);
        client.field_1724.field_6017 = 0.0f;
    }
}
