package dev.falaris.client.module.modules.render;

import dev.falaris.client.gui.click.UiColor;
import dev.falaris.client.gui.click.UiRender;
import dev.falaris.client.setting.BooleanSetting;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ArmorHud extends RenderModule {
    private final BooleanSetting background = setting(new BooleanSetting("Background", "Draw a subtle panel behind armor info.", true));

    public ArmorHud() {
        super("ArmorHUD", "Displays armor status and durability on screen.");
    }

    @Override
    protected void onHudRender(class_332 context, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        int x = 20, y = 20;
        int width = 120, height = 4 * 22 + 10;

        if (background.enabled()) {
            UiRender.fillRound(context, x - 10, y - 10, width, height, 6, UiColor.argb(120, 10, 10, 15));
        }

        int armorY = y;
        class_1304[] armorSlots = {class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
        for (class_1304 slot : armorSlots) {
            class_1799 stack = client.field_1724.method_6118(slot);
            if (!stack.method_7960()) {
                context.method_51427(stack, x, armorY);
                context.method_51431(client.field_1772, stack, x, armorY);

                int dur = stack.method_7936() - stack.method_7919();
                context.method_51433(client.field_1772, String.valueOf(dur), x + 20, armorY + 4, 0xFFFFFF, true);
            }
            armorY += 22;
        }
    }
}
