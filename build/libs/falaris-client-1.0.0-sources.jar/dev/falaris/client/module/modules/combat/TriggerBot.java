package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;

public final class TriggerBot extends CombatModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum trigger distance.", 4.5, 1.0, 6.0));
    private final DoubleSetting cps = setting(new DoubleSetting("CPS", "Average attacks per second.", 10.0, 1.0, 20.0));
    private final IntegerSetting jitter = setting(new IntegerSetting("Delay Jitter", "Random extra ticks between attacks.", 2, 0, 8));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Target players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Target hostile mobs.", true));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Target passive mobs.", false));

    public TriggerBot() {
        super("TriggerBot", "Attacks valid entities under the crosshair.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1765 == null || client.field_1765.method_17783() != class_239.class_240.field_1331) {
            return;
        }

        class_3966 hit = (class_3966) client.field_1765;
        if (!(hit.method_17782() instanceof class_1309 target) || !target.method_5805()) {
            return;
        }
        if (client.field_1724.method_5858(target) > range.get() * range.get()) {
            return;
        }
        if (!isAllowed(target)) {
            return;
        }

        int minimumTicks = Math.max(1, (int) Math.round(20.0 / cps.get()));
        if (actionReady(minimumTicks, jitter.get())) {
            CombatUtil.attack(client, target);
        }
    }

    private boolean isAllowed(class_1309 target) {
        if (target instanceof class_1657) {
            return players.enabled();
        }
        if (target instanceof class_1588) {
            return hostiles.enabled();
        }
        return passives.enabled();
    }
}
