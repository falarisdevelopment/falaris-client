package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_310;

public final class AimBot extends CombatModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum lock distance.", 6.0, 1.0, 12.0));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Maximum rotation step per tick.", 14.0, 1.0, 60.0));
    private final ModeSetting priority = setting(new ModeSetting("Priority", "Target sorting mode.", "Angle", "Distance", "Health", "Angle"));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Target players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Target hostile mobs.", true));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Target passive mobs.", false));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Allow targets without line of sight.", false));
    private final BooleanSetting focusBlocks = setting(new BooleanSetting("Focus Blocks", "Aim at the block you are mining.", false));

    public AimBot() {
        super("AimBot", "Smoothly locks view onto the best target.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            return;
        }

        if (focusBlocks.enabled()) {
            net.minecraft.class_2338 breakingPos = null;
            try {
                java.lang.reflect.Field field = client.field_1761.getClass().getDeclaredField("currentBreakingPos");
                field.setAccessible(true);
                breakingPos = (net.minecraft.class_2338) field.get(client.field_1761);
            } catch (Exception ignored) {}

            if (breakingPos == null && client.field_1765 != null && client.field_1765.method_17783() == class_239.class_240.field_1332) {
                breakingPos = ((net.minecraft.class_3965) client.field_1765).method_17777();
            }

            if (breakingPos != null && !client.field_1687.method_8320(breakingPos).method_26215()) {
                CombatUtil.face(rotations(), client.field_1724, breakingPos.method_46558(), rotationSpeed.get());
                return;
            }
        }

        class_1309 target = CombatUtil.bestLivingTarget(
                client,
                range.get(),
                players.enabled(),
                hostiles.enabled(),
                passives.enabled(),
                throughWalls.enabled(),
                priority.get()
        ).orElse(null);

        if (target != null) {
            CombatUtil.face(rotations(), client.field_1724, target.method_33571(), rotationSpeed.get());
        }
    }
}
