package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2611;
import net.minecraft.class_2627;
import net.minecraft.class_310;
import net.minecraft.class_3719;

public final class StorageESP extends RenderModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum storage render range.", 96.0, 8.0, 256.0));
    private final BooleanSetting chests = setting(new BooleanSetting("Chests", "Highlight chests.", true));
    private final BooleanSetting barrels = setting(new BooleanSetting("Barrels", "Highlight barrels.", true));
    private final BooleanSetting shulkers = setting(new BooleanSetting("Shulkers", "Highlight shulker boxes.", true));
    private final BooleanSetting enderChests = setting(new BooleanSetting("Ender Chests", "Highlight ender chests.", true));

    public StorageESP() {
        super("StorageESP", "Highlights storage block entities.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        for (class_2586 blockEntity : client.field_1687.method_72019()) {
            if (client.field_1724.method_5707(blockEntity.method_11016().method_46558()) > range.get() * range.get()) {
                continue;
            }
            RenderUtil.Color color = color(blockEntity);
            if (color != null) {
                RenderUtil.drawBlockBox(context, blockEntity.method_11016(), color);
            }
        }
    }

    private RenderUtil.Color color(class_2586 entity) {
        if (entity instanceof class_2595 && chests.enabled()) {
            return RenderUtil.Color.rgba(255, 190, 80, 220);
        }
        if (entity instanceof class_3719 && barrels.enabled()) {
            return RenderUtil.Color.rgba(180, 132, 88, 220);
        }
        if (entity instanceof class_2627 && shulkers.enabled()) {
            return RenderUtil.Color.rgba(178, 112, 255, 220);
        }
        if (entity instanceof class_2611 && enderChests.enabled()) {
            return RenderUtil.Color.rgba(95, 220, 255, 220);
        }
        return null;
    }
}
