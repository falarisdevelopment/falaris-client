package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class CrystalAura extends CombatModule {
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Maximum target distance.", 8.0, 1.0, 12.0));
    private final DoubleSetting breakRange = setting(new DoubleSetting("Break Range", "Maximum crystal break distance.", 5.0, 1.0, 6.0));
    private final DoubleSetting placeRange = setting(new DoubleSetting("Place Range", "Maximum crystal place distance.", 4.5, 1.0, 6.0));
    private final DoubleSetting minDamage = setting(new DoubleSetting("Min Damage", "Minimum estimated target damage.", 6.0, 1.0, 20.0));
    private final DoubleSetting maxSelfDamage = setting(new DoubleSetting("Max Self Damage", "Maximum estimated self damage.", 8.0, 1.0, 20.0));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Maximum rotation step per tick.", 20.0, 1.0, 60.0));
    private final IntegerSetting actionJitter = setting(new IntegerSetting("Action Jitter", "Random extra ticks between crystal actions.", 2, 0, 8));
    private final BooleanSetting place = setting(new BooleanSetting("Place", "Place end crystals.", true));
    private final BooleanSetting explode = setting(new BooleanSetting("Break", "Break end crystals.", true));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Face crystal actions.", true));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Allow crystals without line of sight.", false));
    private final ModeSetting priority = setting(new ModeSetting("Priority", "Target sorting mode.", "Distance", "Distance", "Health", "Angle"));

    public CrystalAura() {
        super("CrystalAura", "Places and breaks end crystals near selected targets.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        class_1309 target = CombatUtil.bestLivingTarget(client, targetRange.get(), true, true, false, throughWalls.enabled(), priority.get()).orElse(null);
        if (target == null) {
            return;
        }

        if (explode.enabled() && tryBreak(client)) {
            return;
        }
        if (place.enabled()) {
            tryPlace(client, target);
        }
    }

    private boolean tryBreak(class_310 client) {
        Optional<class_1511> crystal = CombatUtil.bestCrystal(client, breakRange.get(), throughWalls.enabled());
        if (crystal.isEmpty()) {
            return false;
        }

        class_1511 entity = crystal.get();
        if (rotate.enabled()) {
            CombatUtil.face(rotations(), client.field_1724, new net.minecraft.class_243(entity.method_23317(), entity.method_23318(), entity.method_23321()), rotationSpeed.get());
        }

        if (actionReady(2, actionJitter.get())) {
            CombatUtil.attack(client, entity);
            return true;
        }
        return false;
    }

    private void tryPlace(class_310 client, class_1309 target) {
        int slot = CombatUtil.findItem(client.field_1724, class_1802.field_8301);
        if (slot == -1) {
            return;
        }

        Optional<class_2338> best = findBestCrystalBase(client, target);
        if (best.isEmpty()) {
            return;
        }

        class_2338 pos = best.get();
        if (rotate.enabled()) {
            CombatUtil.face(rotations(), client.field_1724, class_243.method_24953(pos.method_10084()), rotationSpeed.get());
        }

        if (actionReady(3, actionJitter.get())) {
            CombatUtil.selectHotbarSlot(client.field_1724, slot);
            CombatUtil.interactBlock(client, pos, class_2350.field_11036);
        }
    }

    private Optional<class_2338> findBestCrystalBase(class_310 client, class_1309 target) {
        int radius = (int) Math.ceil(placeRange.get());
        class_2338 origin = target.method_24515();
        class_2338 best = null;
        double bestDistance = Double.MAX_VALUE;

        for (class_2338 pos : class_2338.method_25996(origin, radius, 3, radius)) {
            class_243 crystalPos = class_243.method_24953(pos.method_10084());
            if (!canPlaceCrystal(client, pos)) {
                continue;
            }
            if (client.field_1724.method_5707(class_243.method_24953(pos)) > placeRange.get() * placeRange.get()) {
                continue;
            }
            if (estimatedDamage(new net.minecraft.class_243(target.method_23317(), target.method_23318(), target.method_23321()), crystalPos) < minDamage.get()) {
                continue;
            }
            if (estimatedDamage(new net.minecraft.class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321()), crystalPos) > maxSelfDamage.get()) {
                continue;
            }

            double distance = target.method_5707(crystalPos);
            if (distance < bestDistance) {
                best = pos.method_10062();
                bestDistance = distance;
            }
        }

        return Optional.ofNullable(best);
    }

    private boolean canPlaceCrystal(class_310 client, class_2338 pos) {
        boolean base = client.field_1687.method_8320(pos).method_27852(class_2246.field_10540) || client.field_1687.method_8320(pos).method_27852(class_2246.field_9987);
        return base && client.field_1687.method_8320(pos.method_10084()).method_26215() && client.field_1687.method_8320(pos.method_10086(2)).method_26215();
    }

    private double estimatedDamage(class_243 target, class_243 crystal) {
        double distance = target.method_1022(crystal);
        return Math.max(0.0, 12.0 - distance * 2.0);
    }
}
