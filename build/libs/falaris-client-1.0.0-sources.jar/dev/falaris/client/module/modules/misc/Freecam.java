package dev.falaris.client.module.modules.misc;

import com.mojang.authlib.GameProfile;
import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_745;

public final class Freecam extends MiscModule {
    private final DoubleSetting speed = setting(new DoubleSetting("Speed", "Freecam horizontal speed.", 0.75, 0.05, 5.0));
    private final DoubleSetting verticalSpeed = setting(new DoubleSetting("Vertical Speed", "Freecam climb/drop speed.", 0.55, 0.05, 3.0));
    private final BooleanSetting freezePlayer = setting(new BooleanSetting("Freeze Player", "Keep the real player motionless while freecam is active.", true));
    private final BooleanSetting copyRotation = setting(new BooleanSetting("Copy Rotation", "Start with the player's current yaw and pitch.", true));

    private class_745 camera;
    private class_1297 previousCamera;

    public Freecam() {
        super("Freecam", "Detaches the camera into a client-only movable viewpoint.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        previousCamera = client.method_1560();
        camera = new class_745(client.field_1687, new GameProfile(UUID.randomUUID(), "FalarisFreecam"));
        camera.method_5719(client.field_1724);
        if (!copyRotation.enabled()) {
            camera.method_36456(0.0f);
            camera.method_36457(0.0f);
        }
        camera.field_5960 = true;
        client.method_1504(camera);
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.method_1504(previousCamera == null ? client.field_1724 : previousCamera);
        }
        camera = null;
        previousCamera = null;
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null || camera == null) {
            return;
        }

        camera.method_36456(client.field_1724.method_36454());
        camera.method_36457(client.field_1724.method_36455());
        class_243 velocity = inputVelocity(client);
        camera.method_33574(new net.minecraft.class_243(camera.method_23317(), camera.method_23318(), camera.method_23321()).method_1019(velocity));
        camera.method_18799(class_243.field_1353);
        camera.field_5960 = true;

        if (freezePlayer.enabled()) {
            client.field_1724.method_18799(class_243.field_1353);
        }
    }

    private class_243 inputVelocity(class_310 client) {
        double forward = client.field_1690.field_1894.method_1434() ? 1.0 : 0.0;
        forward -= client.field_1690.field_1881.method_1434() ? 1.0 : 0.0;
        double strafe = client.field_1690.field_1913.method_1434() ? 1.0 : 0.0;
        strafe -= client.field_1690.field_1849.method_1434() ? 1.0 : 0.0;
        double y = 0.0;
        y += client.field_1690.field_1903.method_1434() ? verticalSpeed.get() : 0.0;
        y -= client.field_1690.field_1832.method_1434() ? verticalSpeed.get() : 0.0;

        if (forward == 0.0 && strafe == 0.0) {
            return new class_243(0.0, y, 0.0);
        }

        double length = Math.sqrt(forward * forward + strafe * strafe);
        forward /= length;
        strafe /= length;
        double yaw = Math.toRadians(camera.method_36454());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        return new class_243((strafe * cos - forward * sin) * speed.get(), y, (forward * cos + strafe * sin) * speed.get());
    }
}
