package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class AutoTotem extends PlayerModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "When to equip a totem.", "Always", "Always", "Low Health", "Fall Risk"));
    private final DoubleSetting health = setting(new DoubleSetting("Health", "Health threshold for low-health mode.", 10.0, 1.0, 20.0));
    private final DoubleSetting fallDistance = setting(new DoubleSetting("Fall Distance", "Fall distance threshold for fall-risk mode.", 8.0, 2.0, 80.0));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between inventory actions.", 2, 1, 20));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks between actions.", 2, 0, 10));
    private final BooleanSetting inventoryOnly = setting(new BooleanSetting("Inventory Only", "Only swap while an inventory container is available.", false));

    public AutoTotem() {
        super("AutoTotem", "Keeps a totem in the offhand based on health and fall risk.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null || InventoryUtil.isTotem(client.field_1724.method_6079()) || !shouldEquip(client)) {
            return;
        }
        if (inventoryOnly.enabled() && client.field_1755 == null) {
            return;
        }
        if (!ready(delay.get(), jitter.get())) {
            return;
        }

        int inventoryIndex = InventoryUtil.findItem(client.field_1724, class_1802.field_8288, false);
        int screenSlot = InventoryUtil.screenSlotForInventoryIndex(inventoryIndex);
        InventoryUtil.clickMove(client, screenSlot, InventoryUtil.OFFHAND_SLOT);
    }

    private boolean shouldEquip(class_310 client) {
        if (mode.is("Always")) {
            return true;
        }
        if (mode.is("Low Health")) {
            return client.field_1724.method_6032() + client.field_1724.method_6067() <= health.get();
        }
        return client.field_1724.field_6017 >= fallDistance.get();
    }
}
