package dev.falaris.client.module.modules.client;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.module.Category;
import dev.falaris.client.module.Module;
import net.minecraft.class_310;
import net.minecraft.class_408;
import org.lwjgl.glfw.GLFW;

public final class ClickGuiModule extends Module {
    public ClickGuiModule() {
        super("Click GUI", "Opens the Falaris ClickGUI.", Category.CLIENT);
        setKeyCode(GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    @Override
    protected void onEnable() {
        class_310 client = class_310.method_1551();
        if (client.field_1755 instanceof class_408) {
            setEnabled(false);
            return;
        }

        FalarisClient.getInstance().openClickGui();
        setEnabled(false);
    }
}
