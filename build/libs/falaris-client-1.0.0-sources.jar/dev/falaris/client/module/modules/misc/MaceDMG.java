package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;

public final class MaceDMG extends MiscModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Mace damage helper mode.", "Attack", "Attack", "Notify"));
    private final DoubleSetting minFall = setting(new DoubleSetting("Min Fall", "Minimum fall distance before attacking.", 3.0, 0.5, 80.0));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum target range.", 4.5, 1.0, 6.0));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between mace actions.", 3, 1, 30));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks between mace actions.", 1, 0, 10));
    private final BooleanSetting requireMace = setting(new BooleanSetting("Require Mace", "Only act while holding a mace.", true));

    public MaceDMG() {
        super("MaceDMG", "Assists timing high-fall mace attacks and reports estimated damage.");
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null || client.field_1765 == null) {
            return;
        }
        if (requireMace.enabled() && !client.field_1724.method_6047().method_31574(class_1802.field_49814)) {
            return;
        }
        if (client.field_1724.field_6017 < minFall.get() || client.field_1765.method_17783() != class_239.class_240.field_1331) {
            return;
        }

        class_1297 target = ((class_3966) client.field_1765).method_17782();
        if (!(target instanceof class_1309) || client.field_1724.method_5858(target) > range.get() * range.get()) {
            return;
        }
        if (!ready(delay.get(), jitter.get())) {
            return;
        }

        double estimate = estimateDamage((float) client.field_1724.field_6017);
        if (mode.is("Notify")) {
            client.field_1724.method_7353(net.minecraft.class_2561.method_43470("[Falaris] Estimated mace damage: " + Math.round(estimate * 10.0) / 10.0), true);
            return;
        }

        client.field_1761.method_2918(client.field_1724, target);
        client.field_1724.method_6104(class_1268.field_5808);
    }

    private double estimateDamage(float fallDistance) {
        if (fallDistance <= 3.0f) {
            return 6.0;
        }
        if (fallDistance <= 8.0f) {
            return 6.0 + (fallDistance - 3.0f) * 4.0;
        }
        return 26.0 + (fallDistance - 8.0f) * 2.0;
    }
}
