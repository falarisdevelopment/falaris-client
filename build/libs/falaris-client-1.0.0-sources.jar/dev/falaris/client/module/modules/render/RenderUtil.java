package dev.falaris.client.module.modules.render;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import java.util.List;

final class RenderUtil {
    private RenderUtil() {
    }

    static void drawBox(WorldRenderContext context, class_238 box, Color color) {
        // 1.21.11 moved low-level world line drawing into the render state pipeline.
        // Keep this as a no-op until a dedicated render pipeline is added.
    }

    static void drawBlockBox(WorldRenderContext context, class_2338 pos, Color color) {
        drawBox(context, new class_238(pos), color);
    }

    static void drawEntityBox(WorldRenderContext context, class_1297 entity, Color color, double expand) {
        drawBox(context, entity.method_5829().method_1014(expand), color);
    }

    static void drawNametag(WorldRenderContext context, class_1297 entity, List<String> lines, Color background, int textColor, double yOffset, double scale) {
        // See drawBox: world-space text now needs an extraction/render state path.
    }

    static String compactItem(net.minecraft.class_1799 stack) {
        if (stack.method_7960()) {
            return "-";
        }
        String name = stack.method_7964().getString();
        return stack.method_7947() > 1 ? name + " x" + stack.method_7947() : name;
    }

    record Color(float red, float green, float blue, float alpha) {
        static Color rgba(int red, int green, int blue, int alpha) {
            return new Color(red / 255.0f, green / 255.0f, blue / 255.0f, alpha / 255.0f);
        }

        int asArgb() {
            int a = Math.round(alpha * 255.0f) & 255;
            int r = Math.round(red * 255.0f) & 255;
            int g = Math.round(green * 255.0f) & 255;
            int b = Math.round(blue * 255.0f) & 255;
            return a << 24 | r << 16 | g << 8 | b;
        }
    }
}
