package dev.falaris.client.module.modules.render;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

import java.util.List;

final class RenderUtil {
    private RenderUtil() {
    }

    static void drawBox(WorldRenderContext context, class_238 box, Color color) {
        class_4587 matrices = context.matrices();
        class_4597 consumers = context.consumers();
        if (consumers == null) return;

        class_310 client = class_310.method_1551();
        class_4184 camera = client.field_1773.method_19418();
        class_243 cam = camera.method_71156();
        double x1 = box.field_1323 - cam.field_1352;
        double y1 = box.field_1322 - cam.field_1351;
        double z1 = box.field_1321 - cam.field_1350;
        double x2 = box.field_1320 - cam.field_1352;
        double y2 = box.field_1325 - cam.field_1351;
        double z2 = box.field_1324 - cam.field_1350;

        class_4588 buffer = consumers.method_73477(class_12249.method_76015());
        class_4587.class_4665 entry = matrices.method_23760();

        // 12 lines of the box
        drawLine(buffer, entry, x1, y1, z1, x2, y1, z1, color);
        drawLine(buffer, entry, x2, y1, z1, x2, y1, z2, color);
        drawLine(buffer, entry, x2, y1, z2, x1, y1, z2, color);
        drawLine(buffer, entry, x1, y1, z2, x1, y1, z1, color);

        drawLine(buffer, entry, x1, y2, z1, x2, y2, z1, color);
        drawLine(buffer, entry, x2, y2, z1, x2, y2, z2, color);
        drawLine(buffer, entry, x2, y2, z2, x1, y2, z2, color);
        drawLine(buffer, entry, x1, y2, z2, x1, y2, z1, color);

        drawLine(buffer, entry, x1, y1, z1, x1, y2, z1, color);
        drawLine(buffer, entry, x2, y1, z1, x2, y2, z1, color);
        drawLine(buffer, entry, x2, y1, z2, x2, y2, z2, color);
        drawLine(buffer, entry, x1, y1, z2, x1, y2, z2, color);
    }

    private static void drawLine(class_4588 buffer, class_4587.class_4665 entry, double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
        buffer.method_75298(1.0f);
        buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_22915(color.red, color.green, color.blue, color.alpha).method_60831(entry, 0, 1, 0);
        buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_22915(color.red, color.green, color.blue, color.alpha).method_60831(entry, 0, 1, 0);
    }

    static void drawBlockBox(WorldRenderContext context, class_2338 pos, Color color) {
        drawBox(context, new class_238(pos), color);
    }

    static void drawEntityBox(WorldRenderContext context, class_1297 entity, Color color, double expand) {
        drawBox(context, entity.method_5829().method_1014(expand), color);
    }

    static void drawNametag(WorldRenderContext context, class_1297 entity, List<String> lines, Color background, int textColor, double yOffset, double scale) {
        class_310 client = class_310.method_1551();
        class_327 textRenderer = client.field_1772;
        class_4587 matrices = context.matrices();
        class_4184 camera = client.field_1773.method_19418();
        class_243 camPos = camera.method_71156();
        
        double x = entity.method_23317() - camPos.field_1352;
        double y = entity.method_23318() - camPos.field_1351 + entity.method_17682() + yOffset;
        double z = entity.method_23321() - camPos.field_1350;

        matrices.method_22903();
        matrices.method_22904(x, y, z);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrices.method_22905((float)-scale, (float)-scale, (float)scale);

        Matrix4f matrix = matrices.method_23760().method_23761();
        class_4597 consumers = context.consumers();
        
        float currentY = 0;
        for (String line : lines) {
            float width = textRenderer.method_1727(line);
            textRenderer.method_27521(line, -width / 2, currentY, textColor, false, matrix, consumers, class_327.class_6415.field_33994, background.asArgb(), 0xF000F0);
            currentY += textRenderer.field_2000 + 1;
        }

        matrices.method_22909();
    }

    static String compactItem(net.minecraft.class_1799 stack) {
        if (stack.method_7960()) {
            return "-";
        }
        String name = stack.method_7964().getString();
        return stack.method_7947() > 1 ? name + " x" + stack.method_7947() : name;
    }

    record Color(float red, float green, float blue, float alpha) {
        static Color rgba(int red, int green, int blue, int alpha) {
            return new Color(red / 255.0f, green / 255.0f, blue / 255.0f, alpha / 255.0f);
        }

        int asArgb() {
            int a = Math.round(alpha * 255.0f) & 255;
            int r = Math.round(red * 255.0f) & 255;
            int g = Math.round(green * 255.0f) & 255;
            int b = Math.round(blue * 255.0f) & 255;
            return a << 24 | r << 16 | g << 8 | b;
        }
    }
}
