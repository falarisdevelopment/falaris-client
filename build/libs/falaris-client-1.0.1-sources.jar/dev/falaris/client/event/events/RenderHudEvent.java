package dev.falaris.client.event.events;

import dev.falaris.client.event.Event;
import net.minecraft.class_332;

public record RenderHudEvent(class_332 context, float tickDelta) implements Event {
}
