package dev.falaris.client.event.events;

import dev.falaris.client.event.Event;
import net.minecraft.class_310;

public record ClientTickEvent(class_310 client) implements Event {
}
