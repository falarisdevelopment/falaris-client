package dev.falaris.client.backtrack;

import java.util.*;
import java.util.stream.Collectors;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_638;

public final class BacktrackManager {
    private static final BacktrackManager INSTANCE = new BacktrackManager();
    private static final int HISTORY_MS = 2000;
    private final Map<Integer, List<TimedPosition>> history = new HashMap<>();
    private long lastCapture;

    public static BacktrackManager getInstance() { return INSTANCE; }

    public void capture(class_638 world) {
        long now = System.currentTimeMillis();
        lastCapture = now;
        for (class_1297 entity : world.method_18112()) {
            class_243 pos = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
            history.computeIfAbsent(entity.method_5628(), k -> new ArrayList<>())
                   .add(new TimedPosition(now, pos, entity.method_36454(), entity.method_36455(), entity.method_5829()));
        }
        long cutoff = now - HISTORY_MS;
        history.values().forEach(list -> list.removeIf(tp -> tp.time < cutoff));
        history.entrySet().removeIf(e -> e.getValue().isEmpty());
    }

    public TimedPosition getBacktracked(int entityId, int delayMs) {
        List<TimedPosition> positions = history.get(entityId);
        if (positions == null || positions.isEmpty()) return null;
        long targetTime = System.currentTimeMillis() - delayMs;
        return positions.stream()
            .min(Comparator.comparingLong(tp -> Math.abs(tp.time - targetTime)))
            .orElse(null);
    }

    public Map<Integer, List<TimedPosition>> getAllHistory() { return history; }

    public static final class TimedPosition {
        public final long time;
        public final class_243 pos;
        public final float yaw;
        public final float pitch;
        public final class_238 box;

        public TimedPosition(long time, class_243 pos, float yaw, float pitch, class_238 box) {
            this.time = time;
            this.pos = pos;
            this.yaw = yaw;
            this.pitch = pitch;
            this.box = box;
        }
    }
}
