package dev.falaris.client.mixin;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.module.Module;
import dev.falaris.client.module.modules.misc.Blink;
import dev.falaris.client.module.modules.misc.FakeLag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2828;

@Mixin(class_2535.class)
public class ClientConnectionMixin {
    @Inject(method = "send", at = @At("HEAD"), cancellable = true)
    private void onSend(class_2596<?> packet, CallbackInfo ci) {
        if (!(packet instanceof class_2828)) return;

        Optional<Module> blink = FalarisClient.getInstance().getModuleManager().find("blink");
        if (blink.isPresent()) {
            Blink b = (Blink) blink.get();
            if (b.shouldHoldPacket()) { b.holdPacket((class_2828) packet); ci.cancel(); return; }
        }

        Optional<Module> fakelag = FalarisClient.getInstance().getModuleManager().find("fakelag");
        if (fakelag.isPresent()) {
            FakeLag f = (FakeLag) fakelag.get();
            if (f.shouldHoldPacket()) { f.holdPacket((class_2828) packet); ci.cancel(); }
        }
    }
}
