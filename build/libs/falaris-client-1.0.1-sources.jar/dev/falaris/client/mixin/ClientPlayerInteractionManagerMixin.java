package dev.falaris.client.mixin;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.module.Module;
import dev.falaris.client.module.modules.combat.Reach;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_636;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {
    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    private void onAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        double reachSq = 36.0;
        Optional<Module> found = FalarisClient.getInstance().getModuleManager().find("reach");
        if (found.isPresent() && found.get().isEnabled()) {
            Reach reach = (Reach) found.get();
            reachSq = reach.getAttackReach() * reach.getAttackReach();
        }
        if (player.method_5858(target) > reachSq) {
            ci.cancel();
        }
    }
}
