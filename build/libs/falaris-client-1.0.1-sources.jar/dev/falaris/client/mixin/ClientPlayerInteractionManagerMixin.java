package dev.falaris.client.mixin;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.module.Module;
import dev.falaris.client.module.modules.render.DamageIndicator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_636;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {
    @Inject(method = "attackEntity", at = @At("TAIL"))
    private void onAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        Optional<Module> found = FalarisClient.getInstance().getModuleManager().find("damage-indicator");
        if (found.isPresent()) {
            DamageIndicator di = (DamageIndicator) found.get();
            di.recordHit(target, 1.0f);
        }
    }
}
