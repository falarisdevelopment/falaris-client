package dev.falaris.client.mixin;

import dev.falaris.client.module.modules.player.NoSlowdown;
import net.minecraft.class_1309;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public class LivingEntityMixin {
    @Inject(method = "travel", at = @At("HEAD"))
    private void onTravelHead(CallbackInfo ci) {
        if (!NoSlowdown.shouldCancelSlowdown()) return;
        //noinspection ConstantValue
        if (!((Object) this instanceof class_746)) return;
        class_746 player = (class_746) (Object) this;
        if (player.method_6115()) {
            // Pre-counter the 0.2x slowdown that travel() will apply
            player.method_18799(player.method_18798().method_18805(5.0, 1.0, 5.0));
        }
    }
}
