package dev.falaris.client.gui.click;

import dev.falaris.client.module.Module;
import dev.falaris.client.module.ModuleManager;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class HudEditorScreen extends class_437 {
    private static final int SNAP_GRID = 5;
    private static final int BOX_W = 120;
    private static final int BOX_H = 24;

    private final ModuleManager moduleManager;
    private final List<HudElement> elements = new ArrayList<>();

    private HudElement dragging;
    private int dragOffX, dragOffY;

    public HudEditorScreen(ModuleManager moduleManager) {
        super(class_2561.method_43470("HUD Editor"));
        this.moduleManager = moduleManager;
        buildElements();
    }

    private void buildElements() {
        elements.clear();
        for (Module mod : moduleManager.getModules()) {
            if (!mod.isEnabled()) continue;
            IntegerSetting xSetting = null;
            IntegerSetting ySetting = null;
            for (Setting<?> s : mod.getSettings()) {
                if (s.getName().equalsIgnoreCase("Offset X") && s instanceof IntegerSetting is) {
                    xSetting = is;
                }
                if (s.getName().equalsIgnoreCase("Offset Y") && s instanceof IntegerSetting is) {
                    ySetting = is;
                }
            }
            if (xSetting != null && ySetting != null) {
                elements.add(new HudElement(mod, xSetting, ySetting));
            }
        }
    }

    @Override
    public void method_25394(class_332 ctx, int mx, int my, float delta) {
        ctx.method_25294(0, 0, field_22789, field_22790, 0x40000000);
        int sw = class_310.method_1551().method_22683().method_4486();
        int sh = class_310.method_1551().method_22683().method_4502();

        // Draw grid
        for (int x = 0; x < sw; x += SNAP_GRID * 10) {
            ctx.method_25294(x, 0, x + 1, sh, 0x15FFFFFF);
        }
        for (int y = 0; y < sh; y += SNAP_GRID * 10) {
            ctx.method_25294(0, y, sw, y + 1, 0x15FFFFFF);
        }

        ctx.method_51433(field_22793, "HUD Editor - Drag boxes to reposition, ESC to exit", 10, 10, 0xFFCCCCCC, false);

        for (HudElement elem : elements) {
            elem.render(ctx, mx, my);
        }
    }

    @Override
    public boolean method_25402(net.minecraft.class_11909 click, boolean doubled) {
        double mx = click.comp_4798(), my = click.comp_4799();
        if (click.method_74245() == 0) {
            for (HudElement elem : elements) {
                if (mx >= elem.x && mx <= elem.x + BOX_W && my >= elem.y && my <= elem.y + BOX_H) {
                    dragging = elem;
                    dragOffX = (int) mx - elem.x;
                    dragOffY = (int) my - elem.y;
                    return true;
                }
            }
        }
        return true;
    }

    @Override
    public boolean method_25403(net.minecraft.class_11909 click, double dx, double dy) {
        if (dragging != null) {
            int nx = (int) click.comp_4798() - dragOffX;
            int ny = (int) click.comp_4799() - dragOffY;
            nx = Math.round(nx / (float) SNAP_GRID) * SNAP_GRID;
            ny = Math.round(ny / (float) SNAP_GRID) * SNAP_GRID;
            dragging.x = Math.max(0, nx);
            dragging.y = Math.max(0, ny);
            dragging.xSetting.set(dragging.x);
            dragging.ySetting.set(dragging.y);
            moduleManager.save();
            return true;
        }
        return true;
    }

    @Override
    public boolean method_25406(net.minecraft.class_11909 click) {
        dragging = null;
        return true;
    }

    @Override
    public boolean method_25421() { return false; }

    @Override
    public void method_25419() {
        dragging = null;
        super.method_25419();
    }

    private static class HudElement {
        final Module mod;
        final IntegerSetting xSetting;
        final IntegerSetting ySetting;
        int x, y;

        HudElement(Module mod, IntegerSetting xSetting, IntegerSetting ySetting) {
            this.mod = mod;
            this.xSetting = xSetting;
            this.ySetting = ySetting;
            this.x = xSetting.get();
            this.y = ySetting.get();
        }

        void render(class_332 ctx, int mx, int my) {
            boolean hovered = mx >= x && mx <= x + BOX_W && my >= y && my <= y + BOX_H;
            int bg = hovered ? 0xFF3A3C4E : 0xFF242632;
            ctx.method_25294(x, y, x + BOX_W, y + BOX_H, bg);
            ctx.method_25294(x, y, x + 3, y + BOX_H, 0xFF54B8B3);
            ctx.method_51433(class_310.method_1551().field_1772, mod.getName(), x + 10, y + (BOX_H - 8) / 2, 0xFFDCE1EB, false);
        }
    }
}
