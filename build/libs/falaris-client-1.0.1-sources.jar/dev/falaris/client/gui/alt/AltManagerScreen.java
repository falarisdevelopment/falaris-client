package dev.falaris.client.gui.alt;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.alt.AltAccount;
import dev.falaris.client.alt.AltManager;
import dev.falaris.client.gui.click.UiColor;
import dev.falaris.client.gui.click.UiRender;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public final class AltManagerScreen extends class_437 {
    private static final int PANEL_WIDTH = 760;
    private static final int PANEL_HEIGHT = 460;
    private static final int ITEM_HEIGHT = 48;
    private static final int ITEM_GAP = 10;
    private static final DateTimeFormatter LAST_USED_FORMAT = DateTimeFormatter.ofPattern("MMM d, HH:mm");

    private final AltManager altManager;
    private List<AltAccount> displayAlts = List.of();
    private AltAccount selectedAlt;

    private class_342 searchField;
    private class_342 usernameField;
    private class_342 uuidField;
    private class_4185 loginButton;
    private class_4185 addButton;
    private class_4185 editButton;
    private class_4185 removeButton;
    private class_4185 randomButton;
    private class_4185 copyButton;
    private class_4185 favoriteButton;

    private int panelX;
    private int panelY;
    private int scrollOffset;
    private String statusMessage = "";
    private long statusExpires;

    public AltManagerScreen(AltManager altManager) {
        super(class_2561.method_43470("Alt Manager"));
        this.altManager = altManager;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        panelX = (field_22789 - PANEL_WIDTH) / 2;
        panelY = (field_22790 - PANEL_HEIGHT) / 2;

        searchField = new class_342(field_22793, panelX + 24, panelY + 40, 360, 18, class_2561.method_43470("Search"));
        searchField.method_1863(value -> refreshList());
        searchField.method_1880(64);
        method_37063(searchField);

        usernameField = new class_342(field_22793, panelX + 24, panelY + PANEL_HEIGHT - 96, 260, 18, class_2561.method_43470("Username"));
        usernameField.method_1880(64);
        method_37063(usernameField);

        uuidField = new class_342(field_22793, panelX + 304, panelY + PANEL_HEIGHT - 96, 260, 18, class_2561.method_43470("UUID (optional)"));
        uuidField.method_1880(64);
        method_37063(uuidField);

        addButton = method_37063(class_4185.method_46430(class_2561.method_43470("Add Alt"), button -> addAlt()).method_46434(panelX + 24, panelY + PANEL_HEIGHT - 62, 110, 20).method_46431());
        editButton = method_37063(class_4185.method_46430(class_2561.method_43470("Edit Alt"), button -> editAlt()).method_46434(panelX + 144, panelY + PANEL_HEIGHT - 62, 110, 20).method_46431());
        removeButton = method_37063(class_4185.method_46430(class_2561.method_43470("Remove"), button -> removeAlt()).method_46434(panelX + 264, panelY + PANEL_HEIGHT - 62, 110, 20).method_46431());
        copyButton = method_37063(class_4185.method_46430(class_2561.method_43470("Copy Name"), button -> copyUsername()).method_46434(panelX + 384, panelY + PANEL_HEIGHT - 62, 110, 20).method_46431());
        favoriteButton = method_37063(class_4185.method_46430(class_2561.method_43470("Favorite"), button -> toggleFavorite()).method_46434(panelX + 504, panelY + PANEL_HEIGHT - 62, 110, 20).method_46431());
        loginButton = method_37063(class_4185.method_46430(class_2561.method_43470("Login Alt"), button -> loginSelectedAlt()).method_46434(panelX + 624, panelY + PANEL_HEIGHT - 62, 110, 20).method_46431());
        randomButton = method_37063(class_4185.method_46430(class_2561.method_43470("Random Alt"), button -> selectRandomAlt()).method_46434(panelX + 624, panelY + PANEL_HEIGHT - 98, 110, 20).method_46431());

        refreshList();
        updateButtons();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);

        UiRender.fillRound(context, panelX, panelY, PANEL_WIDTH, PANEL_HEIGHT, 16, UiColor.argb(225, 18, 12, 37));
        UiRender.fillRound(context, panelX + 1, panelY + 1, PANEL_WIDTH - 2, PANEL_HEIGHT - 2, 15, UiColor.argb(220, 24, 16, 52));
        UiRender.fillRound(context, panelX + 22, panelY + 16, PANEL_WIDTH - 44, 40, 12, UiColor.argb(200, 73, 46, 140));

        context.method_51439(field_22793, class_2561.method_43470("Cracked Alt Manager"), panelX + 30, panelY + 22, UiColor.rgb(248, 248, 255), false);
        context.method_51439(field_22793, class_2561.method_43470("Search, favorite and login cracked accounts right from the title screen."), panelX + 30, panelY + 40, UiColor.rgb(176, 181, 235), false);

        renderList(context, mouseX, mouseY);
        renderDetails(context);

        if (!statusMessage.isEmpty() && System.currentTimeMillis() < statusExpires) {
            context.method_51439(field_22793, class_2561.method_43470(statusMessage), panelX + 24, panelY + PANEL_HEIGHT - 28, UiColor.rgb(187, 203, 255), false);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void renderList(class_332 context, int mouseX, int mouseY) {
        int listX = panelX + 24;
        int listY = panelY + 78;
        int listWidth = 360;
        int listHeight = PANEL_HEIGHT - 194;

        UiRender.fillRound(context, listX, listY, listWidth, listHeight, 12, UiColor.argb(192, 22, 13, 44));
        UiRender.fillRound(context, listX + 1, listY + 1, listWidth - 2, listHeight - 2, 11, UiColor.argb(178, 28, 18, 55));

        int itemY = listY + 8 - scrollOffset;
        for (AltAccount alt : displayAlts) {
            boolean hovered = inside(mouseX, mouseY, listX + 6, itemY, listWidth - 12, ITEM_HEIGHT);
            boolean selected = selectedAlt != null && selectedAlt.getId().equals(alt.getId());
            int background = selected ? UiColor.argb(200, 85, 56, 155) : hovered ? UiColor.argb(140, 38, 23, 88) : UiColor.argb(110, 32, 20, 68);
            UiRender.fillRound(context, listX + 6, itemY, listWidth - 12, ITEM_HEIGHT, 10, background);

            context.method_51439(field_22793, class_2561.method_43470(alt.isFavorite() ? "★ " + alt.getUsername() : alt.getUsername()), listX + 14, itemY + 10, UiColor.rgb(238, 238, 255), false);
            String subtitle = alt.getUuid().isBlank() ? "Cracked" : "UUID: " + alt.getUuid();
            context.method_51439(field_22793, class_2561.method_43470(subtitle), listX + 14, itemY + 24, UiColor.rgb(156, 167, 219), false);

            String lastUsed = alt.getLastUsed() > 0 ? formatLastUsed(alt.getLastUsed()) : "Never used";
            context.method_51439(field_22793, class_2561.method_43470("Last Used: " + lastUsed), listX + 14, itemY + 36, UiColor.rgb(142, 149, 185), false);
            itemY += ITEM_HEIGHT + ITEM_GAP;
        }

        if (displayAlts.isEmpty()) {
            context.method_51439(field_22793, class_2561.method_43470("No alts found."), listX + listWidth / 2 - field_22793.method_1727("No alts found.") / 2, listY + listHeight / 2 - 6, UiColor.rgb(152, 164, 198), false);
        }
    }

    private void renderDetails(class_332 context) {
        int detailsX = panelX + 400;
        int detailsY = panelY + 78;
        int detailsWidth = PANEL_WIDTH - 432;
        int detailsHeight = PANEL_HEIGHT - 194;

        UiRender.fillRound(context, detailsX, detailsY, detailsWidth, detailsHeight, 12, UiColor.argb(192, 24, 15, 50));
        UiRender.fillRound(context, detailsX + 1, detailsY + 1, detailsWidth - 2, detailsHeight - 2, 11, UiColor.argb(178, 30, 18, 60));

        context.method_51439(field_22793, class_2561.method_43470("Selected Alt"), detailsX + 14, detailsY + 14, UiColor.rgb(233, 228, 255), false);

        if (selectedAlt == null) {
            context.method_51439(field_22793, class_2561.method_43470("Choose an alt from the list or add a new one."), detailsX + 14, detailsY + 40, UiColor.rgb(144, 155, 196), false);
            return;
        }

        context.method_51439(field_22793, class_2561.method_43470("Username:"), detailsX + 14, detailsY + 40, UiColor.rgb(209, 209, 255), false);
        context.method_51439(field_22793, class_2561.method_43470(selectedAlt.getUsername()), detailsX + 14, detailsY + 58, UiColor.rgb(236, 237, 255), false);

        context.method_51439(field_22793, class_2561.method_43470("UUID:"), detailsX + 14, detailsY + 84, UiColor.rgb(209, 209, 255), false);
        context.method_51439(field_22793, class_2561.method_43470(selectedAlt.getUuid().isEmpty() ? "None" : selectedAlt.getUuid()), detailsX + 14, detailsY + 102, UiColor.rgb(236, 237, 255), false);

        context.method_51439(field_22793, class_2561.method_43470("Favorite:"), detailsX + 14, detailsY + 128, UiColor.rgb(209, 209, 255), false);
        context.method_51439(field_22793, class_2561.method_43470(selectedAlt.isFavorite() ? "Yes" : "No"), detailsX + 14, detailsY + 146, UiColor.rgb(236, 237, 255), false);

        context.method_51439(field_22793, class_2561.method_43470("Last Used:"), detailsX + 14, detailsY + 172, UiColor.rgb(209, 209, 255), false);
        context.method_51439(field_22793, class_2561.method_43470(selectedAlt.getLastUsed() > 0 ? formatLastUsed(selectedAlt.getLastUsed()) : "Never"), detailsX + 14, detailsY + 190, UiColor.rgb(236, 237, 255), false);

        if (!selectedAlt.getUuid().isBlank()) {
            context.method_51439(field_22793, class_2561.method_43470("Press Login Alt to start with this UUID."), detailsX + 14, detailsY + 222, UiColor.rgb(162, 172, 215), false);
        }
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubleClicked) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        if (click.method_74245() == 0) {
            int listX = panelX + 24;
            int listY = panelY + 78;
            int itemY = listY + 8 - scrollOffset;
            for (AltAccount alt : displayAlts) {
                if (inside(mouseX, mouseY, listX + 6, itemY, 360 - 12, ITEM_HEIGHT)) {
                    selectAlt(alt);
                    return true;
                }
                itemY += ITEM_HEIGHT + ITEM_GAP;
            }
        }

        return super.method_25402(click, doubleClicked);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int maxScroll = Math.max(0, displayAlts.size() * (ITEM_HEIGHT + ITEM_GAP) - (PANEL_HEIGHT - 194));
        scrollOffset = class_3532.method_15340(scrollOffset - (int) (verticalAmount * 24.0), 0, maxScroll);
        return true;
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (searchField.method_25404(input) || usernameField.method_25404(input) || uuidField.method_25404(input)) {
            return true;
        }
        return super.method_25404(input);
    }

    @Override
    public boolean method_25400(class_11905 input) {
        if (searchField.method_25400(input) || usernameField.method_25400(input) || uuidField.method_25400(input)) {
            return true;
        }
        return super.method_25400(input);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void refreshList() {
        displayAlts = altManager.search(searchField.method_1882());
        if (selectedAlt != null) {
            selectedAlt = altManager.findById(selectedAlt.getId()).orElse(null);
        }
        scrollOffset = Math.min(scrollOffset, Math.max(0, displayAlts.size() * (ITEM_HEIGHT + ITEM_GAP) - (PANEL_HEIGHT - 194)));
        updateButtons();
    }

    private void selectAlt(AltAccount alt) {
        selectedAlt = alt;
        usernameField.method_1852(alt.getUsername());
        uuidField.method_1852(alt.getUuid());
        updateButtons();
        showStatus("Selected alt " + alt.getUsername());
    }

    private void addAlt() {
        String username = usernameField.method_1882().trim();
        String uuid = uuidField.method_1882().trim();
        if (username.isEmpty()) {
            showStatus("Username cannot be empty.");
            return;
        }
        altManager.addAlt(AltAccount.create(username, uuid));
        refreshList();
        showStatus("Alt added.");
    }

    private void editAlt() {
        if (selectedAlt == null) {
            return;
        }
        String username = usernameField.method_1882().trim();
        String uuid = uuidField.method_1882().trim();
        if (username.isEmpty()) {
            showStatus("Username cannot be empty.");
            return;
        }
        selectedAlt = selectedAlt.withUsername(username).withUuid(uuid);
        altManager.updateAlt(selectedAlt);
        refreshList();
        showStatus("Alt updated.");
    }

    private void removeAlt() {
        if (selectedAlt == null) {
            return;
        }
        altManager.removeAlt(selectedAlt);
        selectedAlt = null;
        usernameField.method_1852("");
        uuidField.method_1852("");
        refreshList();
        showStatus("Alt removed.");
    }

    private void loginSelectedAlt() {
        if (selectedAlt == null) {
            return;
        }
        class_310 client = class_310.method_1551();
        String username = selectedAlt.getUsername();
        String rawId = selectedAlt.getUuid().isEmpty() ? "OfflinePlayer:" + username : selectedAlt.getUuid();
        UUID profileId = parseProfileId(rawId, username);
        class_320 session = new class_320(username, profileId, "0", Optional.empty(), Optional.of("legacy"));
        setClientSession(client, session);
        altManager.markAsUsed(selectedAlt);
        showStatus("Logged in as " + username + ".");
        client.method_1507(new class_442());
    }

    private UUID parseProfileId(String rawId, String username) {
        try {
            return UUID.fromString(rawId);
        } catch (IllegalArgumentException exception) {
            return UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).getBytes(StandardCharsets.UTF_8));
        }
    }

    private void setClientSession(class_310 client, class_320 session) {
        try {
            Field field = class_310.class.getDeclaredField("session");
            field.setAccessible(true);
            field.set(client, session);
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("Unable to set client session", exception);
        }
    }

    private void selectRandomAlt() {
        if (altManager.getAlts().isEmpty()) {
            showStatus("No alts to select.");
            return;
        }
        AltAccount randomAlt = altManager.randomAlt();
        selectAlt(randomAlt);
    }

    private void copyUsername() {
        if (selectedAlt == null) {
            return;
        }
        class_310.method_1551().field_1774.method_1455(selectedAlt.getUsername());
        showStatus("Username copied.");
    }

    private void toggleFavorite() {
        if (selectedAlt == null) {
            return;
        }
        altManager.toggleFavorite(selectedAlt);
        selectedAlt = altManager.findById(selectedAlt.getId()).orElse(null);
        refreshList();
        showStatus(selectedAlt != null && selectedAlt.isFavorite() ? "Marked as favorite." : "Unfavorited.");
    }

    private void updateButtons() {
        boolean hasSelection = selectedAlt != null;
        loginButton.field_22763 = hasSelection;
        editButton.field_22763 = hasSelection;
        removeButton.field_22763 = hasSelection;
        copyButton.field_22763 = hasSelection;
        favoriteButton.field_22763 = hasSelection;
        favoriteButton.method_25355(class_2561.method_43470(hasSelection && selectedAlt != null && selectedAlt.isFavorite() ? "Unfavorite" : "Favorite"));
    }

    private void showStatus(String message) {
        this.statusMessage = message;
        this.statusExpires = System.currentTimeMillis() + 3000L;
    }

    private String formatLastUsed(long timestamp) {
        return Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).format(LAST_USED_FORMAT);
    }

    private static boolean inside(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}
