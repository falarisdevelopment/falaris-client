package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.StringSetting;
import net.minecraft.class_310;

public final class NameProtect extends RenderModule {
    private final StringSetting customName = setting(new StringSetting("Custom Name", "Fake name to display.", "Protected"));

    private static NameProtect instance;

    public NameProtect() {
        super("NameProtect", "Hides your real username client-side.");
        instance = this;
    }

    public static String getFakeName() {
        if (instance != null && instance.isEnabled()) {
            return instance.customName.get();
        }
        return null;
    }

    @Override
    protected void onRenderTick(class_310 client) {
        if (client.field_1724 == null) return;
        if (client.field_1724.method_16914()) return;
        client.field_1724.method_5880(false);
    }
}
