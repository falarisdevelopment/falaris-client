package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.StringSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class XRay extends RenderModule {
    private final StringSetting ores = setting(new StringSetting("Ores", "Comma-separated ore ids.", "minecraft:diamond_ore,minecraft:deepslate_diamond_ore,minecraft:emerald_ore,minecraft:ancient_debris,minecraft:gold_ore,minecraft:deepslate_gold_ore,minecraft:iron_ore,minecraft:deepslate_iron_ore,minecraft:coal_ore,minecraft:deepslate_coal_ore,minecraft:copper_ore,minecraft:deepslate_copper_ore,minecraft:redstone_ore,minecraft:deepslate_redstone_ore,minecraft:lapis_ore,minecraft:deepslate_lapis_ore,minecraft:nether_quartz_ore,minecraft:nether_gold_ore"));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Ore scan range.", 64.0, 8.0, 128.0));
    private final BooleanSetting fullbright = setting(new BooleanSetting("Fullbright", "Apply high gamma while XRay is enabled.", true));
    private Double previousGamma;

    public XRay() {
        super("XRay", "Highlights configured ore blocks through the world.");
    }

    @Override
    protected void onRenderTick(class_310 client) {
        if (fullbright.enabled()) {
            if (previousGamma == null) {
                previousGamma = client.field_1690.method_42473().method_41753();
            }
            client.field_1690.method_42473().method_41748(15.0);
        }
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        Set<class_2248> targets = parseTargets();
        if (targets.isEmpty()) return;

        int radius = (int) Math.min(range.get(), 64.0);
        class_2338 origin = client.field_1724.method_24515();

        for (class_2338 pos : class_2338.method_25996(origin, radius, radius, radius)) {
            if (client.field_1687.method_8320(pos).method_26215()) continue;
            if (client.field_1724.method_5707(pos.method_46558()) > range.get() * range.get()) continue;
            if (targets.contains(client.field_1687.method_8320(pos).method_26204())) {
                RenderUtil.drawBlockBox(context, pos, RenderUtil.Color.rgba(178, 112, 255, 180));
            }
        }
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (previousGamma != null) {
            client.field_1690.method_42473().method_41748(previousGamma);
            previousGamma = null;
        }
    }

    private Set<class_2248> parseTargets() {
        Set<class_2248> result = new HashSet<>();
        for (String raw : ores.get().split(",")) {
            String id = raw.trim().toLowerCase(Locale.ROOT);
            if (!id.isEmpty()) {
                class_7923.field_41175.method_17966(class_2960.method_60654(id)).ifPresent(result::add);
            }
        }
        return result;
    }
}
