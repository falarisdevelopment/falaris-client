package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import net.minecraft.class_310;

public final class AutoSprint extends MovementModule {
    private final BooleanSetting omnidirectional = setting(new BooleanSetting("Omnidirectional", "Sprint while moving in any direction.", false));
    private final BooleanSetting requireForward = setting(new BooleanSetting("Require Forward", "Only sprint when forward is held.", true));
    private final BooleanSetting stopInWater = setting(new BooleanSetting("Stop In Water", "Avoid sprinting while submerged.", false));

    public AutoSprint() {
        super("AutoSprint", "Automatically toggles sprint while moving.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) {
            return;
        }
        if (stopInWater.enabled() && client.field_1724.method_5869()) {
            client.field_1724.method_5728(false);
            return;
        }

        boolean movingForward = client.field_1690.field_1894.method_1434();
        boolean movingAny = movingForward || client.field_1690.field_1881.method_1434() || client.field_1690.field_1913.method_1434() || client.field_1690.field_1849.method_1434();
        boolean shouldSprint = omnidirectional.enabled() ? movingAny : movingForward;
        if (requireForward.enabled()) {
            shouldSprint = movingForward;
        }

        client.field_1724.method_5728(shouldSprint && !client.field_1724.method_5715() && !client.field_1724.field_5976);
    }
}
