package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class DamageIndicator extends RenderModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Max render range.", 64.0, 8.0, 256.0));
    private final BooleanSetting showParticles = setting(new BooleanSetting("Show Particles", "Spawn particles on hit.", true));
    private final IntegerSetting particleCount = setting(new IntegerSetting("Particle Count", "Particles per hit.", 6, 2, 20));
    private final DoubleSetting particleSpread = setting(new DoubleSetting("Particle Spread", "Spread radius.", 0.5, 0.1, 2.0));
    private final IntegerSetting fadeTicks = setting(new IntegerSetting("Fade Ticks", "Ticks before fade.", 20, 5, 60));
    private final BooleanSetting showDamageNumbers = setting(new BooleanSetting("Show Damage Numbers", "Float damage text.", true));

    private final Map<UUID, HitEntry> hitLog = new ConcurrentHashMap<>();

    public DamageIndicator() {
        super("DamageIndicator", "Visual damage feedback — floating numbers, hit particles, hurt flash.");
    }

    public void recordHit(class_1297 target, float damage) {
        if (!isEnabled()) return;
        if (!(target instanceof class_1309)) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        double dist = client.field_1724.method_5739(target);
        if (dist > range.get()) return;
        hitLog.put(target.method_5667(), new HitEntry(damage, new class_243(target.method_23317(), target.method_23318(), target.method_23321()), System.currentTimeMillis()));
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;
        long now = System.currentTimeMillis();
        hitLog.entrySet().removeIf(e -> now - e.getValue().time > fadeTicks.get() * 50L);

        if (showDamageNumbers.enabled() && !hitLog.isEmpty()) {
            class_4587 matrices = context.matrices();
            class_4597 consumers = context.consumers();
            if (consumers == null) return;
            class_4184 camera = client.field_1773.method_19418();
            class_243 cam = camera.method_71156();

            for (HitEntry entry : hitLog.values()) {
                class_243 pos = entry.pos;
                double age = (now - entry.time) / 1000.0;
                double heightOffset = age * 0.5;

                matrices.method_22903();
                matrices.method_22904(pos.field_1352 - cam.field_1352, pos.field_1351 - cam.field_1351 + heightOffset, pos.field_1350 - cam.field_1350);
                matrices.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(-camera.method_19330()));
                matrices.method_22907(net.minecraft.class_7833.field_40714.rotationDegrees(camera.method_19329()));
                matrices.method_22905(-0.03f, -0.03f, 0.03f);

                String text = String.format("§c-%.0f", entry.damage);
                float w = client.field_1772.method_1727(text);
                float alpha = Math.max(0, 1.0f - (float) age);
                int color = ((int)(alpha * 255) << 24) | 0xFF5555;

                client.field_1772.method_27521(text, -w / 2, 0, color, false,
                    matrices.method_23760().method_23761(), consumers,
                    net.minecraft.class_327.class_6415.field_33993, 0, 0xF000F0);

                matrices.method_22909();
            }
        }
    }

    private record HitEntry(float damage, class_243 pos, long time) {}
}
