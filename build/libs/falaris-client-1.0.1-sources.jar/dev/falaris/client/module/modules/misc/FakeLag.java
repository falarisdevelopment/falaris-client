package dev.falaris.client.module.modules.misc;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2828;
import net.minecraft.class_310;

public final class FakeLag extends MiscModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Lag behavior.", "Delay", "Delay", "Pulse", "BlinkCombat"));
    private final IntegerSetting holdTicks = setting(new IntegerSetting("Hold Ticks", "Ticks to hold packets.", 10, 2, 100));
    private final IntegerSetting pulseInterval = setting(new IntegerSetting("Pulse Interval", "Ticks between bursts.", 15, 2, 60));
    private final BooleanSetting toggleOnDisconnect = setting(new BooleanSetting("Toggle on Disconnect", "Disable on logout.", true));

    // BlinkCombat settings
    private final IntegerSetting combatFlushDelay = setting(new IntegerSetting("Combat Flush Delay", "Ticks after attack to flush.", 5, 0, 20));

    private final List<class_2828> heldPackets = new ArrayList<>();
    private int tickCounter;
    private int combatHoldTicks;

    public FakeLag() {
        super("FakeLag", "Delays movement packets to create a lag-back / blink combat effect.");
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null || client.method_1562() == null) { heldPackets.clear(); return; }

        if (mode.is("BlinkCombat")) {
            handleBlinkCombat(client);
            return;
        }

        tickCounter++;
        boolean flush = switch (mode.get()) {
            case "Delay" -> tickCounter >= holdTicks.get();
            case "Pulse" -> tickCounter >= pulseInterval.get();
            default -> false;
        };
        if (flush && !heldPackets.isEmpty()) { sendPackets(); tickCounter = 0; }
    }

    private void handleBlinkCombat(class_310 client) {
        tickCounter++;
        boolean inCombat = client.field_1724.field_6235 > 0 || isAttacking();

        if (inCombat) {
            combatHoldTicks = holdTicks.get();
        }

        if (combatHoldTicks > 0) {
            combatHoldTicks--;
            if (combatHoldTicks <= 0 && !heldPackets.isEmpty()) {
                sendPackets();
            }
        } else if (tickCounter >= holdTicks.get() && !heldPackets.isEmpty()) {
            sendPackets();
            tickCounter = 0;
        }
    }

    private boolean isAttacking() {
        var ka = FalarisClient.getInstance().getModuleManager().find("killaura");
        return ka.isPresent() && ka.get().isEnabled();
    }

    public boolean shouldHoldPacket() {
        if (!isEnabled()) return false;
        return switch (mode.get()) {
            case "BlinkCombat" -> combatHoldTicks > 0 || tickCounter < holdTicks.get();
            case "Delay" -> tickCounter < holdTicks.get();
            case "Pulse" -> true;
            default -> false;
        };
    }

    public void holdPacket(class_2828 packet) { heldPackets.add(packet); }

    private void sendPackets() {
        if (heldPackets.isEmpty()) return;
        var nh = class_310.method_1551().method_1562();
        if (nh == null) return;
        for (class_2828 p : heldPackets) nh.method_52787(p);
        heldPackets.clear();
    }

    @Override protected void onEnable() { super.onEnable(); heldPackets.clear(); tickCounter = 0; combatHoldTicks = 0; }
    @Override protected void onDisable() { sendPackets(); super.onDisable(); }

    public int getHeldPackets() { return heldPackets.size(); }
}
