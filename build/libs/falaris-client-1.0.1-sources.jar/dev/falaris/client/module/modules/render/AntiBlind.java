package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import net.minecraft.class_1294;
import net.minecraft.class_310;

public final class AntiBlind extends RenderModule {
    private final BooleanSetting blind = setting(new BooleanSetting("Blindness", "Remove blindness effect.", true));
    private final BooleanSetting nausea = setting(new BooleanSetting("Nausea", "Remove nausea effect.", true));
    private final BooleanSetting darkness = setting(new BooleanSetting("Darkness", "Remove darkness effect.", true));
    private final BooleanSetting fire = setting(new BooleanSetting("Fire", "Remove fire overlay.", true));

    public AntiBlind() {
        super("AntiBlind", "Removes blindness, nausea, and darkness effects.");
    }

    @Override
    protected void onRenderTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (blind.enabled() && client.field_1724.method_6059(class_1294.field_5919)) {
            client.field_1724.method_6016(class_1294.field_5919);
        }
        if (nausea.enabled() && client.field_1724.method_6059(class_1294.field_5916)) {
            client.field_1724.method_6016(class_1294.field_5916);
        }
        if (darkness.enabled() && client.field_1724.method_6059(class_1294.field_38092)) {
            client.field_1724.method_6016(class_1294.field_38092);
        }
    }
}
