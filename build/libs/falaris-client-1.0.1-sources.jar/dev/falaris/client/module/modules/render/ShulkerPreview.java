package dev.falaris.client.module.modules.render;

import dev.falaris.client.event.events.RenderHudEvent;
import dev.falaris.client.setting.BooleanSetting;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

public final class ShulkerPreview extends RenderModule {
    private final BooleanSetting requireShift = setting(new BooleanSetting("Require Shift", "Only show preview while holding shift.", true));
    private static final class_2960 SHULKER_GUI = class_2960.method_60655("minecraft", "textures/gui/container/shulker_box.png");

    public ShulkerPreview() {
        super("ShulkerPreview", "Displays the contents of shulker boxes in your inventory.");
    }

    @Override
    protected void onHudRender(class_332 context, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || !(client.field_1755 instanceof class_465<?> screen)) {
            return;
        }

        if (requireShift.enabled() && !client.field_1690.field_1832.method_1434()) {
            return;
        }

        class_1735 hoveredSlot = null;
        try {
            java.lang.reflect.Field field = class_465.class.getDeclaredField("hoveredSlot");
            field.setAccessible(true);
            hoveredSlot = (class_1735) field.get(screen);
        } catch (Exception ignored) {}
        
        if (hoveredSlot == null || !hoveredSlot.method_7681()) {
            return;
        }

        class_1799 stack = hoveredSlot.method_7677();
        class_9288 container = stack.method_58694(class_9334.field_49622);
        if (container == null) {
            return;
        }

        drawPreview(context, container);
    }

    private void drawPreview(class_332 context, class_9288 container) {
        int x = context.method_51421() / 2 + 10;
        int y = context.method_51443() / 2 - 40;

        // Draw background
        context.method_70845(SHULKER_GUI, x, y, 176, 76, 0.0f, 0.0f, 1.0f, 1.0f);
        context.method_51433(class_310.method_1551().field_1772, "Shulker Box", x + 8, y + 6, 0x404040, false);

        int i = 0;
        for (class_1799 itemStack : container.method_59714()) {
            int slotX = x + 8 + (i % 9) * 18;
            int slotY = y + 18 + (i / 9) * 18;
            context.method_51427(itemStack, slotX, slotY);
            context.method_51431(class_310.method_1551().field_1772, itemStack, slotX, slotY);
            i++;
        }

        // no matrix stack push/pop needed for 2D preview
    }
}
