package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class AirPlace extends MovementModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Placement distance from eyes.", 4.5, 1.0, 6.0));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between placements.", 4, 1, 20));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks between placements.", 2, 0, 10));
    private final BooleanSetting requireUse = setting(new BooleanSetting("Require Use", "Only place while use key is held.", true));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Face the placement position.", true));

    public AirPlace() {
        super("AirPlace", "Places blocks at a projected position in front of the player.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            return;
        }
        if (requireUse.enabled() && !client.field_1690.field_1904.method_1434()) {
            return;
        }
        if (!(client.field_1724.method_6047().method_7909() instanceof class_1747)) {
            return;
        }

        class_243 eye = client.field_1724.method_33571();
        class_243 target = eye.method_1019(client.field_1724.method_5720().method_1021(range.get()));
        class_2338 placePos = class_2338.method_49638(target);
        if (!client.field_1687.method_8320(placePos).method_26215() || !ready(delay.get(), jitter.get())) {
            return;
        }

        if (rotate.enabled()) {
            float yaw = MovementUtil.yawTo(client.field_1724.method_33571(), class_243.method_24953(placePos));
            rotations().rotateTo(yaw, client.field_1724.method_36455(), 2);
        }

        class_3965 result = new class_3965(class_243.method_24953(placePos), class_2350.field_11036, placePos.method_10074(), false);
        client.field_1761.method_2896(client.field_1724, class_1268.field_5808, result);
        client.field_1724.method_6104(class_1268.field_5808);
    }
}
