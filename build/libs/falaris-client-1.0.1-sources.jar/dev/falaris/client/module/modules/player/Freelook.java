package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5498;

public final class Freelook extends PlayerModule {
    private final BooleanSetting holdMode = setting(new BooleanSetting("Hold Mode", "Hold the freelook key while active.", false));
    private final DoubleSetting sensitivity = setting(new DoubleSetting("Sensitivity", "Freelook sensitivity.", 1.0, 0.1, 3.0));
    private final BooleanSetting resetOnDisable = setting(new BooleanSetting("Reset on Disable", "Return camera to body rotation.", true));

    private float cameraYaw, cameraPitch;
    private boolean active;
    private boolean wasActive;
    private double lastMouseX, lastMouseY;
    private boolean firstTick = true;

    public Freelook() {
        super("Freelook", "Detaches camera movement from player body rotation.");
    }

    @Override
    protected void onEnable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        cameraYaw = client.field_1724.method_36454();
        cameraPitch = client.field_1724.method_36455();
        firstTick = true;
        active = true;
        wasActive = true;
        client.field_1690.method_31043(class_5498.field_26664);
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && wasActive && resetOnDisable.enabled()) {
            client.field_1724.method_36456(cameraYaw);
            client.field_1724.method_36457(cameraPitch);
        }
        wasActive = false;
        active = false;
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null || client.field_1690 == null) return;

        if (holdMode.enabled()) {
            active = isFreelookHeld(client);
        }

        client.field_1690.method_31043(class_5498.field_26664);

        if (!active) {
            if (wasActive && resetOnDisable.enabled()) {
                cameraYaw = class_3532.method_16439(0.3f, cameraYaw, client.field_1724.method_36454());
                cameraPitch = class_3532.method_16439(0.3f, cameraPitch, client.field_1724.method_36455());
                if (Math.abs(cameraYaw - client.field_1724.method_36454()) < 0.5f) {
                    cameraYaw = client.field_1724.method_36454();
                    cameraPitch = client.field_1724.method_36455();
                }
            } else {
                cameraYaw = client.field_1724.method_36454();
                cameraPitch = client.field_1724.method_36455();
            }
            wasActive = false;
        } else {
            wasActive = true;
            double mx = client.field_1729.method_1603();
            double my = client.field_1729.method_1604();
            if (firstTick) {
                lastMouseX = mx;
                lastMouseY = my;
                firstTick = false;
            }
            double dx = (mx - lastMouseX) * sensitivity.get() * 0.3;
            double dy = (my - lastMouseY) * sensitivity.get() * 0.3;
            lastMouseX = mx;
            lastMouseY = my;
            cameraYaw += (float) dx;
            cameraPitch = (float) class_3532.method_15350(cameraPitch - dy, -90.0, 90.0);
        }

        client.field_1724.method_36456(cameraYaw);
        client.field_1724.method_36457(cameraPitch);
        client.field_1724.field_6241 = cameraYaw;
        client.field_1724.field_5982 = cameraYaw;
        client.field_1724.field_6004 = cameraPitch;
    }

    private boolean isFreelookHeld(class_310 client) {
        try {
            var key = client.field_1690.field_1832;
            return key != null && key.method_1434();
        } catch (Exception e) {
            return client.field_1729.method_1613();
        }
    }
}
