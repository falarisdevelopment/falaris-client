package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class Velocity extends MiscModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Velocity reduction mode.", "Cancel", "Cancel", "Override", "Push Only", "Reduce"));
    private final DoubleSetting horizontal = setting(new DoubleSetting("Horizontal", "Horizontal velocity multiplier.", 0.0, 0.0, 1.0));
    private final DoubleSetting vertical = setting(new DoubleSetting("Vertical", "Vertical velocity multiplier.", 0.0, 0.0, 1.0));
    private final BooleanSetting applySelf = setting(new BooleanSetting("Apply Self", "Also affect self-explosion knockback.", false));
    private final BooleanSetting pushImmunity = setting(new BooleanSetting("Push Immunity", "Cancel entity push.", true));
    private final BooleanSetting waterImmunity = setting(new BooleanSetting("Water Immunity", "Cancel water push.", false));
    private final BooleanSetting explosionImmunity = setting(new BooleanSetting("Explosion Immunity", "Cancel explosion knockback.", false));
    private final IntegerSetting cancelTicks = setting(new IntegerSetting("Cancel Ticks", "Ticks to cancel velocity after hit.", 5, 0, 20));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anticheat bypass method.", "Vanilla", "Vanilla", "Legit", "Grim", "Vulcan", "AAC"));

    private final Random random = new Random();
    private int velocityCancelTicks;

    public Velocity() {
        super("Velocity", "Modifies incoming knockback velocity.");
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null) return;
        if (velocityCancelTicks > 0) velocityCancelTicks--;

        if (pushImmunity.enabled()) {
            client.field_1724.method_18799(client.field_1724.method_18798().method_18805(1.0, 0.0, 1.0));
        }

        if (waterImmunity.enabled() && client.field_1724.method_5799()) {
            class_243 vel = client.field_1724.method_18798();
            client.field_1724.method_18800(vel.field_1352 * 0.8, vel.field_1351, vel.field_1350 * 0.8);
        }

        boolean isHurt = client.field_1724.field_6235 > 0;
        boolean hasVelocity = client.field_1724.method_18798().method_1027() > 0.005;

        if (!isHurt || !hasVelocity) return;

        if (!applySelf.enabled() && client.field_1724.method_5757()) return;

        if (velocityCancelTicks <= 0 && cancelTicks.get() > 0) {
            velocityCancelTicks = cancelTicks.get();
        }

        String b = bypass.get();
        class_243 vel = client.field_1724.method_18798();

        if (b.equals("Grim")) {
            double h = 0.75 + random.nextDouble() * 0.20;
            double v = 0.75 + random.nextDouble() * 0.20;
            client.field_1724.method_18800(vel.field_1352 * h, vel.field_1351 * v, vel.field_1350 * h);
            return;
        }

        if (b.equals("Legit")) {
            double h = 0.85 + random.nextDouble() * 0.10;
            double v = 0.85 + random.nextDouble() * 0.10;
            client.field_1724.method_18800(vel.field_1352 * h, vel.field_1351 * v, vel.field_1350 * h);
            return;
        }

        if (mode.is("Cancel")) {
            client.field_1724.method_18800(0, 0, 0);
        } else if (mode.is("Reduce")) {
            client.field_1724.method_18800(
                    vel.field_1352 * horizontal.get(),
                    vel.field_1351 * vertical.get(),
                    vel.field_1350 * horizontal.get()
            );
        } else if (mode.is("Override")) {
            client.field_1724.method_18800(
                    vel.field_1352 * Math.max(0.05, horizontal.get()),
                    vel.field_1351 * Math.max(0.05, vertical.get()),
                    vel.field_1350 * Math.max(0.05, horizontal.get())
            );
        } else if (mode.is("Push Only")) {
            if (Math.abs(vel.field_1351) < 0.1) {
                client.field_1724.method_18800(vel.field_1352 * horizontal.get(), vel.field_1351, vel.field_1350 * horizontal.get());
            }
        }
    }
}
