package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_310;

public final class Velocity extends MiscModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Velocity reduction mode.", "Cancel", "Cancel", "Override", "Push Only", "Reduce"));
    private final DoubleSetting horizontal = setting(new DoubleSetting("Horizontal", "Horizontal velocity multiplier.", 0.0, 0.0, 1.0));
    private final DoubleSetting vertical = setting(new DoubleSetting("Vertical", "Vertical velocity multiplier.", 0.0, 0.0, 1.0));
    private final BooleanSetting applySelf = setting(new BooleanSetting("Apply Self", "Also affect self-explosion knockback.", false));
    private final BooleanSetting pushImmunity = setting(new BooleanSetting("Push Immunity", "Cancel entity push.", true));
    private final BooleanSetting waterImmunity = setting(new BooleanSetting("Water Immunity", "Cancel water push.", false));
    private final BooleanSetting explosionImmunity = setting(new BooleanSetting("Explosion Immunity", "Cancel explosion knockback.", false));
    private final IntegerSetting cancelTicks = setting(new IntegerSetting("Cancel Ticks", "Ticks to cancel velocity after hit.", 5, 0, 20));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anticheat bypass method.", "Vanilla", "Vanilla", "Legit", "Grim", "Grim2344", "Grim2371", "Vulcan", "AAC"));

    private final Random random = new Random();
    private int velocityCancelTicks;
    private int knockbackTick;
    private boolean wasHurt;

    // Grim2344 (C06) state
    private boolean grimC06Pending;
    private int grimC06Ticks;

    // Grim2371 (Block-place) state
    private boolean grim2371Pending;
    private int grim2371Ticks;

    public Velocity() {
        super("Velocity", "Modifies incoming knockback velocity.");
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null || client.method_1562() == null) return;
        if (velocityCancelTicks > 0) velocityCancelTicks--;

        if (pushImmunity.enabled()) {
            client.field_1724.method_18799(client.field_1724.method_18798().method_18805(1.0, 0.0, 1.0));
        }

        if (waterImmunity.enabled() && client.field_1724.method_5799()) {
            class_243 vel = client.field_1724.method_18798();
            client.field_1724.method_18800(vel.field_1352 * 0.8, vel.field_1351, vel.field_1350 * 0.8);
        }

        boolean isHurt = client.field_1724.field_6235 > 0;
        boolean hasVelocity = client.field_1724.method_18798().method_1027() > 0.005;
        boolean justGotHit = isHurt && !wasHurt;

        if (isHurt) knockbackTick++;
        wasHurt = isHurt;

        String b = bypass.get();

        // --- Grim2344: C06 bypass ---
        if (b.equals("Grim2344")) {
            handleGrim2344(client, justGotHit, hasVelocity);
            return;
        }

        // --- Grim2371: Block-place bypass ---
        if (b.equals("Grim2371")) {
            handleGrim2371(client, justGotHit, hasVelocity);
            return;
        }

        if (!isHurt || !hasVelocity) return;
        if (!applySelf.enabled() && client.field_1724.method_5757()) return;
        if (velocityCancelTicks <= 0 && cancelTicks.get() > 0) {
            velocityCancelTicks = cancelTicks.get();
        }

        class_243 vel = client.field_1724.method_18798();
        double hMul = horizontal.get();
        double vMul = vertical.get();

        if (b.equals("Grim") || b.equals("Legit")) {
            double jitter = b.equals("Grim") ? 0.10 : 0.05;
            double fadeH, fadeV;
            if (knockbackTick <= 1) {
                fadeH = hMul * 0.5 + 0.5;
                fadeV = vMul * 0.5 + 0.5;
            } else {
                fadeH = hMul;
                fadeV = vMul;
            }
            double h = fadeH * (1.0 - jitter + random.nextDouble() * jitter * 2.0);
            double v = fadeV * (1.0 - jitter + random.nextDouble() * jitter * 2.0);
            client.field_1724.method_18800(vel.field_1352 * h, vel.field_1351 * v, vel.field_1350 * h);
            return;
        }

        class_243 nv = vel;
        if (mode.is("Cancel")) {
            nv = class_243.field_1353;
        } else if (mode.is("Reduce")) {
            nv = new class_243(vel.field_1352 * hMul, vel.field_1351 * vMul, vel.field_1350 * hMul);
        } else if (mode.is("Override")) {
            nv = new class_243(vel.field_1352 * Math.max(0.05, hMul), vel.field_1351 * Math.max(0.05, vMul), vel.field_1350 * Math.max(0.05, hMul));
        } else if (mode.is("Push Only") && Math.abs(vel.field_1351) < 0.1) {
            nv = new class_243(vel.field_1352 * hMul, vel.field_1351, vel.field_1350 * hMul);
        }
        client.field_1724.method_18799(nv);
    }

    private void handleGrim2344(class_310 client, boolean justGotHit, boolean hasVelocity) {
        if (justGotHit && hasVelocity) {
            client.field_1724.method_18800(0, 0, 0);
            grimC06Pending = true;
            grimC06Ticks = 0;
        }
        if (grimC06Pending) {
            grimC06Ticks++;
            if (grimC06Ticks >= 1 && client.method_1562() != null) {
                for (int i = 0; i < 4; i++) {
                    client.method_1562().method_52787(new class_2828.class_2829(
                        client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321(),
                        client.field_1724.method_24828(), client.field_1724.field_5976
                    ));
                }
                class_2338 bp = client.field_1724.method_24515();
                class_2350 dir = client.field_1724.method_5735().method_10153();
                client.method_1562().method_52787(new class_2846(
                    class_2846.class_2847.field_12973, bp, dir
                ));
                grimC06Pending = false;
            }
        }
    }

    private void handleGrim2371(class_310 client, boolean justGotHit, boolean hasVelocity) {
        if (justGotHit && hasVelocity) {
            client.field_1724.method_18800(0, 0, 0);
            grim2371Pending = true;
            grim2371Ticks = 0;
        }
        if (grim2371Pending) {
            grim2371Ticks++;
            if (grim2371Ticks >= 2 && client.method_1562() != null) {
                var hitResult = client.field_1765;
                if (hitResult instanceof net.minecraft.class_3965 bhr) {
                    var result = client.field_1761.method_2896(client.field_1724, net.minecraft.class_1268.field_5808, bhr);
                    if (result.method_23665()) {
                        client.field_1724.method_6104(net.minecraft.class_1268.field_5808);
                    }
                }
                client.method_1562().method_52787(new class_2828.class_2831(
                    client.field_1724.method_36454(), 90f,
                    client.field_1724.method_24828(), client.field_1724.field_5976
                ));
                grim2371Pending = false;
            }
        }
    }
}
