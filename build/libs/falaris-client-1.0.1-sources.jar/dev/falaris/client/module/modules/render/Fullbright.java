package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_310;

public final class Fullbright extends RenderModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Brightness mode.", "Both", "Night Vision", "Gamma", "Both"));
    private final BooleanSetting keepPotion = setting(new BooleanSetting("Keep Potion", "Refresh client night vision effect.", true));
    private Double previousGamma;

    public Fullbright() {
        super("Fullbright", "Brightens dark areas client-side.");
    }

    @Override
    protected void onRenderTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (mode.is("Night Vision") || mode.is("Both")) {
            if (keepPotion.enabled()) {
                client.field_1724.method_6092(new class_1293(class_1294.field_5925, 260, 0, false, false, false));
            }
        }
        if (mode.is("Gamma") || mode.is("Both")) {
            if (previousGamma == null) {
                previousGamma = client.field_1690.method_42473().method_41753();
            }
            client.field_1690.method_42473().method_41748(1.0);
        }
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_6016(class_1294.field_5925);
        }
        if (previousGamma != null) {
            client.field_1690.method_42473().method_41748(previousGamma);
            previousGamma = null;
        }
    }
}
