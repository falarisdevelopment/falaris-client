package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.DoubleSetting;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import dev.falaris.client.setting.BooleanSetting;

public final class TridentBoost extends MovementModule {
    private final DoubleSetting speedBoost = setting(new DoubleSetting("Speed Boost", "Multiplier for riptide velocity.", 1.5, 0.5, 3.0));
    private final BooleanSetting onlyRiptide = setting(new BooleanSetting("Only Riptide", "Only boost when holding any trident.", false));

    public TridentBoost() {
        super("TridentBoost", "Boosts range and velocity of trident riptide launches.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (!client.field_1724.method_6115()) return;

        class_1799 mainHand = client.field_1724.method_6047();
        class_1799 offHand = client.field_1724.method_6079();
        boolean hasTrident = mainHand.method_31574(class_1802.field_8547) || offHand.method_31574(class_1802.field_8547);
        if (!hasTrident) return;

        if (!client.field_1724.method_5721() && !client.field_1724.method_5869()) return;

        var vel = client.field_1724.method_18798();
        client.field_1724.method_18800(
            vel.field_1352 * speedBoost.get(),
            vel.field_1351 * speedBoost.get(),
            vel.field_1350 * speedBoost.get()
        );
    }
}
