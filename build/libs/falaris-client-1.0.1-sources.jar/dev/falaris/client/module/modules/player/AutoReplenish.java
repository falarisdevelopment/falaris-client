package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public final class AutoReplenish extends PlayerModule {
    private final IntegerSetting threshold = setting(new IntegerSetting("Threshold", "Refill when stack is below this count.", 16, 1, 64));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between refills.", 5, 1, 20));
    private final BooleanSetting hotbarOnly = setting(new BooleanSetting("Hotbar Only", "Only refill hotbar from inventory.", true));
    private final BooleanSetting pauseOnOpen = setting(new BooleanSetting("Pause On Open", "Don't refill while inventory is open.", true));

    private int tickCounter;

    public AutoReplenish() {
        super("AutoReplenish", "Auto-refills hotbar slots from inventory.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        tickCounter = 0;
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;
        tickCounter++;
        if (tickCounter < delay.get()) return;
        tickCounter = 0;

        if (pauseOnOpen.enabled() && client.field_1755 != null) return;

        var inventory = client.field_1724.method_31548();

        for (int hotbarSlot = 0; hotbarSlot < 9; hotbarSlot++) {
            class_1799 stack = inventory.method_5438(hotbarSlot);
            if (stack.method_7960()) continue;
            if (stack.method_7947() >= threshold.get()) continue;

            String itemId = net.minecraft.class_7923.field_41178.method_10221(stack.method_7909()).toString();

            int bestSlot = -1;
            int bestCount = 0;
            int start = hotbarOnly.enabled() ? 9 : 0;
            for (int slot = start; slot < 36; slot++) {
                class_1799 other = inventory.method_5438(slot);
                if (other.method_7960() || slot == hotbarSlot) continue;
                String otherId = net.minecraft.class_7923.field_41178.method_10221(other.method_7909()).toString();
                if (!otherId.equals(itemId)) continue;
                if (other.method_7947() > bestCount) {
                    bestCount = other.method_7947();
                    bestSlot = slot;
                }
            }

            if (bestSlot >= 0) {
                int targetCount = Math.min(stack.method_7914(), stack.method_7947() + bestCount);
                if (bestSlot >= 9) {
                    client.field_1761.method_2906(
                        client.field_1724.field_7512.field_7763,
                        bestSlot < 36 ? bestSlot + 36 : bestSlot,
                        hotbarSlot,
                        net.minecraft.class_1713.field_7791,
                        client.field_1724
                    );
                } else {
                    client.field_1761.method_2906(
                        client.field_1724.field_7512.field_7763,
                        bestSlot,
                        hotbarSlot,
                        net.minecraft.class_1713.field_7791,
                        client.field_1724
                    );
                }
            }
        }
    }
}
