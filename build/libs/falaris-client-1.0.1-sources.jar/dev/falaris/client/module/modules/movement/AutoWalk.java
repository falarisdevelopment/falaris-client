package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.minecraft.class_310;

public final class AutoWalk extends MovementModule {
    private final BooleanSetting sprint = setting(new BooleanSetting("Sprint", "Sprint while auto-walking.", true));
    private final BooleanSetting stopOnScreen = setting(new BooleanSetting("Stop On Screen", "Pause while a GUI screen is open.", true));
    private final BooleanSetting steer = setting(new BooleanSetting("Steer", "Use the current camera yaw as direction.", true));
    private final DoubleSetting speed = setting(new DoubleSetting("Speed", "Optional direct movement speed.", 0.0, 0.0, 1.5));

    public AutoWalk() {
        super("AutoWalk", "Keeps the player moving forward.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null || stopOnScreen.enabled() && client.field_1755 != null) {
            return;
        }

        client.field_1690.field_1894.method_23481(true);
        client.field_1724.method_5728(sprint.enabled());

        if (steer.enabled()) {
            rotations().rotateTo(client.field_1724.method_36454(), client.field_1724.method_36455(), 1);
        }
        if (speed.get() > 0.0) {
            MovementUtil.setHorizontalSpeed(client.field_1724, speed.get(), client);
        }
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        client.field_1690.field_1894.method_23481(false);
    }
}
