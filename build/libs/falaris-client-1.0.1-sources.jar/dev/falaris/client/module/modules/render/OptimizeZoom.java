package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_310;

public final class OptimizeZoom extends RenderModule {
    private final DoubleSetting zoomFactor = setting(new DoubleSetting("Zoom Factor", "Zoom multiplier.", 4.0, 2.0, 20.0));
    private final DoubleSetting smoothness = setting(new DoubleSetting("Smoothness", "Zoom transition speed.", 0.25, 0.05, 1.0));
    private final IntegerSetting maxFov = setting(new IntegerSetting("Max FOV", "Maximum FOV to zoom from.", 90, 30, 180));

    private double currentFov;
    private double targetFov;
    private boolean zoomActive;

    public OptimizeZoom() {
        super("OptimizeZoom", "Smooth zoom with adjustable FOV.");
    }

    @Override
    protected void onRenderTick(class_310 client) {
        if (client.field_1724 == null) return;

        boolean shouldZoom = client.field_1690.field_1832.method_1434();

        if (shouldZoom && !zoomActive) {
            zoomActive = true;
            targetFov = maxFov.get() / zoomFactor.get();
        } else if (!shouldZoom && zoomActive) {
            zoomActive = false;
            targetFov = maxFov.get();
        }

        if (zoomActive) {
            currentFov += (targetFov - currentFov) * smoothness.get();
        } else if (currentFov < maxFov.get() - 0.5) {
            currentFov += (maxFov.get() - currentFov) * smoothness.get();
        } else {
            currentFov = maxFov.get();
        }

        if (zoomActive || currentFov < maxFov.get() - 1.0) {
            client.field_1690.method_41808().method_41748((int) currentFov);
        }
    }
}
