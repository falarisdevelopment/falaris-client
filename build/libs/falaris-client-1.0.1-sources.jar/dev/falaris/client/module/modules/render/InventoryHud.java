package dev.falaris.client.module.modules.render;

import dev.falaris.client.gui.click.UiColor;
import dev.falaris.client.gui.click.UiRender;
import dev.falaris.client.setting.BooleanSetting;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class InventoryHud extends RenderModule {
    private final BooleanSetting background = setting(new BooleanSetting("Background", "Draw panel behind info.", true));

    public InventoryHud() {
        super("InventoryHUD", "Displays inventory preview on screen.");
    }

    @Override
    protected void onHudRender(class_332 context, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        int x = 20, y = 150;
        int rows = 3, cols = 9;
        int size = 18;
        int width = cols * size + 10;
        int height = rows * size + 10;

        if (background.enabled()) {
            UiRender.fillRound(context, x - 5, y - 5, width, height, 4, UiColor.argb(120, 10, 10, 15));
        }

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int index = (r + 1) * 9 + c;
                class_1799 stack = client.field_1724.method_31548().method_5438(index);
                if (!stack.method_7960()) {
                    int posX = x + c * size;
                    int posY = y + r * size;
                    context.method_51427(stack, posX, posY);
                    context.method_51431(client.field_1772, stack, posX, posY);
                }
            }
        }
    }
}
