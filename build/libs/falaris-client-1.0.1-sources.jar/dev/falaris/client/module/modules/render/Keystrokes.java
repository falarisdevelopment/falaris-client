package dev.falaris.client.module.modules.render;

import dev.falaris.client.gui.click.UiRender;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class Keystrokes extends RenderModule {
    private final IntegerSetting offsetX = setting(new IntegerSetting("Offset X", "Horizontal position.", 4, 0, 800));
    private final IntegerSetting offsetY = setting(new IntegerSetting("Offset Y", "Vertical position.", 100, 0, 600));
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Key display mode.", "WASD", "WASD", "WASD+Mouse", "WASD+Mouse+Space"));
    private final IntegerSetting keySize = setting(new IntegerSetting("Key Size", "Size of each key.", 22, 14, 40));

    private static final int KEY_PRESSED = 0x60FFFFFF;
    private static final int KEY_IDLE = 0x40000000;

    public Keystrokes() {
        super("Keystrokes", "Shows WASD and mouse button presses on screen.");
    }

    @Override
    protected void onHudRender(class_332 ctx, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        int ks = keySize.get();
        int gap = 2;
        int x = offsetX.get();
        int y = offsetY.get();

        drawKey(ctx, x + ks + gap, y, "W", client.field_1690.field_1894.method_1434(), ks);
        drawKey(ctx, x, y + ks + gap, "A", client.field_1690.field_1913.method_1434(), ks);
        drawKey(ctx, x + ks + gap, y + ks + gap, "S", client.field_1690.field_1881.method_1434(), ks);
        drawKey(ctx, x + (ks + gap) * 2, y + ks + gap, "D", client.field_1690.field_1849.method_1434(), ks);

        if (!mode.is("WASD")) {
            int my = y + (ks + gap) * 2 + 2;
            drawKey(ctx, x, my, "LMB", client.field_1690.field_1886.method_1434(), ks * 2 + gap);
            drawKey(ctx, x + (ks + gap) * 2 + gap, my, "RMB", client.field_1690.field_1904.method_1434(), ks * 2 + gap);
        }

        if (mode.is("WASD+Mouse+Space")) {
            int sy = y + (ks + gap) * 2 + (mode.is("WASD+Mouse+Space") ? ks + gap + 2 : 0) + 2;
            drawKey(ctx, x, sy, "SPACE", client.field_1690.field_1903.method_1434(), (ks + gap) * 3);
        }
    }

    private void drawKey(class_332 ctx, int x, int y, String label, boolean pressed, int width) {
        int bg = pressed ? KEY_PRESSED : KEY_IDLE;
        int border = pressed ? 0x30FFFFFF : 0x20000000;
        UiRender.fillRound(ctx, x, y, width, keySize.get(), 3, bg);
        ctx.method_25294(x, y, x + width, y + 1, border);
        var tr = class_310.method_1551().field_1772;
        int tx = x + width / 2 - tr.method_1727(label) / 2;
        int ty = y + keySize.get() / 2 - 4;
        ctx.method_51433(tr, label, tx, ty, pressed ? 0xFF000000 : 0xFFCCCCCC, true);
    }
}
