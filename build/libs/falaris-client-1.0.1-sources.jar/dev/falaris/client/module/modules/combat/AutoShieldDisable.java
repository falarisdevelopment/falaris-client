package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_746;

public final class AutoShieldDisable extends CombatModule {
    private final BooleanSetting autoSwitch = setting(new BooleanSetting("Auto Switch", "Swap to axe when target has shield.", true));
    private final BooleanSetting silentRotate = setting(new BooleanSetting("Silent Rotate", "Silently face targets.", true));
    private final BooleanSetting onlyWhenBlocking = setting(new BooleanSetting("Only When Blocking", "Only attack when target is blocking.", true));
    private final BooleanSetting requireLooking = setting(new BooleanSetting("Require Looking", "Only attack when looking at target (anti-detection).", true));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Attack range.", 3.0, 1.0, 3.0));
    private final DoubleSetting cps = setting(new DoubleSetting("CPS", "Attacks per second.", 8.0, 1.0, 20.0));
    private final IntegerSetting jitter = setting(new IntegerSetting("Delay Jitter", "Random extra ticks.", 2, 0, 8));

    public AutoShieldDisable() {
        super("AutoShieldDisable", "Auto-swaps to axe to disable enemy shields.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_1309 target = CombatUtil.bestLivingTarget(
                client, range.get(), true, true, false, false, "Angle"
        ).orElse(null);

        if (target == null) return;
        if (!(target instanceof class_1657)) return;
        if (onlyWhenBlocking.enabled() && !target.method_6039()) return;

        if (requireLooking.enabled()) {
            if (client.field_1765 == null || client.field_1765.method_17783() != class_239.class_240.field_1331) return;
            class_3966 entityHit = (class_3966) client.field_1765;
            if (entityHit.method_17782() != target) return;
        }

        if (autoSwitch.enabled()) {
            int axeSlot = findBestAxe(client.field_1724);
            if (axeSlot >= 0 && axeSlot < 9) {
                client.field_1724.method_31548().method_61496(axeSlot);
            }
        }

        if (silentRotate.enabled()) {
            float[] rots = CombatUtil.rotationsTo(client.field_1724, target.method_33571());
            var rotMgr = dev.falaris.client.FalarisClient.getInstance().getRotationManager();
            rotMgr.setMaxStep(30.0f);
            rotMgr.rotateToSilent(rots[0], rots[1], 2);
        }

        int minimumTicks = Math.max(1, (int) Math.round(20.0 / cps.get()));
        if (actionReady(minimumTicks, jitter.get())) {
            CombatUtil.attack(client, target);
        }
    }

    private int findBestAxe(class_746 player) {
        int best = -1;
        double bestScore = -1;
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = player.method_31548().method_5438(slot);
            if (stack.method_7909() instanceof class_1743) {
                double score = stack.method_7936() - stack.method_7919();
                if (score > bestScore) {
                    bestScore = score;
                    best = slot;
                }
            }
        }
        return best;
    }
}
