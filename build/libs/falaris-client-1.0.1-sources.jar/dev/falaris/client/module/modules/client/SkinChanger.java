package dev.falaris.client.module.modules.client;

import dev.falaris.client.gui.skin.SkinChangerScreen;
import dev.falaris.client.module.Category;
import dev.falaris.client.module.Module;
import net.minecraft.class_310;

public final class SkinChanger extends Module {
    public SkinChanger() {
        super("SkinChanger", "Search any player's skin and apply it to yourself.", Category.CLIENT);
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        class_310 client = class_310.method_1551();
        client.method_1507(new SkinChangerScreen());
        setEnabled(false);
    }
}
