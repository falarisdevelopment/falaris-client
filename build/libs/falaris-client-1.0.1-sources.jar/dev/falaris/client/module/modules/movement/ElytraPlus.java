package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class ElytraPlus extends MovementModule {
    private final DoubleSetting boost = setting(new DoubleSetting("Boost", "Velocity multiplier while gliding.", 1.08, 1.0, 2.5));
    private final DoubleSetting maxSpeed = setting(new DoubleSetting("Max Speed", "Maximum horizontal speed.", 2.2, 0.2, 8.0));
    private final BooleanSetting autoFirework = setting(new BooleanSetting("Auto Firework", "Uses fireworks when speed is low.", false));
    private final DoubleSetting fireworkThreshold = setting(new DoubleSetting("Firework Threshold", "Speed below which a firework is used.", 0.8, 0.1, 3.0));
    private final IntegerSetting fireworkDelay = setting(new IntegerSetting("Firework Delay", "Ticks between firework uses.", 60, 5, 200));
    private final IntegerSetting fireworkJitter = setting(new IntegerSetting("Firework Jitter", "Random extra ticks between firework uses.", 20, 0, 100));

    public ElytraPlus() {
        super("ElytraPlus", "Quality-of-life elytra boosts and optional firework assist.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null || !client.field_1724.method_6128()) {
            return;
        }

        class_243 velocity = client.field_1724.method_18798();
        class_243 horizontal = new class_243(velocity.field_1352, 0.0, velocity.field_1350).method_1021(boost.get());
        if (horizontal.method_37267() > maxSpeed.get()) {
            horizontal = horizontal.method_1029().method_1021(maxSpeed.get());
        }
        client.field_1724.method_18800(horizontal.field_1352, velocity.field_1351, horizontal.field_1350);
        client.field_1724.field_6017 = 0.0f;

        if (!autoFirework.enabled() || horizontal.method_37267() > fireworkThreshold.get()) {
            return;
        }

        int slot = MovementUtil.findItem(client.field_1724, class_1802.field_8639);
        if (slot != -1 && client.field_1761 != null && ready(fireworkDelay.get(), fireworkJitter.get())) {
            MovementUtil.selectSlot(client.field_1724, slot);
            client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
            client.field_1724.method_6104(class_1268.field_5808);
        }
    }
}
