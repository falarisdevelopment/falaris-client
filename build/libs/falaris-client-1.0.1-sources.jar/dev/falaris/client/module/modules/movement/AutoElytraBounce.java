package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_310;

public final class AutoElytraBounce extends MovementModule {
    private final DoubleSetting boostVertical = setting(new DoubleSetting("Boost Vertical", "Upward velocity when bouncing.", 1.5, 0.5, 4.0));
    private final DoubleSetting boostHorizontal = setting(new DoubleSetting("Boost Horizontal", "Forward velocity when bouncing.", 1.0, 0.0, 3.0));
    private final IntegerSetting minHeight = setting(new IntegerSetting("Min Height", "Minimum Y level to bounce.", 60, 0, 256));

    private boolean wasBouncing;

    public AutoElytraBounce() {
        super("AutoElytraBounce", "Automatically bounces upward when flying with elytra near the ground.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (client.field_1724.method_31549().field_7479) {
            wasBouncing = false;
            return;
        }

        if (client.field_1724.method_23318() > minHeight.get()) return;

        if (client.field_1724.field_5976 || client.field_1724.field_5992) {
            if (!wasBouncing) {
                client.field_1724.method_18800(
                    client.field_1724.method_18798().field_1352 * 0.5 + client.field_1724.method_5720().field_1352 * boostHorizontal.get(),
                    boostVertical.get(),
                    client.field_1724.method_18798().field_1350 * 0.5 + client.field_1724.method_5720().field_1350 * boostHorizontal.get()
                );
                wasBouncing = true;
            }
        } else {
            wasBouncing = false;
        }
    }
}
