package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1802;
import net.minecraft.class_1819;
import net.minecraft.class_310;

public final class AutoShield extends CombatModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Blocking behavior.", "Always", "Always", "On Target", "When Hurt"));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between offhand swaps.", 2, 1, 10));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks.", 1, 0, 5));
    private final BooleanSetting autoEquip = setting(new BooleanSetting("Auto Equip", "Move shield to offhand automatically.", true));
    private final BooleanSetting keepShield = setting(new BooleanSetting("Keep Shield", "Don't unblock when using items.", false));

    private boolean wasBlocking;
    private int offhandTries;

    public AutoShield() {
        super("AutoShield", "Automatically blocks with a shield and keeps it equipped.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (autoEquip.enabled() && !isShieldInOffhand(client)) {
            if (offhandTries > 0) {
                offhandTries--;
                return;
            }
            int shieldSlot = findShield(client);
            if (shieldSlot != -1) {
                if (actionReady(delay.get(), jitter.get())) {
                    int screenSlot = shieldSlot >= 36 ? shieldSlot : dev.falaris.client.module.modules.player.InventoryUtil.screenSlotForInventoryIndex(shieldSlot);
                    dev.falaris.client.module.modules.player.InventoryUtil.clickMove(client, screenSlot, 45);
                    offhandTries = 5;
                }
            }
            return;
        }

        boolean shouldBlock = shouldBlock(client);
        if (shouldBlock && !wasBlocking) {
            if (isShieldInOffhand(client) || isShieldInMainHand(client)) {
                client.field_1690.field_1904.method_23481(true);
                wasBlocking = true;
            }
        } else if (!shouldBlock && wasBlocking) {
            client.field_1690.field_1904.method_23481(false);
            wasBlocking = false;
        }
    }

    private boolean shouldBlock(class_310 client) {
        if (client.field_1724.method_6115() && !keepShield.enabled()) return false;
        if (mode.is("Always")) return true;
        if (mode.is("On Target")) {
            return client.field_1765 != null && client.field_1765.method_17783() == net.minecraft.class_239.class_240.field_1331;
        }
        return client.field_1724.field_6235 > 0;
    }

    private boolean isShieldInOffhand(class_310 client) {
        return client.field_1724.method_6079().method_7909() instanceof class_1819;
    }

    private boolean isShieldInMainHand(class_310 client) {
        return client.field_1724.method_6047().method_7909() instanceof class_1819;
    }

    private int findShield(class_310 client) {
        for (int i = 0; i < 36; i++) {
            if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8255)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1690.field_1904.method_23481(false);
        }
        wasBlocking = false;
        offhandTries = 0;
    }
}
