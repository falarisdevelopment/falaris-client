package dev.falaris.client.module.modules.combat;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.module.Module;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import dev.falaris.client.tick.TimerManager;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class TickBase extends CombatModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Tick advancement mode.", "FUTURE", "PAST", "FUTURE"));
    private final IntegerSetting maxTicks = setting(new IntegerSetting("Max Ticks", "Max ticks to advance.", 3, 1, 10));
    private final IntegerSetting balanceLimit = setting(new IntegerSetting("Balance Limit", "Max timer excess before compensating.", 5, 1, 20));

    private int pendingTicks;
    private int tickBalance;
    private boolean isAdvancing;
    private boolean requestAttack;

    public TickBase() {
        super("TickBase", "Manipulates game ticks for better attack timing.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        pendingTicks = 0;
        tickBalance = 0;
        isAdvancing = false;
        requestAttack = false;
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        TimerManager.getInstance().release(this);
        pendingTicks = 0;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (isAdvancing) {
            if (pendingTicks > 0) {
                TimerManager.getInstance().requestSpeed(this, 5.0f, 10);
                tickBalance--;
                pendingTicks--;
            } else {
                TimerManager.getInstance().release(this);
                isAdvancing = false;
                if (requestAttack) {
                    requestAttack = false;
                }
            }
            return;
        }

        if (tickBalance < -balanceLimit.get()) {
            TimerManager.getInstance().requestSpeed(this, 0.5f, 10);
            tickBalance++;
        } else if (hasRequests()) {
            TimerManager.getInstance().release(this);
        }
    }

    public boolean shouldTickAdvance(class_1309 target) {
        if (!isEnabled() || target == null) return false;
        if (tickBalance < -balanceLimit.get() * 2) return false;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return false;

        double dist = client.field_1724.method_5858(target);
        int ticks = 0;
        class_243 vel = client.field_1724.method_18798();
        double px = client.field_1724.method_23317(), py = client.field_1724.method_23318(), pz = client.field_1724.method_23321();
        double tx = target.method_23317(), ty = target.method_23318(), tz = target.method_23321();

        for (int i = 0; i < maxTicks.get(); i++) {
            px += vel.field_1352;
            pz += vel.field_1350;
            py += vel.field_1351;
            vel = vel.method_1031(0, -0.08, 0);
            vel = vel.method_1021(0.98);
            double nd = new class_243(px, py, pz).method_1025(new class_243(tx, ty, tz));
            if (nd < dist) { ticks = i + 1; break; }
        }

        if (ticks > 0) {
            pendingTicks = ticks;
            isAdvancing = true;
            tickBalance += ticks;
            return true;
        }
        return false;
    }

    public int getTickBalance() { return tickBalance; }
    public boolean isAdvancing() { return isAdvancing; }

    private boolean hasRequests() {
        return FalarisClient.getInstance().getModuleManager().find("killaura")
            .filter(Module::isEnabled).isPresent();
    }
}
