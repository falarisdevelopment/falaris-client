package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class Surround extends CombatModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Surround placement mode.", "Full", "Full", "Single", "AntiFacePlace"));
    private final ModeSetting blockType = setting(new ModeSetting("Block Type", "Block to place.", "Obsidian", "Obsidian", "Crying Obsidian", "Netherite Block", "End Stone", "Any BlockItem"));
    private final BooleanSetting floor = setting(new BooleanSetting("Floor", "Also place a block below you.", true));
    private final BooleanSetting center = setting(new BooleanSetting("Center", "Center player on block before placing.", true));
    private final BooleanSetting toggleAfterPlace = setting(new BooleanSetting("Toggle After Place", "Disable after blocks placed.", false));
    private final BooleanSetting onlyMissing = setting(new BooleanSetting("Only Missing", "Only place where blocks are missing.", true));
    private final IntegerSetting placeDelay = setting(new IntegerSetting("Place Delay", "Ticks between block placements.", 1, 0, 10));
    private final IntegerSetting blocksPerTick = setting(new IntegerSetting("Blocks Per Tick", "Max blocks to place per tick.", 2, 1, 8));

    private int tickCounter;
    private boolean centered;

    public Surround() {
        super("Surround", "Places blocks around your feet to protect from crystal explosions etc.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        centered = false;
        tickCounter = 0;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        if (center.enabled() && !centered) {
            centerPlayer(client);
            centered = true;
        }

        tickCounter++;
        if (tickCounter < placeDelay.get() + 1) return;
        tickCounter = 0;

        int placed = 0;
        for (class_2338 pos : getTargetPositions(client)) {
            if (placed >= blocksPerTick.get()) break;
            if (tryPlace(client, pos)) {
                placed++;
            }
        }

        if (toggleAfterPlace.enabled() && placed > 0 && isComplete(client)) {
            setEnabled(false);
        }
    }

    private Set<class_2338> getTargetPositions(class_310 client) {
        class_2338 feet = client.field_1724.method_24515();
        Set<class_2338> targets = new HashSet<>();

        switch (mode.get()) {
            case "Full" -> {
                targets.add(feet.method_10095());
                targets.add(feet.method_10072());
                targets.add(feet.method_10078());
                targets.add(feet.method_10067());
                targets.add(feet.method_10095().method_10078());
                targets.add(feet.method_10095().method_10067());
                targets.add(feet.method_10072().method_10078());
                targets.add(feet.method_10072().method_10067());
            }
            case "Single" -> {
                for (class_2350 dir : class_2350.class_2353.field_11062) {
                    class_2338 offset = feet.method_10093(dir);
                    if (client.field_1687.method_8320(offset).method_26215()) {
                        targets.add(offset);
                        break;
                    }
                }
            }
            case "AntiFacePlace" -> {
                targets.add(feet.method_10095());
                targets.add(feet.method_10072());
                targets.add(feet.method_10078());
                targets.add(feet.method_10067());
            }
        }

        if (floor.enabled()) {
            targets.add(feet.method_10074());
        }
        return targets;
    }

    private boolean tryPlace(class_310 client, class_2338 pos) {
        if (!client.field_1687.method_8320(pos).method_26215() && !client.field_1687.method_8320(pos).method_45474()) return false;
        if (onlyMissing.enabled()) {
            if (!client.field_1687.method_8320(pos).method_26215()) return false;
        }

        int slot = findBlock(client);
        if (slot < 0) return false;
        client.field_1724.method_31548().method_61496(slot);

        for (class_2350 dir : class_2350.values()) {
            class_2338 neighbor = pos.method_10093(dir);
            if (!client.field_1687.method_8320(neighbor).method_26215()) {
                class_243 hit = class_243.method_24953(neighbor).method_1019(class_243.method_24954(dir.method_10153().method_62675()).method_1021(0.5));
                class_3965 result = new class_3965(hit, dir.method_10153(), neighbor, false);
                client.field_1761.method_2896(client.field_1724, class_1268.field_5808, result);
                client.field_1724.method_6104(class_1268.field_5808);
                return true;
            }
        }
        return false;
    }

    private int findBlock(class_310 client) {
        String bt = blockType.get();
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(slot);
            if (bt.equals("Obsidian") && stack.method_31574(class_1802.field_8281)) return slot;
            if (bt.equals("Crying Obsidian") && stack.method_31574(class_1802.field_22421)) return slot;
            if (bt.equals("Netherite Block") && stack.method_31574(class_1802.field_22018)) return slot;
            if (bt.equals("End Stone") && stack.method_31574(class_1802.field_20399)) return slot;
        }
        if (bt.equals("Any BlockItem")) {
            for (int slot = 0; slot < 9; slot++) {
                class_1799 stack = client.field_1724.method_31548().method_5438(slot);
                if (stack.method_7909() instanceof net.minecraft.class_1747) return slot;
            }
        }
        // Fallback: find obsidian or any block
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(slot);
            if (stack.method_31574(class_1802.field_8281)) return slot;
        }
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(slot);
            if (stack.method_7909() instanceof net.minecraft.class_1747) return slot;
        }
        return -1;
    }

    private boolean isComplete(class_310 client) {
        for (class_2338 pos : getTargetPositions(client)) {
            if (client.field_1687.method_8320(pos).method_26215()) return false;
        }
        return true;
    }

    private void centerPlayer(class_310 client) {
        class_2338 feet = client.field_1724.method_24515();
        double x = feet.method_10263() + 0.5;
        double z = feet.method_10260() + 0.5;
        client.field_1724.method_5814(x, client.field_1724.method_23318(), z);
    }
}
