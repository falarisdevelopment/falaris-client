package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class IAmInnocent extends PlayerModule {
    private final BooleanSetting autoHide = setting(new BooleanSetting("Auto Hide", "Automatically hide flagged map art.", true));
    private final BooleanSetting blurTextures = setting(new BooleanSetting("Blur Textures", "Blur hidden textures instead of skipping.", false));
    private final ModeSetting detectionMode = setting(new ModeSetting("Detection Mode", "What to hide.", "All", "All", "Map Art", "Player Skins"));
    private final BooleanSetting showNotification = setting(new BooleanSetting("Show Notification", "Chat log when hiding something.", false));

    public IAmInnocent() {
        super("IAmInnocent", "Hides NSFW map art and player skins from view.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return;
        if (!autoHide.enabled()) return;

        if (detectionMode.is("Map Art") || detectionMode.is("All")) {
            for (var entity : client.field_1687.method_18112()) {
                if (client.field_1724.method_5858(entity) < 144.0) {
                    String name = entity.method_5477().getString().toLowerCase();
                    if (name.contains("map") || name.contains("art")) {
                        if (showNotification.enabled()) {
                            client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§7[Innocent] Hid entity §e" + entity.method_5477().getString()), false);
                        }
                        handleMapEntity(client, entity);
                    }
                }
            }

            if (client.field_1724.method_6047().method_31574(class_1802.field_8204) || client.field_1724.method_6079().method_31574(class_1802.field_8204)) {
                if (showNotification.enabled()) {
                    client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§7[Innocent] Hiding map in hand"), false);
                }
            }
        }

        if (detectionMode.is("Player Skins") || detectionMode.is("All")) {
            for (var player : client.field_1687.method_18456()) {
                if (player == client.field_1724) continue;
                if (client.field_1724.method_5858(player) < 144.0) {
                    checkPlayerSkin(client, player);
                }
            }
        }
    }

    private void handleMapEntity(class_310 client, net.minecraft.class_1297 entity) {
        client.field_1687.method_2945(entity.method_5628(), net.minecraft.class_1297.class_5529.field_26999);
    }

    private void checkPlayerSkin(class_310 client, net.minecraft.class_1657 player) {
        if (showNotification.enabled()) {
            client.field_1724.method_7353(net.minecraft.class_2561.method_43470("§7[Innocent] Checked §e" + player.method_5477().getString()), false);
        }
    }
}
