package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_408;
import net.minecraft.class_746;
import net.minecraft.class_7923;

public final class Baritone extends MiscModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Bot operation.", "Idle", "Idle", "Mine", "Goto"));
    private final BooleanSetting autoTool = setting(new BooleanSetting("Auto Tool", "Use best tool for blocks.", true));
    private final BooleanSetting breakBlocks = setting(new BooleanSetting("Break Blocks", "Break blocks in the way.", true));
    private final DoubleSetting speed = setting(new DoubleSetting("Speed", "Movement speed.", 0.5, 0.1, 1.5));

    private class_2338 targetPos;
    private class_2248 targetBlock;
    private List<class_2338> path;
    private int pathIndex;
    private boolean moving;
    private class_408 lastChatScreen;
    private boolean wasChatOpen;

    public Baritone() {
        super("Baritone", "Basic A* pathfinder with #mine/#goto/#stop chat commands. NOT the real Baritone library — this is a lightweight alternative.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        targetPos = null;
        path = null;
        moving = false;
        lastChatScreen = null;
        wasChatOpen = false;
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        // Detect chat close and intercept #commands
        boolean chatOpen = client.field_1755 instanceof class_408;
        if (chatOpen) {
            lastChatScreen = (class_408) client.field_1755;
        }
        if (wasChatOpen && !chatOpen && lastChatScreen != null) {
            String text = getChatText(lastChatScreen);
            if (text != null && text.startsWith("#")) {
                executeCommand(text.substring(1).trim());
            }
            lastChatScreen = null;
        }
        wasChatOpen = chatOpen;

        // Movement
        if (!moving || path == null) return;

        if (pathIndex >= path.size()) {
            if (mode.is("Mine") && targetBlock != null && targetPos != null) {
                mineBlock(client, targetPos);
                if (client.field_1687.method_8320(targetPos).method_26215()) {
                    targetPos = findNearestBlock(targetBlock);
                    if (targetPos != null) {
                        path = pathfind(targetPos);
                        pathIndex = 0;
                        msg("Next target at " + targetPos.method_23854());
                    } else {
                        msg("Mining complete.");
                        stop();
                    }
                }
            } else {
                stop();
                msg("Arrived.");
            }
            return;
        }

        class_2338 next = path.get(pathIndex);
        double dist = client.field_1724.method_5707(class_243.method_24953(next));

        if (dist < 1.5) {
            pathIndex++;
            return;
        }

        if (breakBlocks.enabled()) {
            class_2338 head = client.field_1724.method_24515().method_10084();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    class_2338 check = head.method_10069(dx, 0, dz);
                    class_2680 bs = client.field_1687.method_8320(check);
                    if (!bs.method_26215() && bs.method_26204().method_36555() >= 0) {
                        mineBlock(client, check);
                        return;
                    }
                }
            }
        }

        float[] rots = rotationsTo(client.field_1724, class_243.method_24953(next));
        client.field_1724.method_36456(rots[0]);
        client.field_1724.method_36457(rots[1]);

        client.field_1690.field_1894.method_23481(true);
        client.field_1724.method_5728(true);

        if (client.field_1724.method_24828() && !client.field_1687.method_8320(next).method_26215()) {
            client.field_1724.method_6043();
        }

        class_243 vel = client.field_1724.method_5720().method_1021(speed.get());
        client.field_1724.method_18800(vel.field_1352, client.field_1724.method_18798().field_1351, vel.field_1350);
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        stop();
    }

    private String getChatText(class_408 chat) {
        try {
            // Try Yarn field name (chatField)
            for (Field f : class_408.class.getDeclaredFields()) {
                f.setAccessible(true);
                Object val = f.get(chat);
                if (val instanceof class_342 tfw) {
                    String t = tfw.method_1882();
                    if (t != null && !t.isEmpty()) return t;
                }
            }
            // Try Mojmap field name (input)
            Field inputField = class_408.class.getField("input");
            inputField.setAccessible(true);
            Object val = inputField.get(chat);
            if (val != null) {
                var m = val.getClass().getMethod("getText");
                return (String) m.invoke(val);
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void executeCommand(String cmd) {
        String[] parts = cmd.split("\\s+", 2);
        if (parts.length == 0) return;
        switch (parts[0].toLowerCase()) {
            case "mine" -> {
                if (parts.length < 2) { msg("Usage: #mine <block_id>"); return; }
                class_2248 block = parseBlock(parts[1]);
                if (block == null) { msg("Unknown block: " + parts[1]); return; }
                targetBlock = block;
                mode.set("Mine");
                targetPos = findNearestBlock(block);
                if (targetPos == null) { msg("No " + parts[1] + " found nearby."); return; }
                msg("Mining " + parts[1] + " at " + targetPos.method_23854());
                path = pathfind(targetPos);
                pathIndex = 0;
                moving = true;
            }
            case "goto" -> {
                if (parts.length < 2) { msg("Usage: #goto <x> <z>"); return; }
                String[] coords = parts[1].split("\\s+");
                if (coords.length < 2) { msg("Usage: #goto <x> <z>"); return; }
                try {
                    double gx = Double.parseDouble(coords[0]);
                    double gz = Double.parseDouble(coords[1]);
                    targetPos = class_2338.method_49637(gx, class_310.method_1551().field_1724.method_23318(), gz);
                    mode.set("Goto");
                    path = pathfind(targetPos);
                    pathIndex = 0;
                    moving = true;
                    msg("Navigating to " + targetPos.method_23854());
                } catch (NumberFormatException e) {
                    msg("Invalid coordinates.");
                }
            }
            case "stop" -> {
                stop();
                msg("Bot stopped.");
            }
            case "come" -> {
                targetPos = class_310.method_1551().field_1724.method_24515().method_10069(5, 0, 5);
                mode.set("Goto");
                path = pathfind(targetPos);
                pathIndex = 0;
                moving = true;
                msg("Coming...");
            }
            default -> msg("Unknown: " + parts[0] + ". Commands: #mine, #goto, #stop, #come");
        }
    }

    private void stop() {
        moving = false;
        path = null;
        targetPos = null;
        mode.set("Idle");
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1690.field_1894.method_23481(false);
        }
    }

    private class_2248 parseBlock(String input) {
        String id = input.contains(":") ? input : "minecraft:" + input;
        return class_7923.field_41175.method_63535(class_2960.method_60654(id));
    }

    private class_2338 findNearestBlock(class_2248 block) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return null;
        class_2338 origin = client.field_1724.method_24515();
        class_2338 best = null;
        double bestDist = Double.MAX_VALUE;
        for (int r = 0; r <= 64; r++) {
            for (class_2338 pos : class_2338.method_25996(origin, r, r, r)) {
                if (Math.abs(pos.method_10263()) + Math.abs(pos.method_10264()) + Math.abs(pos.method_10260()) != r) continue;
                if (client.field_1687.method_8320(pos).method_27852(block) && client.field_1687.method_8320(pos.method_10084()).method_26215()) {
                    double d = client.field_1724.method_5707(class_243.method_24953(pos));
                    if (d < bestDist) {
                        bestDist = d;
                        best = pos.method_10062();
                    }
                }
            }
            if (best != null) return best;
        }
        return null;
    }

    private List<class_2338> pathfind(class_2338 target) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return List.of(target);

        class_2338 start = client.field_1724.method_24515();
        if (start.equals(target)) return List.of(target);

        Set<class_2338> visited = new HashSet<>();
        PriorityQueue<Node> open = new PriorityQueue<>(
            Comparator.comparingDouble(n -> n.cost + Math.sqrt(n.pos.method_10262(target)))
        );
        open.add(new Node(start, null, 0));

        int maxNodes = 3000;

        while (!open.isEmpty()) {
            Node current = open.poll();
            if (!visited.add(current.pos)) continue;

            if (current.pos.method_19771(target, 2.0)) {
                return reconstructPath(current);
            }
            if (visited.size() > maxNodes) break;

            exploreNeighbor(open, current, current.pos.method_10069(1, 0, 0), 1.0);
            exploreNeighbor(open, current, current.pos.method_10069(-1, 0, 0), 1.0);
            exploreNeighbor(open, current, current.pos.method_10069(0, 0, 1), 1.0);
            exploreNeighbor(open, current, current.pos.method_10069(0, 0, -1), 1.0);
            exploreNeighbor(open, current, current.pos.method_10069(0, 1, 0), 2.0);
            exploreNeighbor(open, current, current.pos.method_10069(0, -1, 0), 2.0);
        }

        return List.of(target);
    }

    private void exploreNeighbor(PriorityQueue<Node> open, Node current, class_2338 next, double addCost) {
        if (!isWalkable(next)) return;
        open.add(new Node(next, current, current.cost + addCost));
    }

    private boolean isWalkable(class_2338 pos) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return false;
        class_2680 feet = client.field_1687.method_8320(pos);
        return feet.method_26215() || feet.method_26204().method_36555() >= 0;
    }

    private List<class_2338> reconstructPath(Node node) {
        List<class_2338> result = new ArrayList<>();
        Node n = node;
        while (n != null) {
            result.add(0, n.pos);
            n = n.parent;
        }
        return result;
    }

    private void mineBlock(class_310 client, class_2338 pos) {
        if (client.field_1761 == null) return;
        if (autoTool.enabled()) {
            int slot = findBestTool(client, pos);
            if (slot >= 0) client.field_1724.method_31548().method_61496(slot);
        }
        client.field_1761.method_2910(pos, class_2350.field_11036);
        client.field_1724.method_6104(class_1268.field_5808);
    }

    private int findBestTool(class_310 client, class_2338 pos) {
        class_2680 state = client.field_1687.method_8320(pos);
        int best = -1;
        float bestSpeed = 1.0f;
        for (int slot = 0; slot < 9; slot++) {
            float speed = client.field_1724.method_31548().method_5438(slot).method_7924(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                best = slot;
            }
        }
        return best;
    }

    private static float[] rotationsTo(class_746 player, class_243 target) {
        class_243 eyes = player.method_33571();
        double dx = target.field_1352 - eyes.field_1352;
        double dy = target.field_1351 - eyes.field_1351;
        double dz = target.field_1350 - eyes.field_1350;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) class_3532.method_15338(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horiz));
        return new float[]{yaw, class_3532.method_15363(pitch, -90.0f, 90.0f)};
    }

    private void msg(String text) {
        class_310 c = class_310.method_1551();
        if (c.field_1724 != null) {
            c.field_1724.method_7353(net.minecraft.class_2561.method_43470("§7[§bBaritone§7] §f" + text), false);
        }
    }

    private record Node(class_2338 pos, Node parent, double cost) {}
}
