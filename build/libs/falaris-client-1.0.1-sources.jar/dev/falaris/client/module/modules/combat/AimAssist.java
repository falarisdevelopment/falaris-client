package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class AimAssist extends CombatModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum assist distance.", 5.5, 1.0, 10.0));
    private final DoubleSetting fov = setting(new DoubleSetting("FOV", "Maximum angle from crosshair.", 55.0, 5.0, 180.0));
    private final DoubleSetting strength = setting(new DoubleSetting("Strength", "Assist rotation speed.", 6.0, 0.5, 30.0));
    private final ModeSetting priority = setting(new ModeSetting("Priority", "Target sorting mode.", "Angle", "Distance", "Health", "Angle"));
    private final BooleanSetting requireAttack = setting(new BooleanSetting("Require Attack", "Only assist while the attack key is held.", true));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Target players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Target hostile mobs.", true));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Target passive mobs.", false));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Allow targets without line of sight.", false));
    private final BooleanSetting focusBlocks = setting(new BooleanSetting("Focus Blocks", "Aim at the block you are mining.", false));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anticheat bypass.", "Vanilla", "Vanilla", "Legit", "Grim"));

    private final Random random = new Random();

    public AimAssist() {
        super("AimAssist", "Smoothly adjusts your aim toward nearby targets.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) return;
        if (requireAttack.enabled() && !client.field_1690.field_1886.method_1434()) return;

        if (focusBlocks.enabled()) {
            handleBlockFocus(client);
            return;
        }

        class_1309 target = CombatUtil.bestLivingTarget(
                client, range.get(),
                players.enabled(), hostiles.enabled(), passives.enabled(),
                throughWalls.enabled(), priority.get()
        ).filter(entity -> CombatUtil.angleTo(client.field_1724, entity.method_33571()) <= fov.get()).orElse(null);

        if (target == null) return;

        float[] rots = CombatUtil.rotationsTo(client.field_1724, target.method_33571());

        if (bypass.is("Legit") || bypass.is("Grim")) {
            if (random.nextFloat() < 0.20f) return;
            rots[0] += (random.nextFloat() - 0.5f) * 3.0f;
            rots[1] += (random.nextFloat() - 0.5f) * 1.5f;
        }

        float strengthVal = strength.get().floatValue();

        float yawDelta = class_3532.method_15393(rots[0] - client.field_1724.method_36454());
        float pitchDelta = rots[1] - client.field_1724.method_36455();

        float yawStep = class_3532.method_15363(yawDelta / 3.0f, -strengthVal, strengthVal);
        float pitchStep = class_3532.method_15363(pitchDelta / 3.0f, -strengthVal * 0.6f, strengthVal * 0.6f);

        if (Math.abs(yawDelta) > 0.5f || Math.abs(pitchDelta) > 0.5f) {
            client.field_1724.method_36456(client.field_1724.method_36454() + yawStep);
            client.field_1724.method_36457(class_3532.method_15363(client.field_1724.method_36455() + pitchStep, -90.0f, 90.0f));
        }
    }

    private void handleBlockFocus(class_310 client) {
        try {
            java.lang.reflect.Field field = client.field_1761.getClass().getDeclaredField("currentBreakingPos");
            field.setAccessible(true);
            net.minecraft.class_2338 breakingPos = (net.minecraft.class_2338) field.get(client.field_1761);
            if (breakingPos == null && client.field_1765 != null && client.field_1765.method_17783() == class_239.class_240.field_1332) {
                breakingPos = ((net.minecraft.class_3965) client.field_1765).method_17777();
            }
            if (breakingPos != null && !client.field_1687.method_8320(breakingPos).method_26215()) {
                float[] rots = CombatUtil.rotationsTo(client.field_1724, breakingPos.method_46558());
                float yawDelta = class_3532.method_15393(rots[0] - client.field_1724.method_36454());
                float pitchDelta = rots[1] - client.field_1724.method_36455();
                float strengthVal = strength.get().floatValue();
                client.field_1724.method_36456(client.field_1724.method_36454() + class_3532.method_15363(yawDelta / 3.0f, -strengthVal, strengthVal));
                client.field_1724.method_36457(class_3532.method_15363(client.field_1724.method_36455() + class_3532.method_15363(pitchDelta / 3.0f, -strengthVal, strengthVal), -90.0f, 90.0f));
            }
        } catch (Exception ignored) {}
    }
}
