package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class AutoPearlCatch extends PlayerModule {
    private final BooleanSetting pearlDive = setting(new BooleanSetting("Pearl Dive", "Pearl then wind charge for speed.", true));
    private final IntegerSetting windChargeDelay = setting(new IntegerSetting("Wind Charge Delay", "Ticks between pearl and wind charge.", 6, 2, 15));
    private final BooleanSetting lookUp = setting(new BooleanSetting("Look Up", "Look straight up before throwing.", true));
    private final BooleanSetting lookBackDown = setting(new BooleanSetting("Look Back Down", "Return pitch after pearl throw.", true));
    private final IntegerSetting cooldown = setting(new IntegerSetting("Cooldown", "Ticks between combos.", 25, 0, 100));
    private final BooleanSetting autoActivate = setting(new BooleanSetting("Auto Activate", "Auto when holding pearl + looking up.", false));
    private final BooleanSetting elytraSafe = setting(new BooleanSetting("Elytra Safe", "Don't activate while using elytra.", true));
    private final BooleanSetting chasePlayers = setting(new BooleanSetting("Chase Players", "Auto-target players with pearls.", false));
    private final BooleanSetting autoSlamCompat = setting(new BooleanSetting("AutoSlam Compat", "Don't interfere with AutoSlam.", true));
    private final IntegerSetting chaseRange = setting(new IntegerSetting("Chase Range", "Distance to target players.", 20, 5, 50));

    private enum Phase { IDLE, LOOK_UP, PEARL, WAIT, CHARGE, LOOK_DOWN }
    private Phase phase = Phase.IDLE;
    private int tickCounter;
    private int cooldownCounter;
    private float prevPitch;

    public AutoPearlCatch() {
        super("AutoPearlCatch", "Pearl + wind charge combo for fast travel, with player chase.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        phase = Phase.IDLE;
        tickCounter = 0;
        cooldownCounter = 0;
        prevPitch = 0;
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (cooldownCounter < cooldown.get()) {
            cooldownCounter++;
            return;
        }

        if (elytraSafe.enabled() && client.field_1724.method_6128()) return;

        switch (phase) {
            case IDLE -> {
                boolean shouldActivate = false;

                if (chasePlayers.enabled()) {
                    shouldActivate = findTargetPlayer(client) != null;
                }

                if (!shouldActivate && autoActivate.enabled()) {
                    boolean holdingPearl = client.field_1724.method_6047().method_31574(class_1802.field_8634)
                        || client.field_1724.method_6079().method_31574(class_1802.field_8634);
                    boolean lookingUp = client.field_1724.method_36455() < -75.0f;
                    shouldActivate = holdingPearl && lookingUp;
                }

                if (!shouldActivate) {
                    shouldActivate = client.field_1690.field_1904.method_1434();
                }

                if (pearlDive.enabled() && shouldActivate) {
                    int pearlSlot = findItem(client.field_1724, class_1802.field_8634);
                    if (pearlSlot >= 0) {
                        prevPitch = client.field_1724.method_36455();
                        if (lookUp.enabled()) {
                            client.field_1724.method_36457(-90.0f);
                            phase = Phase.LOOK_UP;
                            tickCounter = 0;
                        } else {
                            doPearlThrow(client, pearlSlot);
                            phase = Phase.WAIT;
                            tickCounter = 0;
                        }
                    }
                }
            }
            case LOOK_UP -> {
                tickCounter++;
                if (tickCounter >= 2) {
                    int pearlSlot = findItem(client.field_1724, class_1802.field_8634);
                    if (pearlSlot >= 0) {
                        doPearlThrow(client, pearlSlot);
                    }
                    phase = Phase.WAIT;
                    tickCounter = 0;
                }
            }
            case WAIT -> {
                tickCounter++;
                if (tickCounter >= windChargeDelay.get()) {
                    int windSlot = findItem(client.field_1724, class_1802.field_49098);
                    if (windSlot >= 0 && windSlot < 9) {
                        client.field_1724.method_31548().method_61496(windSlot);
                        client.field_1761.method_2919(client.field_1724, net.minecraft.class_1268.field_5808);
                    }
                    if (lookBackDown.enabled()) {
                        phase = Phase.LOOK_DOWN;
                        tickCounter = 0;
                    } else {
                        phase = Phase.IDLE;
                        cooldownCounter = 0;
                    }
                }
            }
            case LOOK_DOWN -> {
                tickCounter++;
                float target = Math.max(prevPitch, 30.0f);
                float step = (target - client.field_1724.method_36455()) / Math.max(1, 5 - tickCounter);
                client.field_1724.method_36457(client.field_1724.method_36455() + step);
                if (tickCounter >= 5 || Math.abs(client.field_1724.method_36455() - target) < 5.0f) {
                    client.field_1724.method_36457(target);
                    phase = Phase.IDLE;
                    cooldownCounter = 0;
                }
            }
        }
    }

    private void doPearlThrow(class_310 client, int slot) {
        if (slot < 9) {
            client.field_1724.method_31548().method_61496(slot);
        }
        client.field_1761.method_2919(client.field_1724, net.minecraft.class_1268.field_5808);
    }

    private net.minecraft.class_1657 findTargetPlayer(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return null;
        double best = chaseRange.get() * chaseRange.get();
        net.minecraft.class_1657 bestTarget = null;
        for (var player : client.field_1687.method_18456()) {
            if (player == client.field_1724 || player.method_29504()) continue;
            double dist = client.field_1724.method_5858(player);
            if (dist < best) {
                best = dist;
                bestTarget = player;
            }
        }
        return bestTarget;
    }

    private int findItem(class_746 player, net.minecraft.class_1792 item) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.method_31548().method_5438(slot).method_31574(item)) return slot;
        }
        return -1;
    }
}
