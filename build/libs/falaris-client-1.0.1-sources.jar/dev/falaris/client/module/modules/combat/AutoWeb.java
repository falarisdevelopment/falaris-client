package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public final class AutoWeb extends CombatModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Web placement mode.", "Single", "Single", "Surround", "Trap"));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Max distance to target.", 4.5, 1.0, 6.0));
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Range to find targets.", 6.0, 1.0, 12.0));
    private final IntegerSetting placeDelay = setting(new IntegerSetting("Place Delay", "Ticks between placements.", 2, 0, 10));
    private final BooleanSetting autoSwitch = setting(new BooleanSetting("Auto Switch", "Auto-switch to webs in hotbar.", true));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Face block being placed.", true));
    private final BooleanSetting toggleAfterPlace = setting(new BooleanSetting("Toggle After Place", "Disable after placing.", false));
    private final ModeSetting targetMode = setting(new ModeSetting("Target Mode", "Who to web.", "Nearest", "Nearest", "Crosshair", "Combat Target"));

    private int tickCounter;
    private final Random random = new Random();

    public AutoWeb() {
        super("AutoWeb", "Automatically places webs on your opponent to trap them.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        tickCounter++;
        if (tickCounter < placeDelay.get() + random.nextInt(2)) return;
        tickCounter = 0;

        class_1309 target = findTarget(client);
        if (target == null) return;

        Set<class_2338> positions = getWebPositions(client, target);
        if (positions.isEmpty()) return;

        int webSlot = findWebs(client);
        if (webSlot < 0) {
            if (!autoSwitch.enabled()) return;
            // Try to find any slot with webs
            webSlot = findWebs(client);
            if (webSlot < 0) return;
        }

        if (autoSwitch.enabled()) {
            client.field_1724.method_31548().method_61496(webSlot);
        }

        for (class_2338 pos : positions) {
            if (!client.field_1687.method_8320(pos).method_26215()) continue;
            if (client.field_1724.method_5707(class_243.method_24953(pos)) > range.get() * range.get()) continue;

            if (rotate.enabled()) {
                float[] rots = CombatUtil.rotationsTo(client.field_1724, class_243.method_24953(pos));
                rotations().setMaxStep(25.0f);
                rotations().rotateTo(rots[0], rots[1], 2);
            }

            for (class_2350 dir : class_2350.values()) {
                class_2338 neighbor = pos.method_10093(dir);
                if (!client.field_1687.method_8320(neighbor).method_26215()) {
                    class_243 hit = class_243.method_24953(neighbor).method_1019(class_243.method_24954(dir.method_10153().method_62675()).method_1021(0.5));
                    class_3965 result = new class_3965(hit, dir.method_10153(), neighbor, false);
                    client.field_1761.method_2896(client.field_1724, class_1268.field_5808, result);
                    client.field_1724.method_6104(class_1268.field_5808);
                    break;
                }
            }

            if (toggleAfterPlace.enabled()) {
                setEnabled(false);
                return;
            }
            break;
        }
    }

    private class_1309 findTarget(class_310 client) {
        if (targetMode.is("Crosshair")) {
            if (client.field_1765 instanceof class_3966 hit && hit.method_17783() == class_239.class_240.field_1331) {
                if (hit.method_17782() instanceof class_1309 le && le != client.field_1724) return le;
            }
            return null;
        }
        if (targetMode.is("Combat Target")) {
            // Check if KillAura or similar has a target
            var opt = CombatUtil.bestLivingTarget(client, targetRange.get(), true, true, false, false, "Distance");
            return opt.orElse(null);
        }
        return CombatUtil.bestLivingTarget(client, targetRange.get(), true, true, false, false, "Distance").orElse(null);
    }

    private Set<class_2338> getWebPositions(class_310 client, class_1309 target) {
        class_2338 feet = target.method_24515();
        Set<class_2338> result = new HashSet<>();

        switch (mode.get()) {
            case "Single" -> {
                result.add(feet);
            }
            case "Surround" -> {
                result.add(feet.method_10095());
                result.add(feet.method_10072());
                result.add(feet.method_10078());
                result.add(feet.method_10067());
            }
            case "Trap" -> {
                result.add(feet);
                result.add(feet.method_10084());
                result.add(feet.method_10095());
                result.add(feet.method_10072());
                result.add(feet.method_10078());
                result.add(feet.method_10067());
            }
        }
        return result;
    }

    private int findWebs(class_310 client) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(class_1802.field_8786)) return i;
        }
        return -1;
    }
}
