package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_1735;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_465;

public final class AutoTotem extends PlayerModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "When to equip a totem.", "Always", "Always", "Low Health", "Fall Risk", "Hover", "Dynamic"));
    private final DoubleSetting health = setting(new DoubleSetting("Health", "Health threshold for low-health mode.", 10.0, 1.0, 20.0));
    private final DoubleSetting fallDistance = setting(new DoubleSetting("Fall Distance", "Fall distance threshold for fall-risk mode.", 8.0, 2.0, 80.0));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Min ticks between inventory actions.", 4, 1, 30));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks between actions.", 6, 0, 20));
    private final BooleanSetting inventoryOnly = setting(new BooleanSetting("Inventory Only", "Only swap while an inventory container is available.", false));
    private final BooleanSetting doubleHand = setting(new BooleanSetting("Double Hand", "Also place a totem in the main hand if offhand is already filled.", false));
    private final BooleanSetting dynamicDelay = setting(new BooleanSetting("Dynamic Delay", "Faster totem when low health, slower when safe.", true));
    private final BooleanSetting legitMouse = setting(new BooleanSetting("Legit Mouse", "Simulate mouse movements for screenshare safety.", false));
    private final IntegerSetting maxActionsPerOpen = setting(new IntegerSetting("Max Actions", "Max totem swaps per inventory open.", 3, 1, 10));

    private final Random random = new Random();
    private int actionsThisOpen;
    private boolean skipNext;

    public AutoTotem() {
        super("AutoTotem", "Prestige-style auto totem with dynamic danger-based delay.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        actionsThisOpen = 0;
        skipNext = false;
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (mode.is("Hover")) {
            handleHover(client);
            return;
        }

        if (dynamicDelay.enabled() && mode.is("Dynamic")) {
            float hp = client.field_1724.method_6032() + client.field_1724.method_6067();
            float max = client.field_1724.method_6063();
            float ratio = hp / max;
            int dynamicDelayTicks;
            if (ratio < 0.3) {
                dynamicDelayTicks = Math.max(1, delay.get() / 2);
            } else if (ratio < 0.6) {
                dynamicDelayTicks = delay.get();
            } else {
                dynamicDelayTicks = delay.get() + jitter.get() + random.nextInt(5);
            }
            if (!ready(dynamicDelayTicks, 0)) return;
        } else {
            if (!ready(delay.get(), jitter.get())) return;
        }

        if (skipNext) {
            skipNext = false;
            return;
        }

        if (inventoryOnly.enabled() && client.field_1755 == null) return;

        boolean offhandHasTotem = InventoryUtil.isTotem(client.field_1724.method_6079());
        boolean mainHandHasTotem = InventoryUtil.isTotem(client.field_1724.method_6047());

        if (!shouldEquip(client)) return;

        if (!offhandHasTotem) {
            int inventoryIndex = InventoryUtil.findItem(client.field_1724, class_1802.field_8288, false);
            if (inventoryIndex != -1) {
                int screenSlot = InventoryUtil.screenSlotForInventoryIndex(inventoryIndex);
                if (client.field_1755 != null && actionsThisOpen >= maxActionsPerOpen.get()) return;
                InventoryUtil.clickMove(client, screenSlot, InventoryUtil.OFFHAND_SLOT);
                if (client.field_1755 != null) actionsThisOpen++;
                if (random.nextFloat() < 0.3f) skipNext = true;
                return;
            }
        }

        if (doubleHand.enabled() && offhandHasTotem && !mainHandHasTotem) {
            int inventoryIndex = InventoryUtil.findItem(client.field_1724, class_1802.field_8288, false);
            if (inventoryIndex != -1) {
                int screenSlot = InventoryUtil.screenSlotForInventoryIndex(inventoryIndex);
                int mainHandSlot = 36 + client.field_1724.method_31548().method_67532();
                if (client.field_1755 != null && actionsThisOpen >= maxActionsPerOpen.get()) return;
                InventoryUtil.clickMove(client, screenSlot, mainHandSlot);
                if (client.field_1755 != null) actionsThisOpen++;
            }
        }
    }

    private void handleHover(class_310 client) {
        if (!(client.field_1755 instanceof class_465<?> screen)) return;
        if (!ready(delay.get(), jitter.get())) return;

        class_1735 hoveredSlot = null;
        try {
            java.lang.reflect.Field field = class_465.class.getDeclaredField("hoveredSlot");
            field.setAccessible(true);
            hoveredSlot = (class_1735) field.get(screen);
        } catch (Exception ignored) {}

        if (hoveredSlot == null || !hoveredSlot.method_7681()) return;
        if (!InventoryUtil.isTotem(hoveredSlot.method_7677())) return;

        boolean offhandHasTotem = InventoryUtil.isTotem(client.field_1724.method_6079());
        if (!offhandHasTotem) {
            InventoryUtil.clickMove(client, hoveredSlot.field_7874, InventoryUtil.OFFHAND_SLOT);
        }
    }

    private boolean shouldEquip(class_310 client) {
        return switch (mode.get()) {
            case "Always", "Dynamic" -> true;
            case "Low Health" -> client.field_1724.method_6032() + client.field_1724.method_6067() <= health.get();
            case "Fall Risk" -> client.field_1724.field_6017 >= fallDistance.get();
            default -> true;
        };
    }
}
