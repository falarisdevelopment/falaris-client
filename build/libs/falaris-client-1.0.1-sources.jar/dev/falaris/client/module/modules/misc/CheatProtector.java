package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import java.util.Random;
import net.minecraft.class_310;

public final class CheatProtector extends MiscModule {
    private final BooleanSetting packetRandomizer = setting(new BooleanSetting("Packet Randomizer", "Add jitter to packet timing to avoid pattern detection.", true));
    private final BooleanSetting fakeMovements = setting(new BooleanSetting("Fake Movements", "Send occasional fake movement packets to mask real ones.", true));
    private final BooleanSetting antiPayload = setting(new BooleanSetting("Anti Payload", "Block suspicious plugin channel payloads (DonutSMP).", true));
    private final BooleanSetting selfDestruct = setting(new BooleanSetting("Self Destruct", "Rapidly disable all modules when toggled OFF.", true));
    private final IntegerSetting fakeMoveInterval = setting(new IntegerSetting("Fake Move Interval", "Ticks between fake movement packets.", 40, 10, 200));

    private final Random random = new Random();
    private int fakeMoveTick;
    private int packetJitterTick;

    public CheatProtector() {
        super("CheatProtector", "Protects against packet inspection anti-cheats and detection.");
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null) return;

        fakeMoveTick++;
        packetJitterTick++;

        if (fakeMovements.enabled() && fakeMoveTick >= fakeMoveInterval.get() + random.nextInt(20)) {
            fakeMoveTick = 0;
            client.field_1724.field_3944.method_52787(new net.minecraft.class_2828.class_2829(
                client.field_1724.method_23317() + (random.nextDouble() - 0.5) * 0.001,
                client.field_1724.method_23318(),
                client.field_1724.method_23321() + (random.nextDouble() - 0.5) * 0.001,
                client.field_1724.method_24828(),
                client.field_1724.field_5976
            ));
        }

        if (packetRandomizer.enabled() && packetJitterTick % 5 == 0) {
            client.field_1724.field_3944.method_52787(new net.minecraft.class_2828.class_2829(
                client.field_1724.method_23317() + (random.nextDouble() - 0.5) * 0.0001,
                client.field_1724.method_23318() + (random.nextDouble() - 0.5) * 0.0001,
                client.field_1724.method_23321() + (random.nextDouble() - 0.5) * 0.0001,
                client.field_1724.method_24828(),
                client.field_1724.field_5976
            ));
        }
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        if (selfDestruct.enabled()) {
            var modules = dev.falaris.client.FalarisClient.getInstance().getModuleManager().getModules();
            for (var mod : modules) {
                if (mod != this && mod.isEnabled()) {
                    mod.setEnabled(false);
                }
            }
        }
    }
}
