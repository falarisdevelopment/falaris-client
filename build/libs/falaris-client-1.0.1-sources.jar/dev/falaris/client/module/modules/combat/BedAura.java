package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_2244;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public final class BedAura extends CombatModule {
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Maximum target distance.", 6.0, 1.0, 10.0));
    private final DoubleSetting actionRange = setting(new DoubleSetting("Action Range", "Maximum bed interaction distance.", 4.5, 1.0, 6.0));
    private final DoubleSetting minDamage = setting(new DoubleSetting("Min Damage", "Minimum estimated target damage.", 5.0, 1.0, 20.0));
    private final DoubleSetting maxSelfDamage = setting(new DoubleSetting("Max Self Damage", "Maximum estimated self damage.", 8.0, 1.0, 20.0));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Maximum rotation step per tick.", 18.0, 1.0, 60.0));
    private final IntegerSetting actionJitter = setting(new IntegerSetting("Action Jitter", "Random extra ticks between actions.", 3, 0, 10));
    private final ModeSetting priority = setting(new ModeSetting("Priority", "Target sorting mode.", "Distance", "Distance", "Health", "Angle"));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Face bed actions.", true));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Allow targets without line of sight.", false));
    private final BooleanSetting placeBeds = setting(new BooleanSetting("Place Beds", "Place beds near targets.", true));
    private final BooleanSetting autoSwitch = setting(new BooleanSetting("Auto Switch", "Auto switch to bed item.", true));

    public BedAura() {
        super("BedAura", "Places and detonates beds near selected targets.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_1309 target = CombatUtil.bestLivingTarget(client, targetRange.get(), true, true, false, throughWalls.enabled(), priority.get()).orElse(null);
        if (target == null) return;

        Optional<class_2338> bed = findBestBed(client, target);
        if (bed.isPresent()) {
            detonateBed(client, bed.get());
        } else if (placeBeds.enabled()) {
            placeBed(client, target);
        }
    }

    private void detonateBed(class_310 client, class_2338 pos) {
        if (rotate.enabled()) {
            CombatUtil.face(rotations(), client.field_1724, class_243.method_24953(pos), rotationSpeed.get());
        }
        if (actionReady(3, actionJitter.get())) {
            CombatUtil.interactBlock(client, pos, class_2350.field_11036);
        }
    }

    private void placeBed(class_310 client, class_1309 target) {
        int slot = CombatUtil.findItem(client.field_1724, class_1802.field_8258);
        if (slot == -1) slot = CombatUtil.findItem(client.field_1724, class_1802.field_8789);
        if (slot == -1) return;

        if (autoSwitch.enabled() && slot < 9) {
            CombatUtil.selectHotbarSlot(client.field_1724, slot);
        }

        Optional<class_2338> placePos = findBestBedPlacement(client, target);
        if (placePos.isEmpty()) return;

        class_2338 pos = placePos.get();
        if (rotate.enabled()) {
            CombatUtil.face(rotations(), client.field_1724, class_243.method_24953(pos), rotationSpeed.get());
        }
        if (actionReady(4, actionJitter.get())) {
            CombatUtil.interactBlock(client, pos.method_10074(), class_2350.field_11036);
        }
    }

    private Optional<class_2338> findBestBed(class_310 client, class_1309 target) {
        int radius = (int) Math.ceil(actionRange.get());
        class_2338 best = null;
        double bestDistance = Double.MAX_VALUE;

        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 3, radius)) {
            class_243 center = class_243.method_24953(pos);
            class_2680 state = client.field_1687.method_8320(pos);
            if (!(state.method_26204() instanceof class_2244)) continue;
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            if (estimatedDamage(new class_243(target.method_23317(), target.method_23318(), target.method_23321()), center) < minDamage.get()) continue;
            if (estimatedDamage(new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321()), center) > maxSelfDamage.get()) continue;

            double distance = target.method_5707(center);
            if (distance < bestDistance) {
                best = pos.method_10062();
                bestDistance = distance;
            }
        }
        return Optional.ofNullable(best);
    }

    private Optional<class_2338> findBestBedPlacement(class_310 client, class_1309 target) {
        int radius = (int) Math.ceil(actionRange.get());
        class_2338 best = null;
        double bestDistance = Double.MAX_VALUE;

        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 2, radius)) {
            class_243 center = class_243.method_24953(pos);
            if (!client.field_1687.method_8320(pos).method_26215()) continue;
            if (client.field_1687.method_8320(pos.method_10074()).method_26215()) continue;
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            if (estimatedDamage(new class_243(target.method_23317(), target.method_23318(), target.method_23321()), center) < minDamage.get()) continue;
            if (estimatedDamage(new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321()), center) > maxSelfDamage.get()) continue;

            double distance = target.method_5707(center);
            if (distance < bestDistance) {
                best = pos.method_10062();
                bestDistance = distance;
            }
        }
        return Optional.ofNullable(best);
    }

    private double estimatedDamage(class_243 target, class_243 bed) {
        double distance = target.method_1022(bed);
        return Math.max(0.0, 10.0 - distance * 1.8);
    }
}
