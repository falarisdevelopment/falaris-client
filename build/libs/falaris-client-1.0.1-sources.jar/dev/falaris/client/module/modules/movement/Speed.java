package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class Speed extends MovementModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Speed mode.", "Hop", "Hop", "Strafe", "Ground", "Legit"));
    private final DoubleSetting speed = setting(new DoubleSetting("Speed", "Movement speed multiplier.", 1.5, 1.0, 5.0));
    private final DoubleSetting acceleration = setting(new DoubleSetting("Acceleration", "Smooth speed ramp (0 = instant).", 0.25, 0.0, 1.0));
    private final BooleanSetting autoJump = setting(new BooleanSetting("Auto Jump", "Auto-jump to maintain hop speed.", true));
    private final DoubleSetting jumpHeight = setting(new DoubleSetting("Jump Height", "Extra jump motion for hop mode.", 0.42, 0.3, 0.6));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anticheat bypass.", "Vanilla", "Vanilla", "Grim", "Vulcan", "NCP"));

    private final Random random = new Random();
    private double currentSpeed;
    private int hopTicks;

    public Speed() {
        super("Speed", "Increases movement speed with hop, strafe, and ground modes.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        currentSpeed = 0;
        hopTicks = 0;
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) return;

        class_243 input = MovementUtil.inputVelocity(client.field_1724, 1.0, false, client);
        boolean moving = input.method_37268() > 0.001;

        if (!moving) {
            currentSpeed *= 0.8;
            return;
        }

        double target = speed.get();
        if (acceleration.get() > 0.01) {
            currentSpeed += (target - currentSpeed) * acceleration.get();
        } else {
            currentSpeed = target;
        }

        String bp = bypass.get();
        double jitter = 1.0;
        if (bp.equals("Grim")) jitter = 0.95 + random.nextDouble() * 0.10;
        else if (bp.equals("Vulcan")) jitter = 0.90 + random.nextDouble() * 0.15;
        else if (bp.equals("NCP")) jitter = 0.85 + random.nextDouble() * 0.20;

        double moveSpeed = currentSpeed * jitter;
        class_243 vel = MovementUtil.inputVelocity(client.field_1724, moveSpeed, false, client);

        switch (mode.get()) {
            case "Hop" -> {
                if (client.field_1724.method_24828() && autoJump.enabled()) {
                    client.field_1724.method_6043();
                    client.field_1724.method_18800(vel.field_1352, jumpHeight.get(), vel.field_1350);
                } else if (!client.field_1724.method_24828()) {
                    double y = client.field_1724.method_18798().field_1351;
                    client.field_1724.method_18800(vel.field_1352, y, vel.field_1350);
                }
                hopTicks++;
            }
            case "Strafe" -> {
                client.field_1724.method_18800(vel.field_1352, client.field_1724.method_18798().field_1351, vel.field_1350);
                if (client.field_1724.method_24828() && autoJump.enabled()) {
                    client.field_1724.method_6043();
                }
            }
            case "Ground" -> {
                if (client.field_1724.method_24828()) {
                    client.field_1724.method_18800(vel.field_1352, client.field_1724.method_18798().field_1351, vel.field_1350);
                }
            }
            case "Legit" -> {
                client.field_1724.method_5728(true);
                class_243 v = client.field_1724.method_18798();
                double mult = Math.min(moveSpeed, 1.2);
                client.field_1724.method_18800(v.field_1352 * mult, v.field_1351, v.field_1350 * mult);
            }
        }
    }
}
