package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import net.minecraft.class_310;

public final class NoPush extends MiscModule {
    private final BooleanSetting entityPush = setting(new BooleanSetting("Entity Push", "Prevent entities from pushing you.", true));
    private final BooleanSetting waterPush = setting(new BooleanSetting("Water Push", "Prevent water pushing.", true));
    private final BooleanSetting blockPush = setting(new BooleanSetting("Block Push", "Prevent block pushing (pistons).", true));

    public NoPush() {
        super("NoPush", "Prevents being pushed by entities, water, and blocks.");
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (entityPush.enabled()) {
            client.field_1724.method_18799(client.field_1724.method_18798().method_18805(1.0, 0.0, 1.0));
        }

        if (waterPush.enabled() && client.field_1724.method_5799()) {
            var vel = client.field_1724.method_18798();
            client.field_1724.method_18800(vel.field_1352 * 0.9, vel.field_1351, vel.field_1350 * 0.9);
        }
    }
}
