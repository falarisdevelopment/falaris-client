package dev.falaris.client.module.modules.misc;

import dev.falaris.client.module.modules.combat.CombatUtil;
import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import java.util.Comparator;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class Hunter extends MiscModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Target search range.", 32.0, 4.0, 64.0));
    private final DoubleSetting attackRange = setting(new DoubleSetting("Attack Range", "Attack range.", 3.5, 1.0, 6.0));
    private final DoubleSetting speed = setting(new DoubleSetting("Speed", "Flight/movement speed.", 1.0, 0.1, 5.0));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between attacks.", 10, 1, 40));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Target players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Target hostile mobs.", true));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Target passive mobs.", false));
    private final BooleanSetting fly = setting(new BooleanSetting("Fly", "Enable flight when hunting.", true));
    private final BooleanSetting elytraAware = setting(new BooleanSetting("Elytra Aware", "Don't force flight if using elytra.", true));
    private final BooleanSetting autoWeapon = setting(new BooleanSetting("Auto Weapon", "Switch to best weapon when attacking.", true));
    private final BooleanSetting respectCooldown = setting(new BooleanSetting("Respect Cooldown", "Only attack when weapon cooldown is ready.", true));

    private class_1309 target;
    private int attackCounter;

    public Hunter() {
        super("Hunter", "Auto-targets and pursues nearby entities with flight/elytra.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        target = null;
        attackCounter = 0;
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        attackCounter++;

        boolean hasElytra = client.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);

        if (fly.enabled() && !(elytraAware.enabled() && hasElytra)) {
            client.field_1724.method_31549().field_7479 = true;
            client.field_1724.method_31549().method_7248((float) (speed.get() / 5.0));
        }

        if (target == null || !target.method_5805() || client.field_1724.method_5858(target) > range.get() * range.get()) {
            target = findTarget(client);
        }

        if (target == null) return;

        class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        class_243 playerPos = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
        class_243 toTarget = targetPos.method_1020(playerPos).method_1029();

        if (fly.enabled() && !(elytraAware.enabled() && hasElytra)) {
            client.field_1724.method_18800(toTarget.field_1352 * speed.get(), toTarget.field_1351 * speed.get(), toTarget.field_1350 * speed.get());
        } else {
            double y = hasElytra ? client.field_1724.method_18798().field_1351 : 0;
            client.field_1724.method_18800(toTarget.field_1352 * speed.get(), y, toTarget.field_1350 * speed.get());
        }

        if (client.field_1724.method_5739(target) <= attackRange.get() && attackCounter >= delay.get()) {
            if (respectCooldown.enabled() && client.field_1724.method_7261(0) < 0.9f) {
                return;
            }
            if (autoWeapon.enabled()) {
                int swordSlot = CombatUtil.findItem(client.field_1724, class_1802.field_22022);
                if (swordSlot == -1) swordSlot = CombatUtil.findItem(client.field_1724, class_1802.field_8802);
                if (swordSlot == -1) swordSlot = CombatUtil.findItem(client.field_1724, class_1802.field_8371);
                if (swordSlot == -1) swordSlot = CombatUtil.findItem(client.field_1724, class_1802.field_8528);
                if (swordSlot >= 0 && swordSlot < 9) {
                    CombatUtil.selectHotbarSlot(client.field_1724, swordSlot);
                }
            }
            client.field_1761.method_2918(client.field_1724, target);
            client.field_1724.method_6104(class_1268.field_5808);
            attackCounter = 0;
        }

        client.field_1724.field_6017 = 0.0f;
    }

    @Override
    protected void onDisable() {
        target = null;
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && fly.enabled()) {
            client.field_1724.method_31549().field_7479 = false;
        }
    }

    private class_1309 findTarget(class_310 client) {
        return client.field_1687.method_8390(class_1309.class, client.field_1724.method_5829().method_1014(range.get()), entity -> {
            if (entity == client.field_1724 || !entity.method_5805()) return false;
            if (entity instanceof class_1657 && !players.enabled()) return false;
            if (entity instanceof class_1588 && !hostiles.enabled()) return false;
            return true;
        }).stream().min(Comparator.comparingDouble(client.field_1724::method_5739)).orElse(null);
    }
}
