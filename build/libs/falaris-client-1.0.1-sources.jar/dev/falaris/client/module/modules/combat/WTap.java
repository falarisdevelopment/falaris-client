package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;

public final class WTap extends CombatModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Sprint reset method.", "WTap", "WTap", "STap", "BlockHit"));
    private final IntegerSetting tapTicks = setting(new IntegerSetting("Tap Ticks", "Ticks to hold sprint off.", 3, 1, 10));
    private final BooleanSetting requireTarget = setting(new BooleanSetting("Require Target", "Only tap when aiming at entity.", true));

    private int tapTimer;
    private boolean wasTapping;

    public WTap() {
        super("WTap", "Resets sprint on hit to reduce knockback received.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (tapTimer > 0) {
            tapTimer--;
            if (!client.field_1724.method_5624()) {
                wasTapping = true;
            }
            if (tapTimer <= 0 && wasTapping) {
                client.field_1724.method_5728(true);
                wasTapping = false;
            }
            return;
        }

        if (!client.field_1690.field_1894.method_1434()) return;
        if (!client.field_1724.method_5624()) return;

        boolean attacking = isAttacking(client);
        if (!attacking) return;

        if (mode.is("BlockHit")) {
            if (client.field_1724.method_7261(0.5f) >= 0.9f) {
                client.field_1690.field_1886.method_23481(false);
                tapTimer = tapTicks.get();
            }
            return;
        }

        client.field_1724.method_5728(false);
        tapTimer = tapTicks.get();
    }

    private boolean isAttacking(class_310 client) {
        if (client.field_1765 instanceof class_3966 hit && hit.method_17783() == class_239.class_240.field_1331) {
            class_1297 target = hit.method_17782();
            if (!requireTarget.enabled() || (target instanceof class_1309 living && living.method_5805() && living != client.field_1724)) {
                return client.field_1690.field_1886.method_1434();
            }
        }
        return false;
    }
}
