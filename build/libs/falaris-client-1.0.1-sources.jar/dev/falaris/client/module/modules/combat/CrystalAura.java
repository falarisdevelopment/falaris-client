package dev.falaris.client.module.modules.combat;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Optional;
import java.util.Random;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class CrystalAura extends CombatModule {
    // Targeting
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Max target distance.", 8.0, 1.0, 12.0));
    private final DoubleSetting breakRange = setting(new DoubleSetting("Break Range", "Max crystal break distance.", 3.5, 1.0, 5.0));
    private final DoubleSetting placeRange = setting(new DoubleSetting("Place Range", "Max crystal place distance.", 3.5, 1.0, 5.0));
    private final DoubleSetting minDamage = setting(new DoubleSetting("Min Damage", "Minimum estimated target damage.", 6.0, 1.0, 20.0));
    private final DoubleSetting maxSelfDamage = setting(new DoubleSetting("Max Self Damage", "Maximum estimated self damage.", 8.0, 1.0, 20.0));
    private final ModeSetting priority = setting(new ModeSetting("Priority", "Target sorting mode.", "Distance", "Distance", "Health", "Angle"));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Allow targets without line of sight.", false));
    private final BooleanSetting antiBot = setting(new BooleanSetting("Anti Bot", "Skip bot-checked entities.", true));

    // Action toggles
    private final BooleanSetting place = setting(new BooleanSetting("Place", "Place end crystals.", true));
    private final BooleanSetting explode = setting(new BooleanSetting("Break", "Break end crystals.", true));
    private final BooleanSetting placeObsidian = setting(new BooleanSetting("Place Obsidian", "Auto-place obsidian before crystal.", true));
    private final BooleanSetting feetPlace = setting(new BooleanSetting("Feet Place", "Place obsidian under target feet.", true));
    private final BooleanSetting hitTarget = setting(new BooleanSetting("Hit Target", "Melee the target directly.", true));
    private final DoubleSetting hitRange = setting(new DoubleSetting("Melee Range", "Range for melee hits.", 3.0, 1.0, 3.5));

    // Bypass
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anticheat bypass method.", "Vanilla", "Vanilla", "Vanilla", "Ghost", "Grim", "Legit"));
    private final IntegerSetting faceDelay = setting(new IntegerSetting("Face Delay", "Ticks to face target before action (ghost).", 2, 0, 10));
    private final IntegerSetting targetSwitchDelay = setting(new IntegerSetting("Target Switch Delay", "Ticks before switching targets.", 10, 0, 40));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Max rotation per tick.", 20.0, 1.0, 60.0));
    private final DoubleSetting minCps = setting(new DoubleSetting("Min CPS", "Minimum clicks/sec.", 3.0, 1.0, 12.0));
    private final DoubleSetting maxCps = setting(new DoubleSetting("Max CPS", "Maximum clicks/sec.", 8.0, 1.0, 20.0));
    private final DoubleSetting missChance = setting(new DoubleSetting("Miss Chance", "Chance to randomly miss a hit %.", 5.0, 0.0, 30.0));
    private final IntegerSetting actionJitter = setting(new IntegerSetting("Action Jitter", "Random extra ticks.", 2, 0, 8));

    // Auto switch
    private final BooleanSetting autoSwitchSword = setting(new BooleanSetting("Auto Sword", "Switch to sword for melee.", true));
    private final BooleanSetting autoSwitchPick = setting(new BooleanSetting("Auto Pick", "Switch to pick for crystal break.", false));

    private final Random random = new Random();
    private int faceTicks;
    private boolean hasFaced;
    private class_1309 currentTarget;
    private int targetSwitchCooldown;
    private ActionPhase phase = ActionPhase.BREAK;
    private int ghostPreTicks;

    private enum ActionPhase { BREAK, PLACE, OBSIDIAN, MELEE }

    public CrystalAura() {
        super("CrystalAura", "Crystal PvP aura with ghost bypass, face delay, and smart action sequencing.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        faceTicks = 0;
        hasFaced = false;
        currentTarget = null;
        targetSwitchCooldown = 0;
        phase = ActionPhase.BREAK;
        ghostPreTicks = 0;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        if (targetSwitchCooldown > 0) targetSwitchCooldown--;

        // Find/switch target
        class_1309 target = CombatUtil.bestLivingTarget(client, targetRange.get(), true, true, false, throughWalls.enabled(), priority.get()).orElse(null);
        if (target == null) { currentTarget = null; return; }

        if (target != currentTarget && targetSwitchCooldown <= 0) {
            currentTarget = target;
            targetSwitchCooldown = targetSwitchDelay.get() + random.nextInt(5);
            hasFaced = false;
            faceTicks = 0;
        }
        if (currentTarget == null) return;
        if (antiBot.enabled() && FalarisClient.getInstance().getIgnoresManager().isIgnored(currentTarget.method_5477().getString())) return;

        boolean isGhost = bypass.is("Ghost") || bypass.is("Legit") || bypass.is("Grim");

        // Face delay for ghost modes
        if (isGhost && !hasFaced) {
            float[] rots = CombatUtil.rotationsTo(client.field_1724, currentTarget.method_33571());
            rotations().setMaxStep(rotationSpeed.get().floatValue());
            rotations().rotateToSilent(rots[0], rots[1], Math.max(1, faceDelay.get()));
            faceTicks++;
            if (faceTicks >= faceDelay.get()) {
                hasFaced = true;
                faceTicks = 0;
            }
            return;
        }

        // Ghost: tick-based action sequencing
        if (isGhost) {
            tickGhost(client, currentTarget);
        } else {
            tickVanilla(client, currentTarget);
        }
    }

    private void tickGhost(class_310 client, class_1309 target) {
        // Pre-action facing: face the current action's target before executing
        if (ghostPreTicks > 0) {
            ghostPreTicks--;
            faceCurrentAction(client, target);
            return;
        }

        // Execute the current action
        executePhase(client, target);

        // Advance sequence after a brief delay
        if (!actionReady(Math.max(1, faceDelay.get()), actionJitter.get())) return;
        advancePhase();
    }

    private void executePhase(class_310 client, class_1309 target) {
        switch (phase) {
            case BREAK -> {
                if (explode.enabled()) {
                    tryBreakBest(client);
                }
            }
            case PLACE -> {
                if (place.enabled()) {
                    tryPlaceBest(client, target);
                }
            }
            case OBSIDIAN -> {
                if (placeObsidian.enabled()) {
                    boolean placed = false;
                    if (feetPlace.enabled()) placed = tryPlaceObsidianFeet(client, target);
                    if (!placed) {
                        int slot = CombatUtil.findItem(client.field_1724, class_1802.field_8281);
                        if (slot != -1) tryPlaceObsidian(client, target, slot);
                    }
                }
            }
            case MELEE -> {
                boolean willMiss = random.nextFloat() * 100 < missChance.get();
                if (hitTarget.enabled() && client.field_1724.method_5739(target) <= hitRange.get() && !willMiss) {
                    doMelee(client, target);
                }
            }
        }
    }

    private void advancePhase() {
        float r = random.nextFloat();
        if (r < 0.25f) {
            phase = ActionPhase.BREAK;
        } else if (r < 0.50f) {
            phase = ActionPhase.PLACE;
        } else if (r < 0.75f) {
            phase = ActionPhase.OBSIDIAN;
        } else {
            phase = ActionPhase.MELEE;
        }
        ghostPreTicks = Math.max(1, faceDelay.get());
    }

    private void faceCurrentAction(class_310 client, class_1309 target) {
        switch (phase) {
            case BREAK -> {
                class_1511 crystal = findCrystalToBreak(client);
                if (crystal != null) faceCrystal(client, crystal);
            }
            case PLACE -> faceTargetPos(client, target);
            case OBSIDIAN -> faceTargetPos(client, target);
            case MELEE -> faceTargetPos(client, target);
        }
    }

    private void faceTargetPos(class_310 client, class_1309 target) {
        faceSmooth(client, target.method_33571());
    }

    private void tickVanilla(class_310 client, class_1309 target) {
        // Feet obsidian
        if (placeObsidian.enabled() && feetPlace.enabled()) {
            tryPlaceObsidianFeet(client, target);
        }
        if (placeObsidian.enabled() && !feetPlace.enabled()) {
            tryPlaceObsidian(client, target);
        }

        // Break
        if (explode.enabled() && tryBreakBest(client)) {
            class_1511 crystal = findCrystalToBreak(client);
            if (crystal != null && actionReady(1, actionJitter.get())) {
                class_243 targetPos = new class_243(crystal.method_23317(), crystal.method_23318() + 0.5, crystal.method_23321());
                faceSmooth(client, targetPos);
                CombatUtil.attack(client, crystal);
            }
        }

        // Place
        if (place.enabled() && actionReady(2, actionJitter.get())) {
            tryPlaceBest(client, target);
        }

        // Melee fallback
        if (hitTarget.enabled() && client.field_1724.method_5739(target) <= hitRange.get() && actionReady(1, actionJitter.get())) {
            doMelee(client, target);
        }
    }

    private class_1511 findCrystalToBreak(class_310 client) {
        return CombatUtil.bestCrystal(client, breakRange.get(), throughWalls.enabled()).orElse(null);
    }

    private boolean tryBreakBest(class_310 client) {
        class_1511 crystal = findCrystalToBreak(client);
        if (crystal == null) return false;
        class_243 targetPos = new class_243(crystal.method_23317(), crystal.method_23318() + 0.5, crystal.method_23321());
        faceSmooth(client, targetPos);
        CombatUtil.attack(client, crystal);
        return true;
    }

    private boolean tryPlaceObsidianFeet(class_310 client, class_1309 target) {
        int obsidianSlot = CombatUtil.findItem(client.field_1724, class_1802.field_8281);
        if (obsidianSlot == -1) return false;

        class_2338 feetPos = target.method_24515();
        if (!client.field_1687.method_8320(feetPos).method_26215()) return false;
        if (client.field_1687.method_8320(feetPos.method_10074()).method_26215()) return false;
        if (client.field_1724.method_5707(class_243.method_24953(feetPos)) > placeRange.get() * placeRange.get()) return false;

        faceSmooth(client, class_243.method_24953(feetPos));
        if (actionReady(2, actionJitter.get())) {
            CombatUtil.selectHotbarSlot(client.field_1724, obsidianSlot);
            CombatUtil.interactBlock(client, feetPos, class_2350.field_11036);
        }
        return true;
    }

    private boolean tryPlaceObsidian(class_310 client, class_1309 target) {
        int obsidianSlot = CombatUtil.findItem(client.field_1724, class_1802.field_8281);
        if (obsidianSlot == -1) return false;

        Optional<class_2338> placePos = findBestObsidianPlacement(client, target);
        if (placePos.isEmpty()) return false;
        class_2338 pos = placePos.get();
        faceSmooth(client, class_243.method_24953(pos));
        if (actionReady(2, actionJitter.get())) {
            CombatUtil.selectHotbarSlot(client.field_1724, obsidianSlot);
            CombatUtil.interactBlock(client, pos, class_2350.field_11036);
        }
        return true;
    }

    private boolean tryPlaceBest(class_310 client, class_1309 target) {
        int slot = CombatUtil.findItem(client.field_1724, class_1802.field_8301);
        if (slot == -1) return false;

        Optional<class_2338> best = findBestCrystalBase(client, target);
        if (best.isEmpty()) return false;
        class_2338 pos = best.get();
        faceSmooth(client, class_243.method_24953(pos.method_10084()));
        if (actionReady(1, actionJitter.get())) {
            CombatUtil.selectHotbarSlot(client.field_1724, slot);
            CombatUtil.interactBlock(client, pos, class_2350.field_11036);
        }
        return true;
    }

    private void faceSmooth(class_310 client, class_243 target) {
        boolean isGhost = bypass.is("Ghost") || bypass.is("Legit") || bypass.is("Grim");
        int ticks = isGhost ? Math.max(2, faceDelay.get()) : Math.max(1, 1);
        faceRotations(client, target, ticks);
    }

    private void faceCrystal(class_310 client, class_1511 crystal) {
        faceSmooth(client, new class_243(crystal.method_23317(), crystal.method_23318() + 0.5, crystal.method_23321()));
    }

    private void facePos(class_310 client, class_243 pos) {
        faceSmooth(client, pos);
    }

    private void faceRotations(class_310 client, class_243 target, int ticks) {
        float[] rots = CombatUtil.rotationsTo(client.field_1724, target);
        rotations().setMaxStep(rotationSpeed.get().floatValue());

        if (bypass.is("Ghost") || bypass.is("Legit") || bypass.is("Grim")) {
            float noiseYaw = (random.nextFloat() - 0.5f) * 1.5f;
            float noisePitch = (random.nextFloat() - 0.5f) * 0.8f;
            rotations().rotateToSilent(rots[0] + noiseYaw, rots[1] + noisePitch, ticks);
            rotations().setServerRotation(rots[0], rots[1], ticks);
        } else {
            rotations().rotateToSilent(rots[0], rots[1], ticks);
        }
    }

    private boolean tryPlaceObsidian(class_310 client, class_1309 target, int slot) {
        class_2338 bestObsidian = findBestObsidianPlacementBlock(client, target);
        if (bestObsidian == null) return false;
        facePos(client, class_243.method_24953(bestObsidian));
        CombatUtil.selectHotbarSlot(client.field_1724, slot);
        CombatUtil.interactBlock(client, bestObsidian, class_2350.field_11036);
        return true;
    }

    private void doMelee(class_310 client, class_1309 target) {
        if (autoSwitchSword.enabled()) {
            int swordSlot = findBestSword(client);
            if (swordSlot != -1 && swordSlot < 9) {
                CombatUtil.selectHotbarSlot(client.field_1724, swordSlot);
            }
        }
        faceSmooth(client, target.method_33571());
        if (actionReady(1, actionJitter.get())) {
            CombatUtil.attack(client, target);
        }
    }

    private int findBestSword(class_310 client) {
        net.minecraft.class_1792[] swords = {class_1802.field_22022, class_1802.field_8802, class_1802.field_8371, class_1802.field_8528};
        for (net.minecraft.class_1792 sword : swords) {
            int slot = CombatUtil.findItem(client.field_1724, sword);
            if (slot != -1) return slot;
        }
        return -1;
    }

    private class_2338 findBestObsidianPlacementBlock(class_310 client, class_1309 target) {
        Optional<class_2338> opt = findBestObsidianPlacement(client, target);
        return opt.orElse(null);
    }

    private Optional<class_2338> findBestObsidianPlacement(class_310 client, class_1309 target) {
        int radius = (int) Math.ceil(placeRange.get());
        class_2338 origin = target.method_24515();
        class_2338 best = null;
        double bestDamage = 0;

        for (class_2338 pos : class_2338.method_25996(origin, radius, 2, radius)) {
            if (!client.field_1687.method_8320(pos).method_26215()) continue;
            if (client.field_1687.method_8320(pos.method_10074()).method_26215()) continue;
            class_243 crystalPos = class_243.method_24953(pos.method_10084());
            if (client.field_1724.method_5707(crystalPos) > placeRange.get() * placeRange.get()) continue;
            class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
            double dmg = explosionDamage(targetPos, crystalPos, 6.0f, 12.0f);
            if (dmg < minDamage.get()) continue;
            class_243 selfPos = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
            double selfDmg = explosionDamage(selfPos, crystalPos, 6.0f, 12.0f);
            if (selfDmg > maxSelfDamage.get()) continue;
            if (dmg > bestDamage) {
                best = pos.method_10062();
                bestDamage = dmg;
            }
        }
        return Optional.ofNullable(best);
    }

    private Optional<class_2338> findBestCrystalBase(class_310 client, class_1309 target) {
        int radius = (int) Math.ceil(placeRange.get());
        class_2338 origin = target.method_24515();
        class_2338 best = null;
        double bestDamage = 0;

        for (class_2338 pos : class_2338.method_25996(origin, radius, 2, radius)) {
            class_243 crystalPos = class_243.method_24953(pos.method_10084());
            if (!canPlaceCrystal(client, pos)) continue;
            if (client.field_1724.method_5707(crystalPos) > placeRange.get() * placeRange.get()) continue;
            class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
            double dmg = explosionDamage(targetPos, crystalPos, 6.0f, 12.0f);
            if (dmg < minDamage.get()) continue;
            class_243 selfPos = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
            double selfDmg = explosionDamage(selfPos, crystalPos, 6.0f, 12.0f);
            if (selfDmg > maxSelfDamage.get()) continue;
            if (dmg > bestDamage) {
                best = pos.method_10062();
                bestDamage = dmg;
            }
        }
        return Optional.ofNullable(best);
    }

    private boolean canPlaceCrystal(class_310 client, class_2338 pos) {
        return (client.field_1687.method_8320(pos).method_27852(class_2246.field_10540) || client.field_1687.method_8320(pos).method_27852(class_2246.field_9987))
            && client.field_1687.method_8320(pos.method_10084()).method_26215();
    }

    private double explosionDamage(class_243 target, class_243 source, float power, float maxDamage) {
        double distance = target.method_1022(source);
        double exposure = 1.0;
        double impact = (1.0 - distance / (2.0 * power)) * exposure;
        impact = class_3532.method_15350(impact, 0.0, 1.0);
        return (impact * impact + impact) / 2.0 * maxDamage * 1.5 + 1.0;
    }
}
