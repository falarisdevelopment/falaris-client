package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Optional;
import java.util.Random;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class CrystalAura extends CombatModule {
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Max target distance.", 8.0, 1.0, 12.0));
    private final DoubleSetting breakRange = setting(new DoubleSetting("Break Range", "Max crystal break distance.", 3.0, 1.0, 4.0));
    private final DoubleSetting placeRange = setting(new DoubleSetting("Place Range", "Max crystal place distance.", 3.0, 1.0, 4.0));
    private final DoubleSetting minDamage = setting(new DoubleSetting("Min Damage", "Minimum estimated target damage.", 6.0, 1.0, 20.0));
    private final DoubleSetting maxSelfDamage = setting(new DoubleSetting("Max Self Damage", "Maximum estimated self damage.", 8.0, 1.0, 20.0));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Max rotation per tick.", 20.0, 1.0, 60.0));
    private final IntegerSetting actionJitter = setting(new IntegerSetting("Action Jitter", "Random extra ticks between actions.", 2, 0, 8));
    private final BooleanSetting place = setting(new BooleanSetting("Place", "Place end crystals.", true));
    private final BooleanSetting explode = setting(new BooleanSetting("Break", "Break end crystals.", true));
    private final BooleanSetting placeObsidian = setting(new BooleanSetting("Place Obsidian", "Auto-place obsidian before crystal.", true));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Face crystal actions.", true));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Allow crystals without line of sight.", false));
    private final ModeSetting priority = setting(new ModeSetting("Priority", "Target sorting mode.", "Distance", "Distance", "Health", "Angle"));
    private final BooleanSetting hitTarget = setting(new BooleanSetting("Hit Target", "Attack the target directly.", true));
    private final DoubleSetting hitTargetRange = setting(new DoubleSetting("Hit Range", "Range to hit the target.", 3.0, 1.0, 3.0));
    private final BooleanSetting autoSwitch = setting(new BooleanSetting("Auto Switch", "Auto switch to sword for melee hits.", true));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anticheat bypass method.", "Vanilla", "Vanilla", "Legit", "Grim"));

    // Prestige-style additions
    private final ModeSetting breakMode = setting(new ModeSetting("Break Mode", "Crystal break priority.", "Normal", "Normal", "Double Tap", "Chain", "Sequential"));
    private final BooleanSetting silentHeadBob = setting(new BooleanSetting("Silent Head Bob", "Simulate head bobbing for legit look.", true));
    private final BooleanSetting idPrediction = setting(new BooleanSetting("ID Prediction", "Predict entity ID for faster hits.", false));
    private final BooleanSetting feetPlace = setting(new BooleanSetting("Feet Place", "Place obsidian under target feet before crystal.", true));

    private final Random random = new Random();
    private int actionCounter;
    private int headBobPhase;
    private int predictedId;

    public CrystalAura() {
        super("CrystalAura", "Prestige-style crystal PvP with double-tap, ID prediction, silent head bob.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_1309 target = CombatUtil.bestLivingTarget(client, targetRange.get(), true, true, false, throughWalls.enabled(), priority.get()).orElse(null);
        if (target == null) return;

        actionCounter++;

        if (silentHeadBob.enabled()) {
            headBobPhase += 2;
            if (headBobPhase > 360) headBobPhase = 0;
            float bob = class_3532.method_15374(headBobPhase * class_3532.field_29847) * 0.5f;
            client.field_1724.method_36457(client.field_1724.method_36455() + bob * 0.02f);
        }

        if (bypass.is("Grim")) {
            tickGrim(client, target);
            return;
        }
        if (bypass.is("Legit")) {
            tickLegit(client, target);
            return;
        }

        // Double Tap: break then place at same spot
        if (breakMode.is("Double Tap") && explode.enabled()) {
            Optional<class_1511> crystal = CombatUtil.bestCrystal(client, breakRange.get(), throughWalls.enabled());
            if (crystal.isPresent()) {
                tryBreakBest(client);
                if (actionReady(0, 0)) {
                    class_1511 ec = crystal.get();
                    class_2338 basePos = class_2338.method_49637(ec.method_23317(), ec.method_23318() - 1, ec.method_23321());
                    if (place.enabled() && canPlaceCrystal(client, basePos)) {
                        int slot = CombatUtil.findItem(client.field_1724, class_1802.field_8301);
                        if (slot >= 0 && slot < 9) {
                            CombatUtil.selectHotbarSlot(client.field_1724, slot);
                            CombatUtil.interactBlock(client, basePos, class_2350.field_11036);
                        }
                    }
                }
            }
        }

        // FeetPlace: place obsidian under target
        if (feetPlace.enabled() && placeObsidian.enabled()) {
            tryPlaceObsidianFeet(client, target);
        }

        if (placeObsidian.enabled() && !feetPlace.enabled()) {
            tryPlaceObsidian(client, target);
        }

        if (breakMode.is("Chain")) {
            chainBreak(client);
        } else if (breakMode.is("Sequential")) {
            sequentialBreak(client, target);
        } else if (!breakMode.is("Double Tap")) {
            if (explode.enabled()) tryBreakBest(client);
            if (place.enabled()) tryPlaceBest(client, target);
        }

        hitFallback(client, target);
    }

    private void tickGrim(class_310 client, class_1309 target) {
        if (explode.enabled() && actionReady(3 + random.nextInt(3), actionJitter.get())) {
            tryBreakBest(client);
        }
        if (placeObsidian.enabled() && actionReady(5 + random.nextInt(3), actionJitter.get())) {
            tryPlaceObsidian(client, target);
        }
        if (place.enabled() && actionReady(2 + random.nextInt(2), actionJitter.get())) {
            tryPlaceBest(client, target);
        }
        if (hitTarget.enabled() && client.field_1724.method_5739(target) <= hitTargetRange.get()) {
            if (actionReady(4, actionJitter.get())) {
                doMelee(client, target);
            }
        }
    }

    private void tickLegit(class_310 client, class_1309 target) {
        boolean willBreak = explode.enabled() && random.nextFloat() < 0.6f;
        boolean willObsidian = placeObsidian.enabled() && random.nextFloat() < 0.4f;
        boolean willPlace = place.enabled() && random.nextFloat() < 0.5f;
        boolean willMelee = hitTarget.enabled() && client.field_1724.method_5739(target) <= hitTargetRange.get() && random.nextFloat() < 0.3f;

        if (willBreak && actionReady(4 + random.nextInt(4), actionJitter.get())) {
            tryBreakBest(client);
        }
        if (willObsidian && actionReady(6 + random.nextInt(2), actionJitter.get())) {
            tryPlaceObsidian(client, target);
        }
        if (willPlace && actionReady(3 + random.nextInt(3), actionJitter.get())) {
            tryPlaceBest(client, target);
        }
        if (willMelee && actionReady(5, actionJitter.get())) {
            doMelee(client, target);
        }
    }

    private void chainBreak(class_310 client) {
        while (explode.enabled()) {
            Optional<class_1511> crystal = CombatUtil.bestCrystal(client, breakRange.get(), throughWalls.enabled());
            if (crystal.isEmpty()) break;
            CombatUtil.attack(client, crystal.get());
        }
    }

    private void sequentialBreak(class_310 client, class_1309 target) {
        if (!explode.enabled()) return;
        Optional<class_1511> crystal = CombatUtil.bestCrystal(client, breakRange.get(), throughWalls.enabled());
        if (crystal.isEmpty()) return;

        if (idPrediction.enabled()) {
            try {
                int id = crystal.get().method_5628();
                if (predictedId != id && predictedId != 0) {
                    int slot = CombatUtil.findItem(client.field_1724, class_1802.field_8802);
                    if (slot >= 0) CombatUtil.selectHotbarSlot(client.field_1724, slot);
                }
                predictedId = id;
            } catch (Exception ignored) {}
        }

        tryBreakBest(client);
        if (place.enabled() && actionReady(0, 0)) {
            tryPlaceBest(client, target);
        }
    }

    private boolean tryBreakBest(class_310 client) {
        Optional<class_1511> crystal = CombatUtil.bestCrystal(client, breakRange.get(), throughWalls.enabled());
        if (crystal.isEmpty()) return false;

        class_1511 entity = crystal.get();
        class_243 targetPos = new class_243(entity.method_23317(), entity.method_23318() + 0.5, entity.method_23321());
        if (rotate.enabled()) {
            faceSmooth(client, targetPos);
        }
        if (actionReady(1, actionJitter.get())) {
            CombatUtil.attack(client, entity);
        }
        return true;
    }

    private boolean tryPlaceObsidianFeet(class_310 client, class_1309 target) {
        int obsidianSlot = CombatUtil.findItem(client.field_1724, class_1802.field_8281);
        if (obsidianSlot == -1) return false;

        class_2338 feetPos = target.method_24515();
        if (!client.field_1687.method_8320(feetPos).method_26215()) return false;
        if (client.field_1687.method_8320(feetPos.method_10074()).method_26215()) return false;
        double dist = client.field_1724.method_5707(class_243.method_24953(feetPos));
        if (dist > placeRange.get() * placeRange.get()) return false;

        if (rotate.enabled()) {
            faceSmooth(client, class_243.method_24953(feetPos));
        }
        if (actionReady(1, actionJitter.get())) {
            CombatUtil.selectHotbarSlot(client.field_1724, obsidianSlot);
            CombatUtil.interactBlock(client, feetPos, class_2350.field_11036);
        }
        return true;
    }

    private boolean tryPlaceObsidian(class_310 client, class_1309 target) {
        int obsidianSlot = CombatUtil.findItem(client.field_1724, class_1802.field_8281);
        if (obsidianSlot == -1) return false;

        Optional<class_2338> placePos = findBestObsidianPlacement(client, target);
        if (placePos.isEmpty()) return false;

        class_2338 pos = placePos.get();
        class_243 center = class_243.method_24953(pos);
        if (rotate.enabled()) {
            faceSmooth(client, center);
        }
        if (actionReady(2, actionJitter.get())) {
            CombatUtil.selectHotbarSlot(client.field_1724, obsidianSlot);
            CombatUtil.interactBlock(client, pos, class_2350.field_11036);
        }
        return true;
    }

    private boolean tryPlaceBest(class_310 client, class_1309 target) {
        int slot = CombatUtil.findItem(client.field_1724, class_1802.field_8301);
        if (slot == -1) return false;

        Optional<class_2338> best = findBestCrystalBase(client, target);
        if (best.isEmpty()) return false;

        class_2338 pos = best.get();
        class_243 placePos = class_243.method_24953(pos.method_10084());
        if (rotate.enabled()) {
            faceSmooth(client, placePos);
        }
        if (actionReady(1, actionJitter.get())) {
            CombatUtil.selectHotbarSlot(client.field_1724, slot);
            CombatUtil.interactBlock(client, pos, class_2350.field_11036);
        }
        return true;
    }

    private void faceSmooth(class_310 client, class_243 target) {
        float[] rots = CombatUtil.rotationsTo(client.field_1724, target);
        float yawDelta = Math.abs(class_3532.method_15393(rots[0] - client.field_1724.method_36454()));
        float pitchDelta = Math.abs(rots[1] - client.field_1724.method_36455());
        int ticks = Math.max(1, (int) Math.ceil(Math.max(yawDelta, pitchDelta) / rotationSpeed.get().floatValue()));
        rotations().setMaxStep(rotationSpeed.get().floatValue());
        rotations().rotateTo(rots[0], rots[1], ticks);
    }

    private void doMelee(class_310 client, class_1309 target) {
        if (autoSwitch.enabled()) {
            int swordSlot = findBestSword(client);
            if (swordSlot != -1 && swordSlot < 9) {
                CombatUtil.selectHotbarSlot(client.field_1724, swordSlot);
            }
        }
        if (actionReady(1, actionJitter.get())) {
            CombatUtil.attack(client, target);
        }
    }

    private int findBestSword(class_310 client) {
        net.minecraft.class_1792[] swords = {class_1802.field_22022, class_1802.field_8802, class_1802.field_8371, class_1802.field_8528};
        for (net.minecraft.class_1792 sword : swords) {
            int slot = CombatUtil.findItem(client.field_1724, sword);
            if (slot != -1) return slot;
        }
        return -1;
    }

    private void hitFallback(class_310 client, class_1309 target) {
        if (!hitTarget.enabled()) return;
        if (client.field_1724.method_5739(target) > hitTargetRange.get()) return;
        if (!actionReady(1, actionJitter.get())) return;
        doMelee(client, target);
    }

    private Optional<class_2338> findBestObsidianPlacement(class_310 client, class_1309 target) {
        int radius = (int) Math.ceil(placeRange.get());
        class_2338 origin = target.method_24515();
        class_2338 best = null;
        double bestDamage = 0;

        for (class_2338 pos : class_2338.method_25996(origin, radius, 2, radius)) {
            if (!client.field_1687.method_8320(pos).method_26215()) continue;
            if (client.field_1687.method_8320(pos.method_10074()).method_26215()) continue;
            class_243 crystalPos = class_243.method_24953(pos.method_10084());
            if (client.field_1724.method_5707(crystalPos) > placeRange.get() * placeRange.get()) continue;
            class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
            double dmg = explosionDamage(targetPos, crystalPos, 6.0f, 12.0f);
            if (dmg < minDamage.get()) continue;
            class_243 selfPos = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
            double selfDmg = explosionDamage(selfPos, crystalPos, 6.0f, 12.0f);
            if (selfDmg > maxSelfDamage.get()) continue;
            if (dmg > bestDamage) {
                best = pos.method_10062();
                bestDamage = dmg;
            }
        }
        return Optional.ofNullable(best);
    }

    private Optional<class_2338> findBestCrystalBase(class_310 client, class_1309 target) {
        int radius = (int) Math.ceil(placeRange.get());
        class_2338 origin = target.method_24515();
        class_2338 best = null;
        double bestDamage = 0;

        for (class_2338 pos : class_2338.method_25996(origin, radius, 2, radius)) {
            class_243 crystalPos = class_243.method_24953(pos.method_10084());
            if (!canPlaceCrystal(client, pos)) continue;
            if (client.field_1724.method_5707(crystalPos) > placeRange.get() * placeRange.get()) continue;
            class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
            double dmg = explosionDamage(targetPos, crystalPos, 6.0f, 12.0f);
            if (dmg < minDamage.get()) continue;
            class_243 selfPos = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
            double selfDmg = explosionDamage(selfPos, crystalPos, 6.0f, 12.0f);
            if (selfDmg > maxSelfDamage.get()) continue;
            if (dmg > bestDamage) {
                best = pos.method_10062();
                bestDamage = dmg;
            }
        }
        return Optional.ofNullable(best);
    }

    private boolean canPlaceCrystal(class_310 client, class_2338 pos) {
        return (client.field_1687.method_8320(pos).method_27852(class_2246.field_10540) || client.field_1687.method_8320(pos).method_27852(class_2246.field_9987))
            && client.field_1687.method_8320(pos.method_10084()).method_26215();
    }

    private double explosionDamage(class_243 target, class_243 source, float power, float maxDamage) {
        double distance = target.method_1022(source);
        double exposure = 1.0;
        double impact = (1.0 - distance / (2.0 * power)) * exposure;
        impact = class_3532.method_15350(impact, 0.0, 1.0);
        return (impact * impact + impact) / 2.0 * maxDamage * 1.5 + 1.0;
    }
}
