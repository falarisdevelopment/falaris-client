package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3612;

public final class Jesus extends MovementModule {
    private final DoubleSetting surfaceLift = setting(new DoubleSetting("Surface Lift", "Upward velocity while in liquid.", 0.08, 0.01, 0.5));
    private final DoubleSetting surfaceSpeed = setting(new DoubleSetting("Surface Speed", "Horizontal speed on liquid.", 0.28, 0.05, 1.5));
    private final BooleanSetting water = setting(new BooleanSetting("Water", "Affect water.", true));
    private final BooleanSetting lava = setting(new BooleanSetting("Lava", "Affect lava.", false));
    private final BooleanSetting allowSneak = setting(new BooleanSetting("Allow Sneak", "Sneaking lets you sink.", true));

    public Jesus() {
        super("Jesus", "Helps the player stay on liquid surfaces.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }
        if (allowSneak.enabled() && client.field_1690.field_1832.method_1434()) {
            return;
        }

        class_2338 pos = client.field_1724.method_24515();
        boolean liquid = water.enabled() && client.field_1687.method_8316(pos).method_39360(class_3612.field_15910);
        liquid = liquid || lava.enabled() && client.field_1687.method_8316(pos).method_39360(class_3612.field_15908);
        if (!liquid) {
            return;
        }

        class_243 input = MovementUtil.inputVelocity(client.field_1724, surfaceSpeed.get(), false, client);
        client.field_1724.method_18800(input.field_1352, surfaceLift.get(), input.field_1350);
        client.field_1724.field_6017 = 0.0f;
    }
}
