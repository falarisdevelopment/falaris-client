package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class AntiBot extends MiscModule {
    private final BooleanSetting removeInvisible = setting(new BooleanSetting("Remove Invisible", "Remove invisible entities.", true));
    private final BooleanSetting removeNoName = setting(new BooleanSetting("Remove No Name", "Remove entities without nametag.", false));
    private final BooleanSetting removeDuplicates = setting(new BooleanSetting("Remove Duplicates", "Remove duplicate UUID entities.", true));
    private final BooleanSetting blockCombat = setting(new BooleanSetting("Block Combat Targeting", "Prevent bot targeting in combat modules.", true));
    private final ModeSetting detectionMode = setting(new ModeSetting("Detection Mode", "Bot detection method.", "Smart", "Smart", "Strict", "Prediction", "Off"));
    private final DoubleSetting predictionThreshold = setting(new DoubleSetting("Prediction Threshold", "Max position deviation before flagged.", 0.5, 0.1, 2.0));
    private final BooleanSetting namePatternCheck = setting(new BooleanSetting("Name Pattern Check", "Flag bots with auto-generated names.", true));
    private final BooleanSetting groundCheck = setting(new BooleanSetting("Ground Check", "Flag entities floating above blocks.", false));
    private final BooleanSetting duplicateCheck = setting(new BooleanSetting("Duplicate Check", "Flag exact position duplicates.", true));

    private final Set<UUID> knownPlayers = new HashSet<>();
    private final Map<UUID, class_243> previousPositions = new HashMap<>();
    private final Set<UUID> flaggedBots = new HashSet<>();
    private int tabRefreshTicks;

    public AntiBot() {
        super("AntiBot", "Filters bots from targeting and rendering using prediction, name patterns, tab list, and movement analysis.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        knownPlayers.clear();
        previousPositions.clear();
        flaggedBots.clear();
        tabRefreshTicks = 0;
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1687 == null || client.field_1724 == null) return;
        if (detectionMode.is("Off")) return;

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1657 player) || player == client.field_1724) continue;

            boolean isBot = false;

            // Duplicate UUID check
            if (removeDuplicates.enabled()) {
                if (knownPlayers.contains(player.method_5667())) continue;
                knownPlayers.add(player.method_5667());
            }

            // Name pattern check
            if (namePatternCheck.enabled() && !isBot) {
                String name = player.method_5477().getString();
                if (isGeneratedName(name)) isBot = true;
            }

            // Prediction-based detection
            if (detectionMode.is("Prediction") && !isBot) {
                class_243 prev = previousPositions.get(player.method_5667());
                class_243 current = new class_243(player.method_23317(), player.method_23318(), player.method_23321());
                if (prev != null) {
                    double expectedSpeed = 0.25;
                    double dist = prev.method_1022(current);
                    if (dist > expectedSpeed + predictionThreshold.get()) isBot = true;
                }
                previousPositions.put(player.method_5667(), current);
            }

            // Invisible check
            if (removeInvisible.enabled() && player.method_5767() && !isBot) isBot = true;

            // Strict: line of sight
            if (detectionMode.is("Strict") && !isBot) {
                if (!player.method_6057(client.field_1724)) isBot = true;
            }

            // Ground check
            if (groundCheck.enabled() && !isBot) {
                if (!player.method_24828() && player.method_18798().field_1351 == 0 && player.field_6017 == 0) isBot = true;
            }

            // Duplicate position check
            if (duplicateCheck.enabled() && !isBot) {
                for (class_1297 other : client.field_1687.method_18112()) {
                    if (other == player || !(other instanceof class_1657)) continue;
                    if (other.method_23317() == player.method_23317() && other.method_23318() == player.method_23318() && other.method_23321() == player.method_23321()
                        && !other.method_5667().equals(player.method_5667())) {
                        isBot = true;
                        break;
                    }
                }
            }

            if (isBot) {
                flaggedBots.add(player.method_5667());
                handleBot(client, player);
            }
        }
    }

    public boolean isBot(class_1297 entity) {
        if (detectionMode.is("Off")) return false;
        if (!blockCombat.enabled()) return false;
        if (!(entity instanceof class_1657)) return false;
        if (flaggedBots.contains(entity.method_5667())) return true;
        if (removeInvisible.enabled() && entity.method_5767()) return true;
        return false;
    }

    private boolean isGeneratedName(String name) {
        if (name.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")) return true;
        if (name.length() >= 8 && name.matches("[a-zA-Z0-9]+") && !name.matches(".*[aeiouAEIOU].*")) return true;
        if (name.startsWith("Bot_") || name.startsWith("bot_") || name.endsWith("_NPC") || name.endsWith("_bot")) return true;
        if (name.matches(".*[0-9]{4,}")) return true;
        return false;
    }

    private void handleBot(class_310 client, class_1657 bot) {
        if (removeInvisible.enabled() && bot.method_5767()) {
            client.field_1687.method_2945(bot.method_5628(), class_1297.class_5529.field_26999);
        }
    }
}
