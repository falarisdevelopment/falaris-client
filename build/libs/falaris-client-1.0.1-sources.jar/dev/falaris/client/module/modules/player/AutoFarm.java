package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class AutoFarm extends PlayerModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Reach to scan for crops.", 4.5, 1.0, 6.0));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between actions.", 2, 0, 10));
    private final BooleanSetting autoReplant = setting(new BooleanSetting("Auto Replant", "Plant seeds after harvesting.", true));
    private final BooleanSetting onlyHoe = setting(new BooleanSetting("Only Hoe", "Only harvest when holding a hoe.", true));

    private int tickCounter;

    public AutoFarm() {
        super("AutoFarm", "Automatically harvests and replants mature crops.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        tickCounter++;
        if (tickCounter < delay.get()) return;
        tickCounter = 0;

        if (onlyHoe.enabled() && !isHoldingHoe(client)) return;

        class_2338 origin = client.field_1724.method_24515();
        int r = (int) Math.ceil(range.get());

        for (class_2338 pos : class_2338.method_25996(origin, r, 2, r)) {
            if (client.field_1724.method_5707(class_243.method_24953(pos)) > range.get() * range.get()) continue;
            class_2680 state = client.field_1687.method_8320(pos);

            // Harvest mature crops
            if (state.method_26204() instanceof class_2302 crop) {
                if (crop.method_9825(state)) {
                    breakBlock(client, pos);
                    return;
                }
            }

            // Handle nether wart
            if (state.method_27852(class_2246.field_9974) && state.method_11654(net.minecraft.class_2421.field_11306) >= 3) {
                breakBlock(client, pos);
                return;
            }
        }
    }

    private void breakBlock(class_310 client, class_2338 pos) {
        for (class_2350 dir : class_2350.values()) {
            class_2338 neighbor = pos.method_10093(dir);
            if (!client.field_1687.method_8320(neighbor).method_26215()) {
                client.field_1761.method_2910(pos, dir);
                client.field_1724.method_6104(class_1268.field_5808);

                // Auto replant
                if (autoReplant.enabled()) {
                    int seedSlot = findSeeds(client);
                    if (seedSlot >= 0) {
                        client.field_1724.method_31548().method_61496(seedSlot);
                        class_243 hit = class_243.method_24953(neighbor).method_1019(class_243.method_24954(dir.method_10153().method_62675()).method_1021(0.5));
                        client.field_1761.method_2896(client.field_1724, class_1268.field_5808,
                            new class_3965(hit, dir.method_10153(), neighbor, false));
                    }
                }
                return;
            }
        }
    }

    private int findSeeds(class_310 client) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(class_1802.field_8317) || stack.method_31574(class_1802.field_8309)
                || stack.method_31574(class_1802.field_8567) || stack.method_31574(class_1802.field_8179)
                || stack.method_31574(class_1802.field_8790)) {
                return i;
            }
        }
        return -1;
    }

    private boolean isHoldingHoe(class_310 client) {
        class_1799 held = client.field_1724.method_6047();
        return held.method_31574(class_1802.field_8167) || held.method_31574(class_1802.field_8431)
            || held.method_31574(class_1802.field_8609) || held.method_31574(class_1802.field_8303)
            || held.method_31574(class_1802.field_8527) || held.method_31574(class_1802.field_22026);
    }
}
