package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Comparator;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class AutoElytraSpear extends MiscModule {
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Max target distance.", 40.0, 5.0, 80.0));
    private final DoubleSetting attackRange = setting(new DoubleSetting("Attack Range", "Range to strike.", 4.0, 2.0, 8.0));
    private final DoubleSetting diveRange = setting(new DoubleSetting("Dive Range", "Range to start dive.", 15.0, 5.0, 40.0));
    private final IntegerSetting fireworkDelay = setting(new IntegerSetting("Firework Delay", "Ticks between boosts.", 20, 5, 60));
    private final BooleanSetting autoEquip = setting(new BooleanSetting("Auto Equip", "Equip elytra from hotbar.", true));
    private final BooleanSetting autoStart = setting(new BooleanSetting("Auto Start", "Auto-start gliding when falling.", true));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Target players.", true));
    private final ModeSetting weapon = setting(new ModeSetting("Weapon", "Spear weapon.", "Trident", "Trident", "Mace", "Sword"));
    private final BooleanSetting fireworkBoost = setting(new BooleanSetting("Firework Boost", "Use rockets to dive.", true));
    private final IntegerSetting strafeInterval = setting(new IntegerSetting("Strafe Interval", "Ticks between strafe adjustments.", 10, 5, 30));

    private final Random random = new Random();
    private class_1309 target;
    private int fireworkTick;
    private int strafeTick;

    public AutoElytraSpear() {
        super("AutoElytraSpear", "Elytra combat with trident/spear dive attacks. Vape-style.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        target = null;
        fireworkTick = 0;
        strafeTick = 0;
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        fireworkTick++;
        strafeTick++;

        if (target == null || !target.method_5805() || client.field_1724.method_5858(target) > targetRange.get() * targetRange.get()) {
            target = findTarget(client);
        }
        if (target == null) return;

        if (autoEquip.enabled()) {
            int elytraSlot = findItem(client, class_1802.field_8833);
            if (elytraSlot != -1 && !client.field_1724.method_6118(net.minecraft.class_1304.field_6174).method_31574(class_1802.field_8833)) {
                selectSlot(client, elytraSlot);
            }
        }

        if (autoStart.enabled() && !client.field_1724.method_24828() && !client.field_1724.method_6128() && client.field_1724.method_18798().field_1351 < -0.3) {
            client.field_1724.field_3944.method_52787(new net.minecraft.class_2848(
                client.field_1724, net.minecraft.class_2848.class_2849.field_12982
            ));
        }

        if (!client.field_1724.method_6128()) return;

        double dist = client.field_1724.method_5739(target);

        if (fireworkBoost.enabled() && dist <= diveRange.get() && fireworkTick >= fireworkDelay.get()) {
            int fw = findItem(client, class_1802.field_8639);
            if (fw >= 0 && fw < 9) {
                selectSlot(client, fw);
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                fireworkTick = 0;
            }
        }

        if (dist <= attackRange.get()) {
            int spearSlot = findBestSpear(client);
            if (spearSlot >= 0 && spearSlot < 9) {
                client.field_1724.method_31548().method_61496(spearSlot);
            }
            if (ready(2, 1)) {
                class_243 look = target.method_33571();
                float[] rots = dev.falaris.client.module.modules.combat.CombatUtil.rotationsTo(client.field_1724, look);
                client.field_1724.method_36456(rots[0]);
                client.field_1724.method_36457(rots[1]);
                client.field_1761.method_2918(client.field_1724, target);
                client.field_1724.method_6104(class_1268.field_5808);
            }
        }

        if (strafeTick >= strafeInterval.get()) {
            strafeTick = 0;
            double dx = target.method_23317() - client.field_1724.method_23317();
            double dz = target.method_23321() - client.field_1724.method_23321();
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len > 0.1) {
                class_243 vel = client.field_1724.method_18798();
                class_243 toward = new class_243(dx / len * 0.3, -0.3, dz / len * 0.3);
                client.field_1724.method_18799(vel.method_1019(toward));
            }
        }
    }

    private class_1309 findTarget(class_310 client) {
        return client.field_1687.method_8390(class_1309.class, client.field_1724.method_5829().method_1014(targetRange.get()), entity -> {
            return entity != client.field_1724 && entity.method_5805()
                && (!(entity instanceof class_1657) || players.enabled());
        }).stream().min(Comparator.comparingDouble(client.field_1724::method_5739)).orElse(null);
    }

    private int findBestSpear(class_310 client) {
        net.minecraft.class_1792 targetItem = switch (weapon.get()) {
            case "Trident" -> class_1802.field_8547;
            case "Mace" -> class_1802.field_49814;
            default -> class_1802.field_8802;
        };
        return findItem(client, targetItem);
    }

    private int findItem(class_310 client, net.minecraft.class_1792 item) {
        for (int slot = 0; slot < 9; slot++) {
            if (client.field_1724.method_31548().method_5438(slot).method_31574(item)) return slot;
        }
        for (int slot = 9; slot < 36; slot++) {
            if (client.field_1724.method_31548().method_5438(slot).method_31574(item)) return slot;
        }
        return -1;
    }

    private void selectSlot(class_310 client, int slot) {
        if (slot >= 0 && slot < 9) {
            client.field_1724.method_31548().method_61496(slot);
        }
    }
}
