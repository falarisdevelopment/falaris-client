package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1802;
import net.minecraft.class_2828;
import net.minecraft.class_310;

public final class MaceVerticalControl extends MovementModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Vertical control method.", "Boost", "Boost", "Keep", "Strafing"));
    private final DoubleSetting strength = setting(new DoubleSetting("Strength", "Downward velocity strength.", 0.3, 0.05, 1.0));
    private final DoubleSetting minFallDist = setting(new DoubleSetting("Min Fall Dist", "Minimum fall distance to activate.", 2.0, 0.5, 8.0));
    private final BooleanSetting requireMace = setting(new BooleanSetting("Require Mace", "Only control vertical while holding mace.", true));
    private final BooleanSetting airControl = setting(new BooleanSetting("Air Control", "Allow horizontal movement control in air.", true));
    private final DoubleSetting airSpeed = setting(new DoubleSetting("Air Speed", "Horizontal air control factor.", 0.8, 0.1, 1.0));
    private final BooleanSetting autoSlam = setting(new BooleanSetting("Auto Slam", "Auto-slam down when above target.", false));
    private final DoubleSetting slamRange = setting(new DoubleSetting("Slam Range", "Range to detect targets below for slam.", 6.0, 2.0, 12.0));

    public MaceVerticalControl() {
        super("MaceVerticalControl", "Controls vertical movement for optimal mace slam combos.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (requireMace.enabled() && !client.field_1724.method_6047().method_31574(class_1802.field_49814)) return;
        if (client.field_1724.method_24828()) return;
        if (client.field_1724.field_6017 < minFallDist.get()) return;

        if (mode.is("Boost")) {
            if (client.field_1724.method_18798().field_1351 > -strength.get()) {
                client.field_1724.method_18800(
                    client.field_1724.method_18798().field_1352,
                    -strength.get(),
                    client.field_1724.method_18798().field_1350
                );
            }
        } else if (mode.is("Keep")) {
            double currentVy = client.field_1724.method_18798().field_1351;
            if (currentVy > -0.1) {
                client.field_1724.method_18800(
                    client.field_1724.method_18798().field_1352,
                    Math.min(currentVy, -0.1),
                    client.field_1724.method_18798().field_1350
                );
            }
        } else if (mode.is("Strafing")) {
            if (client.field_1724.method_18798().field_1351 > -strength.get() * 0.7) {
                client.field_1724.method_18800(
                    client.field_1724.method_18798().field_1352 * airSpeed.get(),
                    -strength.get() * 0.7,
                    client.field_1724.method_18798().field_1350 * airSpeed.get()
                );
            }
            if (airControl.enabled() && !client.field_1724.method_24828()) {
                double forward = client.field_1690.field_1894.method_1434() ? 1.0 : 0.0;
                forward -= client.field_1690.field_1881.method_1434() ? 1.0 : 0.0;
                double sideways = client.field_1690.field_1913.method_1434() ? 1.0 : 0.0;
                sideways -= client.field_1690.field_1849.method_1434() ? 1.0 : 0.0;
                if (forward != 0 || sideways != 0) {
                    double speed = airSpeed.get() * 0.3;
                    double length = Math.sqrt(forward * forward + sideways * sideways);
                    forward /= length;
                    sideways /= length;
                    double sin = Math.sin(Math.toRadians(client.field_1724.method_36454()));
                    double cos = Math.cos(Math.toRadians(client.field_1724.method_36454()));
                    double mx = (sideways * cos - forward * sin) * speed;
                    double mz = (forward * cos + sideways * sin) * speed;
                    client.field_1724.method_18800(mx, client.field_1724.method_18798().field_1351, mz);
                }
            }
        }

        if (autoSlam.enabled()) {
            client.field_1724.field_3944.method_52787(new class_2828.class_2829(
                client.field_1724.method_23317(),
                client.field_1724.method_23318() - 0.2,
                client.field_1724.method_23321(),
                false,
                client.field_1724.field_5976
            ));
        }
    }
}
