package dev.falaris.client.module.modules.client;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.gui.click.HudEditorScreen;
import dev.falaris.client.module.Category;
import dev.falaris.client.module.Module;
import net.minecraft.class_310;
import net.minecraft.class_408;

public final class HudEditor extends Module {
    public HudEditor() {
        super("HUD Editor", "Opens the HUD editor to resize and move on-screen modules.", Category.CLIENT);
    }

    @Override
    protected void onEnable() {
        class_310 client = class_310.method_1551();
        if (client.field_1755 instanceof class_408 || client.field_1755 instanceof HudEditorScreen) {
            setEnabled(false);
            return;
        }
        client.method_1507(new HudEditorScreen(FalarisClient.getInstance().getModuleManager()));
        setEnabled(false);
    }
}
