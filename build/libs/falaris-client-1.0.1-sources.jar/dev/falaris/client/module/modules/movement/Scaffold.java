package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class Scaffold extends MovementModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Placement reach.", 4.5, 1.0, 6.0));
    private final BooleanSetting swing = setting(new BooleanSetting("Swing", "Swing hand when placing.", true));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Auto-rotate towards block.", true));
    private final BooleanSetting tower = setting(new BooleanSetting("Tower", "Hold sneak to tower up.", true));
    private final ModeSetting towerMode = setting(new ModeSetting("Tower Mode", "Tower vertical movement method.", "Jump", "Jump", "Rubberband", "Fast", "None"));
    private final DoubleSetting towerSpeed = setting(new DoubleSetting("Tower Speed", "Blocks per second when towering.", 1.2, 0.5, 3.0));
    private final ModeSetting blockSelect = setting(new ModeSetting("Block Select", "Block selection mode.", "Any", "Any", "First", "Selected", "Obsidian", "Cobblestone", "End Stone", "Wood"));
    private final IntegerSetting placeDelay = setting(new IntegerSetting("Place Delay", "Ticks between placements.", 1, 0, 5));
    private final BooleanSetting placeOnEdge = setting(new BooleanSetting("Place on Edge", "Place blocks even when standing on edge.", true));
    private final ModeSetting placeMode = setting(new ModeSetting("Place Mode", "Where to place blocks.", "Below", "Below", "Side", "Both", "AirPlace"));

    private int tickCounter;

    public Scaffold() {
        super("Scaffold", "Places blocks beneath you automatically.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        tickCounter++;

        if (tower.enabled() && client.field_1690.field_1832.method_1434()) {
            if (!client.field_1724.method_24828()) return;
            String tm = towerMode.get();
            switch (tm) {
                case "Rubberband" -> {
                    client.field_1724.method_6043();
                    client.field_1724.method_18800(client.field_1724.method_18798().field_1352, 0.42 * towerSpeed.get(), client.field_1724.method_18798().field_1350);
                }
                case "Fast" -> {
                    client.field_1724.method_6043();
                    double vy = 0.42 * Math.min(towerSpeed.get(), 2.0);
                    client.field_1724.method_18800(client.field_1724.method_18798().field_1352, vy, client.field_1724.method_18798().field_1350);
                }
                default -> client.field_1724.method_6043();
            }
        }

        if (tickCounter % (placeDelay.get() + 1) != 0) return;

        class_2338 target = findTarget(client);
        if (target == null) return;

        int slot = findBlockSlot(client);
        if (slot == -1) return;

        int prev = client.field_1724.method_31548().method_67532();
        client.field_1724.method_31548().method_61496(slot);

        if (rotate.enabled() && slot != -1) {
            float[] rots = rotationsToBlock(client, target);
            rotations().setMaxStep(30f);
            rotations().rotateTo(rots[0], rots[1], 2);
        }

        placeBlock(client, target, slot);

        client.field_1724.method_31548().method_61496(prev);
    }

    private class_2338 findTarget(class_310 client) {
        class_243 pos = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
        String pm = placeMode.get();

        if (pm.equals("Side") || pm.equals("Both") || pm.equals("AirPlace")) {
            class_2338 sideTarget = findSideTarget(client);
            if (sideTarget != null) return sideTarget;
            if (pm.equals("Side")) return null;
        }

        class_2338 below = class_2338.method_49637(pos.field_1352, pos.field_1351 - 0.5, pos.field_1350);

        if (!client.field_1687.method_8320(below).method_26215() && !client.field_1687.method_8320(below).method_45474()) {
            return null;
        }

        if (pm.equals("AirPlace")) return below;

        for (class_2350 dir : class_2350.values()) {
            if (dir == class_2350.field_11036) continue;
            class_2338 neighbor = below.method_10093(dir);
            if (isValidNeighbor(client, neighbor)) {
                return below;
            }
        }

        if (!placeOnEdge.enabled()) return null;

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                class_2338 check = below.method_10069(dx, 0, dz);
                if (!client.field_1687.method_8320(check).method_26215() && !client.field_1687.method_8320(check).method_45474()) continue;
                for (class_2350 dir : class_2350.values()) {
                    if (dir == class_2350.field_11036) continue;
                    if (isValidNeighbor(client, check.method_10093(dir))) {
                        return check;
                    }
                }
            }
        }

        return null;
    }

    private class_2338 findSideTarget(class_310 client) {
        class_243 pos = client.field_1724.method_33571();
        class_243 look = client.field_1724.method_5828(1.0f);
        for (double d = 1.0; d <= range.get(); d += 1.0) {
            class_243 check = pos.method_1031(look.field_1352 * d, 0, look.field_1350 * d);
            class_2338 bp = class_2338.method_49638(check);
            if (client.field_1687.method_8320(bp).method_26215() || client.field_1687.method_8320(bp).method_45474()) {
                for (class_2350 dir : class_2350.values()) {
                    class_2338 neighbor = bp.method_10093(dir);
                    if (isValidNeighbor(client, neighbor)) {
                        return bp;
                    }
                }
            }
        }
        return null;
    }

    private boolean isValidNeighbor(class_310 client, class_2338 pos) {
        return client.field_1687.method_8320(pos).method_26212(client.field_1687, pos);
    }

    private int findBlockSlot(class_310 client) {
        for (int slot = 0; slot < 9; slot++) {
            if (client.field_1724.method_31548().method_5438(slot).method_7909() instanceof class_1747 bi) {
                class_2248 b = bi.method_7711();
                if (blockSelect.is("Selected") && !isPreferredBlock(b)) continue;
                if (!b.method_9564().method_51367()) continue;
                return slot;
            }
        }
        return -1;
    }

    private boolean isPreferredBlock(class_2248 b) {
        if (blockSelect.is("Obsidian")) return b == class_2246.field_10540;
        if (blockSelect.is("Cobblestone")) return b == class_2246.field_10445;
        if (blockSelect.is("End Stone")) return b == class_2246.field_10471;
        if (blockSelect.is("Wood")) return b == class_2246.field_10161 || b == class_2246.field_9975 || b == class_2246.field_10148;
        return b == class_2246.field_10540 || b == class_2246.field_10445 || b == class_2246.field_10340
                || b == class_2246.field_10471 || b == class_2246.field_10515 || b == class_2246.field_10566;
    }

    private boolean placeBlock(class_310 client, class_2338 pos, int slot) {
        if (client.field_1761 == null) return false;

        for (class_2350 dir : class_2350.values()) {
            if (dir == class_2350.field_11036) continue;
            class_2338 neighbor = pos.method_10093(dir);
            if (!client.field_1687.method_8320(neighbor).method_26212(client.field_1687, neighbor)) continue;

            class_243 hit = class_243.method_24953(neighbor);
            class_3965 hitResult = new class_3965(hit, dir.method_10153(), neighbor, false);

            class_1269 result = client.field_1761.method_2896(client.field_1724, class_1268.field_5808, hitResult);
            if (result.method_23665()) {
                client.field_1724.method_6104(class_1268.field_5808);
                return true;
            }
        }
        return false;
    }

    private float[] rotationsToBlock(class_310 client, class_2338 pos) {
        class_243 target = class_243.method_24953(pos);
        class_243 eyes = client.field_1724.method_33571();
        double dx = target.field_1352 - eyes.field_1352;
        double dy = target.field_1351 - eyes.field_1351;
        double dz = target.field_1350 - eyes.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);
        return new float[]{
                (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f,
                (float) -Math.toDegrees(Math.atan2(dy, dist))
        };
    }
}
