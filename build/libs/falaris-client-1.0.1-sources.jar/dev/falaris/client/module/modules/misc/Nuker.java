package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public final class Nuker extends MiscModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Block selection mode.", "Radius", "Radius", "Flatten", "Forward"));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum block break range.", 4.5, 1.0, 6.0));
    private final IntegerSetting blocksPerTick = setting(new IntegerSetting("Blocks/Tick", "Maximum break attempts per tick.", 2, 1, 12));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between nuker passes.", 1, 1, 20));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks between passes.", 1, 0, 10));
    private final BooleanSetting ignoreAir = setting(new BooleanSetting("Ignore Air", "Skip air and fluids.", true));
    private final BooleanSetting creativeOnly = setting(new BooleanSetting("Creative Only", "Only run while creative.", false));
    private final BooleanSetting instant = setting(new BooleanSetting("Instant", "Break blocks instantly (creative mode).", true));

    public Nuker() {
        super("Nuker", "Breaks nearby blocks according to a configured selection mode.");
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) {
            return;
        }
        if (creativeOnly.enabled() && !client.field_1724.method_31549().field_7477) {
            return;
        }
        if (!ready(delay.get(), jitter.get())) {
            return;
        }

        int broken = 0;
        int radius = (int) Math.ceil(range.get());
        class_2338 origin = client.field_1724.method_24515();
        for (class_2338 pos : class_2338.method_25996(origin, radius, radius, radius)) {
            if (broken >= blocksPerTick.get()) break;
            if (!allowed(client, pos)) continue;
            class_2350 side = sideFor(client.field_1724.method_33571(), class_243.method_24953(pos));

            if (instant.enabled() && client.field_1724.method_31549().field_7477) {
                client.field_1761.method_2910(pos, side);
            } else {
                client.field_1761.method_2910(pos, side);
                client.field_1761.method_2902(pos, side);
            }
            client.field_1724.method_6104(net.minecraft.class_1268.field_5808);
            broken++;
        }
    }

    private boolean allowed(class_310 client, class_2338 pos) {
        if (client.field_1724.method_5707(pos.method_46558()) > range.get() * range.get()) return false;
        if (mode.is("Flatten") && pos.method_10264() > client.field_1724.method_31478()) return false;
        if (mode.is("Forward")) {
            class_243 toBlock = pos.method_46558().method_1020(client.field_1724.method_33571()).method_1029();
            if (client.field_1724.method_5720().method_1026(toBlock) < 0.82) return false;
        }
        class_2680 state = client.field_1687.method_8320(pos);
        return !(ignoreAir.enabled() && (state.method_26215() || !state.method_26227().method_15769()));
    }

    private class_2350 sideFor(class_243 from, class_243 to) {
        class_243 diff = to.method_1020(from);
        return class_2350.method_10142(diff.field_1352, diff.field_1351, diff.field_1350);
    }
}
