package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_640;
import net.minecraft.class_7833;
import net.minecraft.class_7920;
import net.minecraft.class_8685;
import java.util.HashMap;
import java.util.Map;

public final class ClientDetector extends RenderModule {
    private final ModeSetting displayMode = setting(new ModeSetting("Display", "What to show next to nametag.", "Icon", "Icon", "Name", "Both"));
    private final BooleanSetting showSelf = setting(new BooleanSetting("Show Self", "Show your own detected client.", false));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Detection and render range.", 64.0, 8.0, 256.0));
    private final BooleanSetting colors = setting(new BooleanSetting("Colors", "Use colored client names/icons.", true));
    private final BooleanSetting cacheResults = setting(new BooleanSetting("Cache Results", "Cache detection results per player.", true));

    private final Map<String, DetectedClient> clientCache = new HashMap<>();
    private int cacheTick;

    public ClientDetector() {
        super("ClientDetector", "Detects other players' clients via visual indicators and shows icons next to nametags.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.method_1562() == null) return;

        double rangeSq = range.get() * range.get();

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1657 player)) continue;
            if (player == client.field_1724 && !showSelf.enabled()) continue;
            if (client.field_1724.method_5858(player) > rangeSq) continue;

            class_640 entry = client.method_1562().method_2871(player.method_5667());
            if (entry == null) continue;

            DetectedClient dc = detectClient(player, entry);
            String label = formatLabel(dc);
            if (label.isEmpty()) continue;

            drawClientLabel(context, player, label, colors.enabled() ? dc.color : 0xFFFFFFFF);
        }
    }

    private DetectedClient detectClient(class_1657 player, class_640 entry) {
        String uuid = player.method_5845();
        if (cacheResults.enabled() && clientCache.containsKey(uuid)) {
            return clientCache.get(uuid);
        }

        DetectedClient result = heuristicDetect(entry);

        if (cacheResults.enabled()) {
            clientCache.put(uuid, result);
        }
        return result;
    }

    private DetectedClient heuristicDetect(class_640 entry) {
        class_8685 skin = entry.method_52810();
        boolean hasCape = skin.comp_1627() != null;
        class_7920 modelType = skin.comp_1629();
        boolean slim = modelType == class_7920.field_41122;

        if (hasCape) {
            String capePath = skin.comp_1627().comp_3627().method_12832();

            if (capePath.contains("lunar")) {
                return new DetectedClient("Lunar", "\uD83C\uDF19", 0x44B3FF);
            }
            if (capePath.contains("badlion")) {
                return new DetectedClient("Badlion", "\uD83E\uDD81", 0xFF6B35);
            }
            if (capePath.contains("feather")) {
                return new DetectedClient("Feather", "\uD83E\uDEB8", 0x8B5CF6);
            }
            if (capePath.contains("labymod")) {
                return new DetectedClient("LabyMod", "\uD83D\uDD2C", 0x3B82F6);
            }
            if (capePath.contains("optifine")) {
                return new DetectedClient("OptiFine", "\u26A1", 0xFBBF24);
            }
            if (capePath.contains("minecraftcapes")) {
                return new DetectedClient("MC Capes", "\uD83C\uDF1F", 0xEC4899);
            }

            return new DetectedClient("Cape", "\uD83D\uDC54", 0x10B981);
        }

        if (slim) {
            return new DetectedClient("Slim", "\uD83D\uDC64", 0xA78BFA);
        }

        return new DetectedClient("Vanilla", "\uD83E\uDDCA", 0x9CA3AF);
    }

    private String formatLabel(DetectedClient dc) {
        return switch (displayMode.get()) {
            case "Icon" -> dc.icon;
            case "Name" -> dc.name;
            case "Both" -> dc.icon + " " + dc.name;
            default -> dc.icon;
        };
    }

    private void drawClientLabel(WorldRenderContext context, class_1657 player, String label, int color) {
        class_310 client = class_310.method_1551();
        class_327 textRenderer = client.field_1772;
        class_4587 matrices = context.matrices();

        class_243 cam = client.field_1773.method_19418().method_71156();
        double x = player.method_23317() - cam.field_1352;
        double y = player.method_23318() - cam.field_1351 + player.method_17682() + 0.7;
        double z = player.method_23321() - cam.field_1350;

        matrices.method_22903();
        matrices.method_22904(x, y, z);
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-client.field_1773.method_19418().method_19330()));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(client.field_1773.method_19418().method_19329()));
        matrices.method_22905(-0.025f, -0.025f, 0.025f);

        float fw = textRenderer.method_1727(label);
        textRenderer.method_27521(label, -fw / 2, 0, color, false, matrices.method_23760().method_23761(), context.consumers(),
            class_327.class_6415.field_33994, 0x00000000, 0xF000F0);

        matrices.method_22909();
    }

    @Override
    protected void onRenderTick(class_310 client) {
        cacheTick++;
        if (cacheTick > 100) {
            cacheTick = 0;
            if (cacheResults.enabled() && !clientCache.isEmpty()) {
                clientCache.clear();
            }
        }
    }

    private record DetectedClient(String name, String icon, int color) {}
}
