package dev.falaris.client.module.modules.player;

import net.minecraft.class_1294;
import net.minecraft.class_310;

public final class AntiLevitate extends PlayerModule {
    public AntiLevitate() {
        super("AntiLevitate", "Removes shulker levitation in end cities.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;
        client.field_1724.method_6016(class_1294.field_5902);
    }
}
