package dev.falaris.client.module.modules.player;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public final class AutoPot extends PlayerModule {
    private final DoubleSetting healthThreshold = setting(new DoubleSetting("Health Threshold", "Auto-heal when health below.", 10.0, 1.0, 20.0));
    private final BooleanSetting autoHealth = setting(new BooleanSetting("Auto Health", "Auto-splash health pots.", true));
    private final BooleanSetting autoSpeed = setting(new BooleanSetting("Auto Speed", "Auto-splash speed.", false));
    private final BooleanSetting autoStrength = setting(new BooleanSetting("Auto Strength", "Auto-splash strength.", false));
    private final BooleanSetting autoFireRes = setting(new BooleanSetting("Auto Fire Res", "Auto-splash fire resistance.", false));
    private final ModeSetting potMode = setting(new ModeSetting("Pot Mode", "Throw method.", "Normal", "Normal", "Legit", "Instant"));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between pots.", 10, 2, 40));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks.", 3, 0, 10));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Look down when throwing.", true));

    private final Random random = new Random();
    private int potCooldown;

    public AutoPot() {
        super("AutoPot", "Auto-splash potions for NoDebuff/Pot PvP.");
    }

    @Override
    protected void onEnable() { super.onEnable(); potCooldown = 0; }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (potCooldown > 0) { potCooldown--; return; }

        if (autoHealth.enabled() && client.field_1724.method_6032() + client.field_1724.method_6067() <= healthThreshold.get()) {
            if (throwPotion(client, findPotionWithEffect(client, class_1294.field_5915))) return;
        }
        if (autoSpeed.enabled() && !client.field_1724.method_6059(class_1294.field_5904)) {
            if (throwPotion(client, findPotionWithEffect(client, class_1294.field_5904))) return;
        }
        if (autoStrength.enabled() && !client.field_1724.method_6059(class_1294.field_5910)) {
            if (throwPotion(client, findPotionWithEffect(client, class_1294.field_5910))) return;
        }
        if (autoFireRes.enabled() && client.field_1724.method_5809() && !client.field_1724.method_6059(class_1294.field_5918)) {
            if (throwPotion(client, findPotionWithEffect(client, class_1294.field_5918))) return;
        }
    }

    private boolean throwPotion(class_310 client, int slot) {
        if (slot < 0) return false;
        int prev = client.field_1724.method_31548().method_67532();
        client.field_1724.method_31548().method_61496(slot);

        if (rotate.enabled()) {
            var rm = FalarisClient.getInstance().getRotationManager();
            rm.setMaxStep(90.0f);
            rm.rotateToSilent(client.field_1724.method_36454(), 90.0f, 1);
        }

        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
        client.field_1724.method_6104(class_1268.field_5808);

        client.field_1724.method_31548().method_61496(prev);
        potCooldown = delay.get() + random.nextInt(jitter.get() + 1);
        return true;
    }

    private int findPotionWithEffect(class_310 client, class_6880<net.minecraft.class_1291> effect) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_7960() || !stack.method_31574(class_1802.field_8436)) continue;
            class_1844 contents = stack.method_58694(class_9334.field_49651);
            if (contents == null) continue;
            if (contents.comp_2378().isPresent()) {
                var potion = contents.comp_2378().get().comp_349();
                for (class_1293 inst : potion.method_8049()) {
                    if (inst.method_5579() == effect) return i;
                }
            }
            for (class_1293 inst : contents.comp_2380()) {
                if (inst.method_5579() == effect) return i;
            }
        }
        return -1;
    }
}
