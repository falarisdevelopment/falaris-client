package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_310;

public final class FastUse extends PlayerModule {
    private final IntegerSetting speed = setting(new IntegerSetting("Speed", "Use speed multiplier in ticks.", 0, 0, 4));
    private final BooleanSetting fastPlace = setting(new BooleanSetting("Fast Place", "Remove block placement delay.", true));
    private final IntegerSetting itemUseTime = setting(new IntegerSetting("Item Use Time", "Ticks to cancel item use at.", 16, 0, 36));

    public FastUse() {
        super("FastUse", "Speeds up item usage like eating, blocking, and building.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        // Fast item use (eating, potions, etc.)
        if (client.field_1724.method_6115() && client.field_1724.method_6048() >= speed.get()) {
            client.field_1724.method_6075();
            client.field_1761.method_2897(client.field_1724);
        }

        // Fast block placement - reset right click delay timer
        if (fastPlace.enabled()) {
            try {
                java.lang.reflect.Field cooldownField = class_310.class.getDeclaredField("itemUseCooldown");
                cooldownField.setAccessible(true);
                cooldownField.setInt(client, 0);
            } catch (Exception ignored) {
            }
        }
    }
}
