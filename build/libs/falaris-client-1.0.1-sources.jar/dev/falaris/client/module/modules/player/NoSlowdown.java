package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_310;

public final class NoSlowdown extends PlayerModule {
    private static boolean active;

    private final ModeSetting mode = setting(new ModeSetting("Mode", "NoSlowdown mode.", "Vanilla", "Vanilla", "Legit", "Grim", "Vulcan"));
    private final DoubleSetting slowFactor = setting(new DoubleSetting("Slow Factor", "Movement speed while using items (Legit mode: 0.1-1.0).", 0.8, 0.1, 1.0));
    private final BooleanSetting onlySword = setting(new BooleanSetting("Only Sword", "Only apply when blocking with sword.", true));
    private final BooleanSetting consumeItems = setting(new BooleanSetting("Consume Items", "Apply when eating/drinking.", true));

    public NoSlowdown() {
        super("NoSlowdown", "Prevents slowdown while using items. Vanilla = full cancel, Legit = reduced slowdown.");
    }

    public static boolean shouldCancelSlowdown() {
        return active;
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;
        active = isEnabled() && client.field_1724.method_6115();

        if (!active) return;

        boolean isSwordBlock = client.field_1724.method_6030().method_31574(net.minecraft.class_1802.field_8255)
            || isSwordItem(client.field_1724.method_6030().method_7909());
        boolean isEating = client.field_1724.method_6030().method_57826(net.minecraft.class_9334.field_50075);

        if (onlySword.enabled() && !isSwordBlock) {
            active = false;
            return;
        }
        if (!consumeItems.enabled() && isEating) {
            active = false;
            return;
        }

        String m = mode.get();
        if (m.equals("Legit")) {
            // Mixin applies 5.0x counter in travel() head, so we undo part of it here
            float factor = slowFactor.get().floatValue();
            float restore = 1.0f - (1.0f - factor) * 0.8f;
            if (restore < 1.0f) {
                client.field_1724.method_18799(client.field_1724.method_18798().method_18805(restore, 1.0, restore));
            }
        }
    }

    private boolean isSwordItem(net.minecraft.class_1792 item) {
        return item == net.minecraft.class_1802.field_8091 || item == net.minecraft.class_1802.field_8528
            || item == net.minecraft.class_1802.field_8371 || item == net.minecraft.class_1802.field_8845
            || item == net.minecraft.class_1802.field_8802 || item == net.minecraft.class_1802.field_22022;
    }
}
