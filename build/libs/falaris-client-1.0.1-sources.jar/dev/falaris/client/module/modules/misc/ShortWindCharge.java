package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class ShortWindCharge extends MiscModule {
    private final BooleanSetting autoJump = setting(new BooleanSetting("Auto Jump", "Jump before wind charge for max height.", true));
    private final DoubleSetting minRange = setting(new DoubleSetting("Min Range", "Min enemy range to activate.", 3.0, 1.0, 10.0));
    private final IntegerSetting cooldown = setting(new IntegerSetting("Cooldown", "Ticks between uses.", 15, 5, 60));
    private final BooleanSetting onlyWhenTarget = setting(new BooleanSetting("Only When Target", "Only use when enemy nearby.", false));
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Target detection range.", 8.0, 2.0, 20.0));

    private int tickCounter;

    public ShortWindCharge() {
        super("ShortWindCharge", "Fires a wind charge at your feet to launch upward instantly.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        tickCounter = 0;
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null) return;
        tickCounter++;
        if (tickCounter < cooldown.get()) return;

        if (onlyWhenTarget.enabled()) {
            boolean found = client.field_1687 != null && client.field_1687.method_18456().stream()
                .anyMatch(p -> p != client.field_1724 && !p.method_29504() && client.field_1724.method_5739(p) < targetRange.get());
            if (!found) return;
        }

        if (client.field_1724.method_24828() && client.field_1690.field_1903.method_1434()) {
            int slot = findWindCharge(client);
            if (slot >= 0 && slot < 9) {
                client.field_1724.method_31548().method_61496(slot);
                if (autoJump.enabled()) {
                    client.field_1724.method_6043();
                }
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                tickCounter = 0;
            }
        }
    }

    private int findWindCharge(class_310 client) {
        for (int slot = 0; slot < 9; slot++) {
            if (client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_49098)) return slot;
        }
        return -1;
    }
}
