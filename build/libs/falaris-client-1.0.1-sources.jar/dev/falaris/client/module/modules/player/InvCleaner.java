package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Set;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class InvCleaner extends PlayerModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "What to clean.", "Trash", "Trash", "All", "Custom"));
    private final BooleanSetting autoDrop = setting(new BooleanSetting("Auto Drop", "Drop items automatically each tick.", false));
    private final BooleanSetting tools = setting(new BooleanSetting("Tools", "Drop tools (if Trash mode).", false));
    private final BooleanSetting armor = setting(new BooleanSetting("Armor", "Drop armor (if Trash mode).", false));
    private final IntegerSetting invCheckInterval = setting(new IntegerSetting("Check Interval", "Ticks between inventory scans.", 10, 2, 60));

    private static final Set<class_1792> TRASH = Set.of(
        class_1802.field_8831, class_1802.field_20412, class_1802.field_8110, class_1802.field_8858, class_1802.field_8200,
        class_1802.field_20394, class_1802.field_20401, class_1802.field_20407, class_1802.field_27021, class_1802.field_27020,
        class_1802.field_28866, class_1802.field_20391, class_1802.field_8328, class_1802.field_22000,
        class_1802.field_8511, class_1802.field_8680, class_1802.field_8635,
        class_1802.field_8107, class_1802.field_8606, class_1802.field_8276, class_1802.field_8153,
        class_1802.field_8745, class_1802.field_8389, class_1802.field_8046, class_1802.field_8726,
        class_1802.field_17532, class_1802.field_8158, class_1802.field_8600, class_1802.field_8145,
        class_1802.field_8803, class_1802.field_8794, class_1802.field_28410,
        class_1802.field_8317, class_1802.field_46250, class_1802.field_46249, class_1802.field_8309,
        class_1802.field_8116, class_1802.field_17531, class_1802.field_17520,
        class_1802.field_8583, class_1802.field_8684, class_1802.field_8170, class_1802.field_8125,
        class_1802.field_8820, class_1802.field_8652, class_1802.field_42692, class_1802.field_37512,
        class_1802.field_8118, class_1802.field_8113, class_1802.field_8191, class_1802.field_8842,
        class_1802.field_8651, class_1802.field_8404, class_1802.field_42687, class_1802.field_37507
    );

    public InvCleaner() {
        super("InvCleaner", "Automatically drops junk items from inventory.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (!autoDrop.enabled() || !ready(invCheckInterval.get(), 3)) return;

        for (int slot = 9; slot < 36; slot++) {
            class_1792 item = client.field_1724.method_31548().method_5438(slot).method_7909();
            if (shouldDrop(item)) {
                dropSlot(client.field_1724, slot);
                break;
            }
        }
        for (int slot = 0; slot < 9; slot++) {
            class_1792 item = client.field_1724.method_31548().method_5438(slot).method_7909();
            if (shouldDrop(item)) {
                dropSlot(client.field_1724, slot);
                break;
            }
        }
    }

    private boolean shouldDrop(class_1792 item) {
        return switch (mode.get()) {
            case "All" -> !tools.enabled() && isTool(item) || !armor.enabled() && isArmor(item) ? false : true;
            case "Trash" -> TRASH.contains(item);
            default -> false;
        };
    }

    private boolean isTool(class_1792 item) {
        return item == class_1802.field_8647 || item == class_1802.field_8387 || item == class_1802.field_8403
            || item == class_1802.field_8335 || item == class_1802.field_8377 || item == class_1802.field_22024
            || item == class_1802.field_8406 || item == class_1802.field_8062 || item == class_1802.field_8475
            || item == class_1802.field_8825 || item == class_1802.field_8556 || item == class_1802.field_22025
            || item == class_1802.field_8876 || item == class_1802.field_8776 || item == class_1802.field_8699
            || item == class_1802.field_8322 || item == class_1802.field_8250 || item == class_1802.field_22023
            || item == class_1802.field_8167 || item == class_1802.field_8431 || item == class_1802.field_8609
            || item == class_1802.field_8303 || item == class_1802.field_8527 || item == class_1802.field_22026;
    }

    private boolean isArmor(class_1792 item) {
        return item == class_1802.field_8267 || item == class_1802.field_8283 || item == class_1802.field_8743
            || item == class_1802.field_8862 || item == class_1802.field_8805 || item == class_1802.field_22027
            || item == class_1802.field_8577 || item == class_1802.field_8873 || item == class_1802.field_8523
            || item == class_1802.field_8678 || item == class_1802.field_8058 || item == class_1802.field_22028
            || item == class_1802.field_8570 || item == class_1802.field_8218 || item == class_1802.field_8396
            || item == class_1802.field_8416 || item == class_1802.field_8348 || item == class_1802.field_22029
            || item == class_1802.field_8370 || item == class_1802.field_8313 || item == class_1802.field_8660
            || item == class_1802.field_8753 || item == class_1802.field_8285 || item == class_1802.field_22030;
    }

    private void dropSlot(class_746 player, int slot) {
        if (class_310.method_1551().field_1761 != null) {
            class_310.method_1551().field_1761.method_2906(player.field_7512.field_7763, 36 + slot, 1, class_1713.field_7795, player);
        }
    }
}
