package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_239;
import net.minecraft.class_310;

public final class AutoSword extends PlayerModule {
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between weapon switches.", 1, 1, 20));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks between weapon switches.", 0, 0, 10));
    private final BooleanSetting allowAxes = setting(new BooleanSetting("Allow Axes", "Use axes if no sword is better.", true));
    private final BooleanSetting hotbarOnly = setting(new BooleanSetting("Hotbar Only", "Only select weapons already in the hotbar.", true));
    private final BooleanSetting requireEntity = setting(new BooleanSetting("Require Entity", "Only switch when looking at an entity.", true));
    private final BooleanSetting requireAttack = setting(new BooleanSetting("Require Attack", "Only switch while attacking.", true));

    public AutoSword() {
        super("AutoSword", "Selects the best hotbar weapon for attacks.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null || !ready(delay.get(), jitter.get())) {
            return;
        }
        if (requireAttack.enabled() && !client.field_1690.field_1886.method_1434()) {
            return;
        }
        if (requireEntity.enabled() && (client.field_1765 == null || client.field_1765.method_17783() != class_239.class_240.field_1331)) {
            return;
        }

        int best = InventoryUtil.findBestSword(client.field_1724, allowAxes.enabled(), hotbarOnly.enabled());
        if (best >= 0 && best <= 8) {
            InventoryUtil.selectHotbar(client.field_1724, best);
        } else if (!hotbarOnly.enabled() && best != -1) {
            InventoryUtil.quickMove(client, InventoryUtil.screenSlotForInventoryIndex(best));
        }
    }
}
