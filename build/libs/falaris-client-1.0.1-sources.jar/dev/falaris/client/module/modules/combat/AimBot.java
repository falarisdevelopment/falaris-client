package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class AimBot extends CombatModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum lock distance.", 6.0, 1.0, 12.0));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Maximum rotation step per tick.", 14.0, 1.0, 60.0));
    private final ModeSetting priority = setting(new ModeSetting("Priority", "Target sorting mode.", "Angle", "Distance", "Health", "Angle"));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Target players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Target hostile mobs.", true));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Target passive mobs.", false));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Allow targets without line of sight.", false));
    private final BooleanSetting focusBlocks = setting(new BooleanSetting("Focus Blocks", "Aim at the block you are mining.", false));
    private final DoubleSetting smoothing = setting(new DoubleSetting("Smoothing", "Higher = smoother but slower aim.", 3.0, 1.0, 15.0));

    private float prevYaw, prevPitch;
    private boolean hasPrev;

    public AimBot() {
        super("AimBot", "Smoothly locks view onto the best target.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        hasPrev = false;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) return;

        if (focusBlocks.enabled()) {
            handleBlockFocus(client);
            return;
        }

        class_1309 target = CombatUtil.bestLivingTarget(
                client, range.get(),
                players.enabled(), hostiles.enabled(), passives.enabled(),
                throughWalls.enabled(), priority.get()
        ).orElse(null);

        if (target == null) {
            hasPrev = false;
            return;
        }

        float[] rots = CombatUtil.rotationsTo(client.field_1724, target.method_33571());

        float targetYaw = rots[0];
        float targetPitch = rots[1];

        if (!hasPrev) {
            prevYaw = client.field_1724.method_36454();
            prevPitch = client.field_1724.method_36455();
            hasPrev = true;
        }

        float step = rotationSpeed.get().floatValue();
        smoothRotate(client, targetYaw, targetPitch, step);
    }

    private void smoothRotate(class_310 client, float targetYaw, float targetPitch, float step) {
        float yawDelta = class_3532.method_15393(targetYaw - prevYaw);
        float pitchDelta = targetPitch - prevPitch;

        float smoothFactor = smoothing.get().floatValue();
        float smoothYaw = prevYaw + class_3532.method_15363(yawDelta / smoothFactor, -step, step);
        float smoothPitch = prevPitch + class_3532.method_15363(pitchDelta / smoothFactor, -step, step);

        prevYaw = smoothYaw;
        prevPitch = smoothPitch;

        client.field_1724.method_36456(smoothYaw);
        client.field_1724.method_36457(class_3532.method_15363(smoothPitch, -90.0f, 90.0f));
    }

    private void handleBlockFocus(class_310 client) {
        try {
            java.lang.reflect.Field field = client.field_1761.getClass().getDeclaredField("currentBreakingPos");
            field.setAccessible(true);
            net.minecraft.class_2338 breakingPos = (net.minecraft.class_2338) field.get(client.field_1761);
            if (breakingPos == null && client.field_1765 != null && client.field_1765.method_17783() == class_239.class_240.field_1332) {
                breakingPos = ((net.minecraft.class_3965) client.field_1765).method_17777();
            }
            if (breakingPos != null && !client.field_1687.method_8320(breakingPos).method_26215()) {
                float[] rots = CombatUtil.rotationsTo(client.field_1724, breakingPos.method_46558());
                smoothRotate(client, rots[0], rots[1], rotationSpeed.get().floatValue());
            }
        } catch (Exception ignored) {}
    }
}
