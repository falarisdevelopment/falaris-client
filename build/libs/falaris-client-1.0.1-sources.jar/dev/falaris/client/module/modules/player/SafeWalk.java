package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_2338;
import net.minecraft.class_310;

public final class SafeWalk extends PlayerModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Safety method.", "Sneak", "Sneak", "Legit", "Edge"));
    private final BooleanSetting slow = setting(new BooleanSetting("Slow", "Slow down on edges.", true));
    private final BooleanSetting onlySneaking = setting(new BooleanSetting("Only While Sneaking", "Only activate when already sneaking.", false));

    public SafeWalk() {
        super("SafeWalk", "Prevents you from walking off edges.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (onlySneaking.enabled() && !client.field_1690.field_1832.method_1434()) return;

        if (!client.field_1724.method_24828()) return;

        if (mode.is("Sneak")) {
            client.field_1724.method_5660(true);
        } else if (mode.is("Legit")) {
            if (isAtEdge(client)) {
                client.field_1724.method_5660(true);
            }
        } else if (mode.is("Edge")) {
            if (isAtEdge(client)) {
                client.field_1724.method_18800(client.field_1724.method_18798().field_1352, -0.1, client.field_1724.method_18798().field_1350);
            }
        }
    }

    private boolean isAtEdge(class_310 client) {
        double x = client.field_1724.method_23317();
        double z = client.field_1724.method_23321();
        double y = client.field_1724.method_23318() - 0.5;

        var world = client.field_1687;
        if (world == null) return false;

        return world.method_8320(class_2338.method_49637(x - 0.3, y, z - 0.3)).method_26215()
                || world.method_8320(class_2338.method_49637(x + 0.3, y, z - 0.3)).method_26215()
                || world.method_8320(class_2338.method_49637(x - 0.3, y, z + 0.3)).method_26215()
                || world.method_8320(class_2338.method_49637(x + 0.3, y, z + 0.3)).method_26215();
    }
}
