package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_2586;
import net.minecraft.class_2589;
import net.minecraft.class_2595;
import net.minecraft.class_2601;
import net.minecraft.class_2608;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_310;
import net.minecraft.class_3719;
import net.minecraft.class_3866;

public final class StorageESP extends RenderModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum storage render range.", 96.0, 8.0, 256.0));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Show storage through walls.", true));
    private final BooleanSetting chests = setting(new BooleanSetting("Chests", "Highlight chests (yellow).", true));
    private final BooleanSetting barrels = setting(new BooleanSetting("Barrels", "Highlight barrels.", true));
    private final BooleanSetting shulkers = setting(new BooleanSetting("Shulkers", "Highlight shulker boxes.", true));
    private final BooleanSetting enderChests = setting(new BooleanSetting("Ender Chests", "Highlight ender chests (purple).", true));
    private final BooleanSetting furnaces = setting(new BooleanSetting("Furnaces", "Highlight furnaces, smokers, blast furnaces.", false));
    private final BooleanSetting other = setting(new BooleanSetting("Other", "Highlight hoppers, dispensers, droppers, brewing stands.", false));

    public StorageESP() {
        super("StorageESP", "Highlights storage block entities through walls with color coding.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        boolean tw = throughWalls.enabled();
        for (class_2586 blockEntity : client.field_1687.method_72019()) {
            if (client.field_1724.method_5707(blockEntity.method_11016().method_46558()) > range.get() * range.get()) {
                continue;
            }
            RenderUtil.Color color = color(blockEntity);
            if (color != null) {
                RenderUtil.drawBlockBox(context, blockEntity.method_11016(), color, tw);
            }
        }
    }

    private RenderUtil.Color color(class_2586 entity) {
        if (entity instanceof class_2595 && chests.enabled()) {
            return RenderUtil.Color.rgba(255, 215, 0, 220);
        }
        if (entity instanceof class_2611 && enderChests.enabled()) {
            return RenderUtil.Color.rgba(140, 60, 220, 220);
        }
        if (entity instanceof class_2627 && shulkers.enabled()) {
            return RenderUtil.Color.rgba(178, 112, 255, 220);
        }
        if (entity instanceof class_3719 && barrels.enabled()) {
            return RenderUtil.Color.rgba(180, 132, 88, 220);
        }
        if (entity instanceof class_3866 && furnaces.enabled()) {
            return RenderUtil.Color.rgba(200, 120, 80, 220);
        }
        if ((entity instanceof class_2614 || entity instanceof class_2601
                || entity instanceof class_2608 || entity instanceof class_2589) && other.enabled()) {
            return RenderUtil.Color.rgba(160, 160, 160, 220);
        }
        return null;
    }
}
