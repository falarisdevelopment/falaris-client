package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import dev.falaris.client.setting.StringSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class BlockESP extends RenderModule {
    private final ModeSetting blockPreset = setting(new ModeSetting("Block Preset", "Predefined block groups or custom.", "Custom",
            "Ores", "Rare Ores", "All Ores", "Diamonds", "Netherite", "Emeralds", "Iron", "Gold", "Lapis", "Redstone", "Coal",
            "Ancient Debris", "Chests", "Spawners", "Bookshelves", "Crafting", "Custom"));
    private final StringSetting blocks = setting(new StringSetting("Blocks",
            "Comma-separated block IDs. Type any block from the game (e.g. minecraft:ancient_debris,minecraft:diamond_block).",
            "minecraft:diamond_ore,minecraft:deepslate_diamond_ore,minecraft:ancient_debris"));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Show blocks through walls.", true));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Block scan range.", 32.0, 4.0, 128.0));

    public BlockESP() {
        super("BlockESP", "Highlights any blocks you choose. Type any block ID in the Blocks field.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        Set<class_2248> targets = parseTargets();
        if (targets.isEmpty()) return;
        int radius = (int) Math.ceil(range.get());
        class_2338 origin = client.field_1724.method_24515();
        boolean tw = throughWalls.enabled();
        for (class_2338 pos : class_2338.method_25996(origin, radius, radius, radius)) {
            if (client.field_1724.method_5707(pos.method_46558()) > range.get() * range.get()) continue;
            if (targets.contains(client.field_1687.method_8320(pos).method_26204())) {
                RenderUtil.drawBlockBox(context, pos, RenderUtil.Color.rgba(118, 156, 255, 220), tw);
            }
        }
    }

    private Set<class_2248> parseTargets() {
        if (!blockPreset.is("Custom")) {
            return getPresetBlocks();
        }
        Set<class_2248> result = new HashSet<>();
        for (String raw : blocks.get().split(",")) {
            String id = raw.trim().toLowerCase(Locale.ROOT);
            if (!id.isEmpty()) {
                class_7923.field_41175.method_17966(class_2960.method_60654(id)).ifPresent(result::add);
            }
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    private Set<class_2248> getPresetBlocks() {
        return switch (blockPreset.get()) {
            case "Ores" -> Set.of(
                class_2246.field_10442, class_2246.field_29029,
                class_2246.field_10013, class_2246.field_29220,
                class_2246.field_10212, class_2246.field_29027,
                class_2246.field_10571, class_2246.field_29026,
                class_2246.field_27120, class_2246.field_29221,
                class_2246.field_10418, class_2246.field_29219,
                class_2246.field_10090, class_2246.field_29028,
                class_2246.field_10080, class_2246.field_29030,
                class_2246.field_23077, class_2246.field_10213,
                class_2246.field_22109
            );
            case "Rare Ores" -> Set.of(
                class_2246.field_10442, class_2246.field_29029,
                class_2246.field_10013, class_2246.field_29220,
                class_2246.field_22109
            );
            case "All Ores" -> Set.of(
                class_2246.field_10442, class_2246.field_29029,
                class_2246.field_10013, class_2246.field_29220,
                class_2246.field_10212, class_2246.field_29027,
                class_2246.field_10571, class_2246.field_29026,
                class_2246.field_27120, class_2246.field_29221,
                class_2246.field_10418, class_2246.field_29219,
                class_2246.field_10090, class_2246.field_29028,
                class_2246.field_10080, class_2246.field_29030,
                class_2246.field_23077, class_2246.field_10213,
                class_2246.field_22109,
                class_2246.field_22108, class_2246.field_10201,
                class_2246.field_10234, class_2246.field_10085, class_2246.field_10205
            );
            case "Diamonds" -> Set.of(class_2246.field_10442, class_2246.field_29029, class_2246.field_10201);
            case "Netherite" -> Set.of(class_2246.field_22109, class_2246.field_22108);
            case "Emeralds" -> Set.of(class_2246.field_10013, class_2246.field_29220, class_2246.field_10234);
            case "Iron" -> Set.of(class_2246.field_10212, class_2246.field_29027, class_2246.field_10085, class_2246.field_33508);
            case "Gold" -> Set.of(class_2246.field_10571, class_2246.field_29026, class_2246.field_10205, class_2246.field_33510, class_2246.field_23077);
            case "Lapis" -> Set.of(class_2246.field_10090, class_2246.field_29028, class_2246.field_10441);
            case "Redstone" -> Set.of(class_2246.field_10080, class_2246.field_29030, class_2246.field_10002);
            case "Coal" -> Set.of(class_2246.field_10418, class_2246.field_29219, class_2246.field_10381);
            case "Ancient Debris" -> Set.of(class_2246.field_22109);
            case "Chests" -> Set.of(class_2246.field_10034, class_2246.field_10380, class_2246.field_16328);
            case "Spawners" -> Set.of(class_2246.field_10260, class_2246.field_47336);
            case "Bookshelves" -> Set.of(class_2246.field_10504, class_2246.field_40276, class_2246.field_16330, class_2246.field_10485);
            case "Crafting" -> Set.of(class_2246.field_9980, class_2246.field_10535, class_2246.field_10105, class_2246.field_10414,
                class_2246.field_16337, class_2246.field_16329, class_2246.field_10181, class_2246.field_16333, class_2246.field_16334);
            default -> Set.of();
        };
    }
}
