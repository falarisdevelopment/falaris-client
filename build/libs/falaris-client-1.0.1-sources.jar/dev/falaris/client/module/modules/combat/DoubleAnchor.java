package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4969;

public final class DoubleAnchor extends CombatModule {
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Max target distance.", 6.0, 1.0, 10.0));
    private final DoubleSetting actionRange = setting(new DoubleSetting("Action Range", "Max anchor interaction distance.", 3.0, 1.0, 4.0));
    private final DoubleSetting minDamage = setting(new DoubleSetting("Min Damage", "Minimum per anchor damage.", 5.0, 1.0, 20.0));
    private final DoubleSetting maxSelfDamage = setting(new DoubleSetting("Max Self Damage", "Max total self damage.", 10.0, 1.0, 20.0));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Max rotation per tick.", 18.0, 1.0, 60.0));
    private final IntegerSetting actionJitter = setting(new IntegerSetting("Action Jitter", "Extra ticks between phases.", 2, 0, 10));
    private final BooleanSetting safeAnchor = setting(new BooleanSetting("Safe Anchor", "Skip if self damage > max.", true));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Face anchor.", true));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Target through blocks.", false));

    public DoubleAnchor() {
        super("DoubleAnchor", "Places two anchors and detonates both instantly for massive burst damage.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_1309 target = CombatUtil.bestLivingTarget(client, targetRange.get(), true, true, false, throughWalls.enabled(), "Distance").orElse(null);
        if (target == null) return;

        List<class_2338> charged = findChargedAnchorsNearTarget(client, target);
        if (charged.size() >= 2) {
            detonateAnchors(client, charged);
            return;
        }

        List<class_2338> uncharged = findUnchargedAnchorsNearTarget(client, target);
        int needed = 2 - charged.size();
        int charged_count = chargeAnchors(client, uncharged, needed);

        if (charged.size() + charged_count >= 2) {
            List<class_2338> allCharged = findChargedAnchorsNearTarget(client, target);
            detonateAnchors(client, allCharged);
            return;
        }

        int toPlace = 2 - (charged.size() + charged_count);
        placeAnchors(client, target, toPlace);
    }

    private List<class_2338> findChargedAnchorsNearTarget(class_310 client, class_1309 target) {
        List<class_2338> list = new ArrayList<>();
        int radius = (int) Math.ceil(actionRange.get());
        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 3, radius)) {
            class_2680 state = client.field_1687.method_8320(pos);
            if (!state.method_27852(class_2246.field_23152)) continue;
            int charges = state.method_11654(class_4969.field_23153);
            if (charges <= 0) continue;
            class_243 center = class_243.method_24953(pos);
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            if (estimatedDamage(class_243.method_24953(target.method_24515()), center) < minDamage.get()) continue;
            if (safeAnchor.enabled()) {
                double self = estimatedDamage(class_243.method_24953(client.field_1724.method_24515()), center);
                if (self > maxSelfDamage.get()) continue;
            }
            list.add(pos.method_10062());
        }
        return list;
    }

    private List<class_2338> findUnchargedAnchorsNearTarget(class_310 client, class_1309 target) {
        List<class_2338> list = new ArrayList<>();
        int radius = (int) Math.ceil(actionRange.get());
        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 3, radius)) {
            class_2680 state = client.field_1687.method_8320(pos);
            if (!state.method_27852(class_2246.field_23152)) continue;
            int charges = state.method_11654(class_4969.field_23153);
            if (charges >= 4) continue;
            class_243 center = class_243.method_24953(pos);
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            if (estimatedDamage(class_243.method_24953(target.method_24515()), center) < minDamage.get()) continue;
            if (safeAnchor.enabled()) {
                double self = estimatedDamage(class_243.method_24953(client.field_1724.method_24515()), center);
                if (self > maxSelfDamage.get()) continue;
            }
            list.add(pos.method_10062());
        }
        return list;
    }

    private void detonateAnchors(class_310 client, List<class_2338> anchors) {
        for (class_2338 pos : anchors) {
            class_243 center = class_243.method_24953(pos);
            if (rotate.enabled()) {
                float[] rots = CombatUtil.rotationsTo(client.field_1724, center);
                client.field_1724.method_36456(rots[0]);
                client.field_1724.method_36457(rots[1]);
            }
            int heldSlot = client.field_1724.method_31548().method_67532();
            int nonGlowstone = findNonGlowstoneSlot(client);
            if (nonGlowstone >= 0) {
                client.field_1724.method_31548().method_61496(nonGlowstone);
            }
            if (actionReady(1, actionJitter.get())) {
                CombatUtil.interactBlock(client, pos, class_2350.field_11036);
            }
            client.field_1724.method_31548().method_61496(heldSlot);
        }
    }

    private int chargeAnchors(class_310 client, List<class_2338> uncharged, int needed) {
        int charged = 0;
        int glowstoneSlot = CombatUtil.findItem(client.field_1724, class_1802.field_8801);
        if (glowstoneSlot == -1) return 0;

        for (class_2338 pos : uncharged) {
            if (charged >= needed) break;
            class_243 center = class_243.method_24953(pos);
            if (rotate.enabled()) {
                float[] rots = CombatUtil.rotationsTo(client.field_1724, center);
                client.field_1724.method_36456(rots[0]);
                client.field_1724.method_36457(rots[1]);
            }
            if (actionReady(2, actionJitter.get())) {
                CombatUtil.selectHotbarSlot(client.field_1724, glowstoneSlot);
                CombatUtil.interactBlock(client, pos, class_2350.field_11036);
                charged++;
            }
        }
        return charged;
    }

    private void placeAnchors(class_310 client, class_1309 target, int count) {
        int anchorSlot = CombatUtil.findItem(client.field_1724, class_1802.field_23141);
        if (anchorSlot == -1) return;

        int radius = (int) Math.ceil(actionRange.get());
        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 2, radius)) {
            if (count <= 0) break;
            if (!client.field_1687.method_8320(pos).method_26215()) continue;
            if (client.field_1687.method_8320(pos.method_10074()).method_26215()) continue;
            class_243 center = class_243.method_24953(pos);
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            if (estimatedDamage(class_243.method_24953(target.method_24515()), center) < minDamage.get()) continue;
            if (safeAnchor.enabled()) {
                double self = estimatedDamage(class_243.method_24953(client.field_1724.method_24515()), center);
                if (self > maxSelfDamage.get()) continue;
            }
            if (rotate.enabled()) {
                float[] rots = CombatUtil.rotationsTo(client.field_1724, center);
                client.field_1724.method_36456(rots[0]);
                client.field_1724.method_36457(rots[1]);
            }
            if (actionReady(2, actionJitter.get())) {
                CombatUtil.selectHotbarSlot(client.field_1724, anchorSlot);
                CombatUtil.interactBlock(client, pos, class_2350.field_11036);
                count--;
            }
        }
    }

    private int findNonGlowstoneSlot(class_310 client) {
        for (int slot = 0; slot < 9; slot++) {
            if (!client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8801)) return slot;
        }
        return -1;
    }

    private double estimatedDamage(class_243 target, class_243 anchor) {
        double distance = target.method_1022(anchor);
        return Math.max(0.0, 10.0 - distance * 1.8);
    }
}
