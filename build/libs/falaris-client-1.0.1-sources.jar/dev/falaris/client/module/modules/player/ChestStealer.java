package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_310;

public final class ChestStealer extends PlayerModule {
    private final BooleanSetting silent = setting(new BooleanSetting("Silent", "Close screen after stealing.", true));
    private final BooleanSetting ignorePlayerInv = setting(new BooleanSetting("Ignore Player Inv", "Only steal from chest slots.", true));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between item moves.", 2, 0, 10));

    private int tickCounter;

    public ChestStealer() {
        super("ChestStealer", "Automatically takes all items from opened chests.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        tickCounter = 0;
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        class_1703 handler = client.field_1724.field_7512;
        if (!(handler instanceof class_1707 container)) return;

        tickCounter++;
        if (tickCounter < delay.get() + 1) return;
        tickCounter = 0;

        int rows = container.method_17388();
        int chestSlots = rows * 9;
        int playerInvStart = chestSlots;

        for (int slot = 0; slot < chestSlots; slot++) {
            if (!container.method_7611(slot).method_7681()) continue;
            if (ignorePlayerInv.enabled() && slot < playerInvStart) {
                client.field_1761.method_2906(handler.field_7763, slot, 0, class_1713.field_7794, client.field_1724);
                return;
            }
        }

        if (silent.enabled()) {
            boolean empty = true;
            for (int slot = 0; slot < chestSlots; slot++) {
                if (container.method_7611(slot).method_7681()) {
                    empty = false;
                    break;
                }
            }
            if (empty) {
                client.field_1724.method_7346();
            }
        }
    }
}
