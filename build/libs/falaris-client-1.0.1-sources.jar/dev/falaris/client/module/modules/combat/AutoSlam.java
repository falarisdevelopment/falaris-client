package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class AutoSlam extends CombatModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Attack mode.", "Slam", "Slam", "Axe Stun", "Axe Slam"));
    private final DoubleSetting minFallDist = setting(new DoubleSetting("Min Fall Dist", "Minimum fall distance for mace bonus.", 3.0, 1.0, 10.0));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Attack range.", 3.0, 1.0, 3.5));
    private final BooleanSetting autoSwitch = setting(new BooleanSetting("Auto Switch", "Swap to mace/axe.", true));
    private final BooleanSetting onlyWhenBlocking = setting(new BooleanSetting("Only When Blocking", "Only attack blocking targets.", false));
    private final BooleanSetting requireBelow = setting(new BooleanSetting("Require Below", "Only targets below you.", true));
    private final IntegerSetting verticalRange = setting(new IntegerSetting("Vertical Range", "Max Y difference.", 3, 1, 6));
    private final IntegerSetting stunSwitchDelay = setting(new IntegerSetting("Stun Switch Delay", "Ticks between axe stun and mace.", 5, 1, 20));
    private final BooleanSetting silentRotate = setting(new BooleanSetting("Silent Rotate", "Face target.", true));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Rotation speed.", 20.0, 1.0, 60.0));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anti-cheat.", "Vanilla", "Vanilla", "Vanilla", "Ghost"));

    private boolean stunned;
    private int stunTicker;
    private final Random random = new Random();

    public AutoSlam() {
        super("AutoSlam", "Slams targets with mace; Axe Stun mode uses axe shield-stun then mace.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        stunned = false;
        stunTicker = 0;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        boolean isFalling = !client.field_1724.method_24828() && client.field_1724.method_18798().field_1351 < -0.1;
        if (mode.is("Slam") || mode.is("Axe Slam")) {
            if (!isFalling && client.field_1724.field_6017 < minFallDist.get()) return;
        }

        class_1309 target = CombatUtil.bestLivingTarget(client, range.get(), true, true, false, false, "Distance").orElse(null);
        if (target == null) return;
        if (onlyWhenBlocking.enabled() && !target.method_6039()) return;

        if (requireBelow.enabled()) {
            double dy = target.method_23318() - client.field_1724.method_23318();
            if (dy > 0 || Math.abs(dy) > verticalRange.get()) return;
        }

        boolean isGhost = bypass.is("Ghost");

        // Rotate toward target
        if (silentRotate.enabled()) {
            float[] rots = CombatUtil.rotationsTo(client.field_1724, target.method_33571());
            rotations().setMaxStep(rotationSpeed.get().floatValue());
            int ticks = isGhost ? 2 + random.nextInt(2) : 1;
            rotations().rotateToSilent(rots[0], rots[1], ticks);
        }

        // Axe stun logic
        if (mode.is("Axe Stun") || mode.is("Axe Slam")) {
            if (!stunned && target.method_6039()) {
                if (autoSwitch.enabled()) {
                    int axeSlot = findAxe(client);
                    if (axeSlot >= 0 && axeSlot < 9) {
                        client.field_1724.method_31548().method_61496(axeSlot);
                    }
                }
                CombatUtil.attack(client, target);
                stunned = true;
                stunTicker = 0;
                return;
            }

            if (stunned) {
                stunTicker++;
                if (stunTicker >= stunSwitchDelay.get()) {
                    stunned = false;
                    if (mode.is("Axe Stun")) return;
                    if (autoSwitch.enabled()) {
                        int maceSlot = findMace(client);
                        if (maceSlot >= 0 && maceSlot < 9) {
                            client.field_1724.method_31548().method_61496(maceSlot);
                        }
                    }
                } else {
                    return;
                }
            }
        }

        if (!mode.is("Axe Stun") && autoSwitch.enabled()) {
            boolean alreadyMace = client.field_1724.method_6047().method_31574(class_1802.field_49814);
            if (!alreadyMace) {
                int maceSlot = findMace(client);
                if (maceSlot >= 0 && maceSlot < 9) {
                    client.field_1724.method_31548().method_61496(maceSlot);
                }
            }
        }

        int delay = isGhost ? 1 + random.nextInt(2) : 0;
        if (actionReady(1 + delay, 0)) {
            CombatUtil.attack(client, target);
        }
    }

    private int findMace(class_310 client) {
        for (int slot = 0; slot < 9; slot++) {
            if (client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_49814)) return slot;
        }
        return -1;
    }

    private int findAxe(class_310 client) {
        int best = -1;
        double bestScore = -1;
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(slot);
            if (stack.method_7909() instanceof class_1743) {
                double score = stack.method_7936() - stack.method_7919();
                if (score > bestScore) { bestScore = score; best = slot; }
            }
        }
        return best;
    }
}
