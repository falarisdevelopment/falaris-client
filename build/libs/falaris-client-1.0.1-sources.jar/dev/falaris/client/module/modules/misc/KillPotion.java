package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_2873;
import net.minecraft.class_310;
import net.minecraft.class_9334;

public final class KillPotion extends MiscModule {
    private final ModeSetting potionType = setting(new ModeSetting("Potion Type", "Generated potion item type.", "Splash", "Splash", "Lingering", "Drinkable"));
    private final IntegerSetting amplifier = setting(new IntegerSetting("Amplifier", "Instant damage amplifier.", 125, 1, 255));
    private final IntegerSetting count = setting(new IntegerSetting("Count", "Generated stack count.", 1, 1, 64));
    private final BooleanSetting requireCreative = setting(new BooleanSetting("Require Creative", "Only generate while in creative.", true));
    private boolean generated;

    public KillPotion() {
        super("KillPotion", "Generates an OP-only creative test potion with high instant damage.");
    }

    @Override
    protected void onEnable() {
        generated = false;
        super.onEnable();
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (generated || client.field_1724 == null || client.field_1724.field_3944 == null) {
            return;
        }
        if (requireCreative.enabled() && !client.field_1724.method_31549().field_7477) {
            client.field_1724.method_7353(class_2561.method_43470("[Falaris] KillPotion requires creative mode or OP creative permissions."), false);
            generated = true;
            setEnabled(false);
            return;
        }

        class_1799 stack = createPotion();
        int selectedSlot = client.field_1724.method_31548().method_67532();
        int slot = 36 + selectedSlot;
        client.field_1724.method_31548().method_5447(selectedSlot, stack);
        client.field_1724.field_3944.method_52787(new class_2873(slot, stack));
        client.field_1724.method_7353(class_2561.method_43470("[Falaris] Generated creative test kill potion in your selected hotbar slot."), false);
        generated = true;
        setEnabled(false);
    }

    private class_1799 createPotion() {
        class_1792 item = switch (potionType.get()) {
            case "Lingering" -> class_1802.field_8150;
            case "Drinkable" -> class_1802.field_8574;
            default -> class_1802.field_8436;
        };

        class_1799 stack = new class_1799(item, count.get());
        class_1844 contents = new class_1844(
                Optional.empty(),
                Optional.of(0x4B0082),
                List.of(new class_1293(class_1294.field_5921, 1, amplifier.get())),
                Optional.of("falaris_kill_potion")
        );
        stack.method_57379(class_9334.field_49651, contents);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470("Falaris Kill Potion"));
        return stack;
    }
}
