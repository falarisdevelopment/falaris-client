package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;

public final class AutoClicker extends CombatModule {
    private final IntegerSetting minCps = setting(new IntegerSetting("Min CPS", "Minimum clicks per second.", 8, 1, 20));
    private final IntegerSetting maxCps = setting(new IntegerSetting("Max CPS", "Maximum clicks per second.", 12, 1, 20));
    private final BooleanSetting onlyTarget = setting(new BooleanSetting("Only Target", "Only click when hovering an entity.", true));
    private final BooleanSetting breakBlocks = setting(new BooleanSetting("Break Blocks", "Also click on blocks for mining.", false));
    private final ModeSetting clickMode = setting(new ModeSetting("Click Mode", "Attack pattern.", "Left", "Left", "Right", "Both"));
    private final BooleanSetting weaponOnly = setting(new BooleanSetting("Weapon Only", "Only click when holding sword/axe.", true));
    private final ModeSetting pattern = setting(new ModeSetting("Pattern", "Click pattern behavior.", "Normal", "Normal", "Blatant", "Randomized", "Legit"));
    private final DoubleSetting dropChance = setting(new DoubleSetting("Drop Chance", "Chance to skip a click (Legit).", 0.15, 0.0, 0.5));
    private final IntegerSetting burstLength = setting(new IntegerSetting("Burst Length", "Max clicks before pause (Randomized).", 6, 2, 15));
    private final IntegerSetting burstPause = setting(new IntegerSetting("Burst Pause", "Ticks between bursts (Randomized).", 3, 1, 10));

    private final Random random = new Random();
    private long nextClickTime;
    private int clicksThisBurst;
    private int pauseTicks;

    public AutoClicker() {
        super("AutoClicker", "Automatically clicks for consistent attack speed.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        nextClickTime = System.currentTimeMillis();
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null) return;

        long now = System.currentTimeMillis();
        if (now < nextClickTime) return;

        if (!client.field_1729.method_1613()) return;

        String p = pattern.get();
        if (p.equals("Randomized") && pauseTicks > 0) {
            pauseTicks--;
            nextClickTime = now + 50;
            return;
        }

        if (weaponOnly.enabled()) {
            var item = client.field_1724.method_6047().method_7909();
            if (!isWeapon(item)) return;
        }

        boolean shouldClick = false;
        if (onlyTarget.enabled()) {
            if (client.field_1765 != null && client.field_1765.method_17783() == class_239.class_240.field_1331) {
                var entity = ((class_3966) client.field_1765).method_17782();
                if (entity != null && entity != client.field_1724 && entity.method_5805()) {
                    shouldClick = true;
                }
            }
            if (!shouldClick && breakBlocks.enabled() && client.field_1765 != null && client.field_1765.method_17783() == class_239.class_240.field_1332) {
                shouldClick = true;
            }
        } else {
            shouldClick = true;
        }

        if (!shouldClick) return;

        // Legit: random click drops
        if (p.equals("Legit") && random.nextDouble() < dropChance.get()) {
            int delay = 1000 / (minCps.get() + random.nextInt(maxCps.get() - minCps.get() + 1));
            nextClickTime = now + Math.max(50, delay);
            return;
        }

        // Randomized: burst-based clicking
        if (p.equals("Randomized")) {
            if (clicksThisBurst >= burstLength.get()) {
                pauseTicks = burstPause.get();
                clicksThisBurst = 0;
                int delay = 1000 / (minCps.get() + random.nextInt(maxCps.get() - minCps.get() + 1));
                nextClickTime = now + Math.max(50, delay);
                return;
            }
            clicksThisBurst++;
        }

        if (clickMode.is("Left") || clickMode.is("Both")) {
            client.field_1690.field_1886.method_23481(true);
            if (client.field_1765 != null && client.field_1765.method_17783() == class_239.class_240.field_1331) {
                var entity = ((class_3966) client.field_1765).method_17782();
                client.field_1761.method_2918(client.field_1724, entity);
            }
            client.field_1724.method_6104(net.minecraft.class_1268.field_5808);
        }
        if (clickMode.is("Right") || clickMode.is("Both")) {
            client.field_1690.field_1904.method_23481(true);
            client.field_1761.method_2919(client.field_1724, net.minecraft.class_1268.field_5808);
        }

        int delay = 1000 / (minCps.get() + random.nextInt(maxCps.get() - minCps.get() + 1));
        nextClickTime = System.currentTimeMillis() + Math.max(50, delay);
    }

    private boolean isWeapon(net.minecraft.class_1792 item) {
        return item == net.minecraft.class_1802.field_22022 || item == net.minecraft.class_1802.field_8802
            || item == net.minecraft.class_1802.field_8371 || item == net.minecraft.class_1802.field_8528
            || item == net.minecraft.class_1802.field_8091 || item == net.minecraft.class_1802.field_8845
            || item == net.minecraft.class_1802.field_22025 || item == net.minecraft.class_1802.field_8556
            || item == net.minecraft.class_1802.field_8475 || item == net.minecraft.class_1802.field_49814;
    }
}
