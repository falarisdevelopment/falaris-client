package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_310;
import java.util.ArrayList;
import java.util.List;

public final class HoleESP extends RenderModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Scan range.", 8.0, 4.0, 32.0));
    private final ModeSetting holeType = setting(new ModeSetting("Hole Type", "Type of holes to show.", "Both", "Both", "Double", "Single", "Both"));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Show through blocks.", true));

    private final List<Hole> holes = new ArrayList<>();
    private int scanTimer;

    public HoleESP() {
        super("HoleESP", "Highlights safe obsidian holes for crystal PVP.");
    }

    @Override
    protected void onRenderTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        scanTimer++;
        if (scanTimer < 20) return; // re-scan every 20 ticks
        scanTimer = 0;
        scan(client);
    }

    private void scan(class_310 client) {
        holes.clear();
        class_2338 center = client.field_1724.method_24515();
        int r = range.get().intValue();

        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                for (int y = -3; y <= 1; y++) {
                    class_2338 pos = center.method_10069(x, y, z);
                    if (client.field_1724.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > range.get() * range.get())
                        continue;
                    if (!client.field_1687.method_8320(pos).method_26215()) continue;
                    if (!isSafeBlock(client, pos.method_10074())) continue;

                    boolean n = isSafeBlock(client, pos.method_10095());
                    boolean s = isSafeBlock(client, pos.method_10072());
                    boolean e = isSafeBlock(client, pos.method_10078());
                    boolean w = isSafeBlock(client, pos.method_10067());

                    if (n && s && e && w) {
                        // Single hole
                        holes.add(new Hole(pos, false));
                    }
                }
            }
        }
    }

    private boolean isSafeBlock(class_310 client, class_2338 pos) {
        var state = client.field_1687.method_8320(pos);
        return state.method_27852(class_2246.field_10540) || state.method_27852(class_2246.field_22423) ||
               state.method_27852(class_2246.field_22108) || state.method_27852(class_2246.field_10535) ||
               state.method_27852(class_2246.field_9987) || state.method_27852(class_2246.field_10443);
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        for (Hole h : holes) {
            RenderUtil.Color c = h.doubleHole
                ? RenderUtil.Color.rgba(120, 200, 255, 180)
                : RenderUtil.Color.rgba(120, 255, 140, 180);
            RenderUtil.drawBox(context, new class_238(h.pos), c, throughWalls.enabled());
        }
    }

    private record Hole(class_2338 pos, boolean doubleHole) {}

    @Override protected void onEnable() { super.onEnable(); holes.clear(); scanTimer = 100; }
}
