package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public final class Tracers extends RenderModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum tracer range.", 128.0, 8.0, 256.0));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Trace to players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Trace to hostile mobs.", true));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Show tracers through blocks.", true));
    private final BooleanSetting onlyMoving = setting(new BooleanSetting("Only When Moving", "Only show tracers when player moves.", false));
    private final ModeSetting colorMode = setting(new ModeSetting("Color Mode", "Tracer color scheme.", "Distance", "Distance", "Health", "Friend", "Fade"));
    private final BooleanSetting toggleBlink = setting(new BooleanSetting("Blink", "Blinking tracer effect.", false));

    public Tracers() {
        super("Tracers", "Meteor-style player tracers with distance-based coloring.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        if (onlyMoving.enabled()) {
            double dx = client.field_1724.method_23317() - client.field_1724.field_6038;
            double dz = client.field_1724.method_23321() - client.field_1724.field_5989;
            if (dx * dx + dz * dz < 0.001) return;
        }

        class_4184 camera = client.field_1773.method_19418();
        class_243 camPos = camera.method_71156();
        class_243 eyes = client.field_1724.method_33571();

        class_4597 consumers = context.consumers();
        if (consumers == null) return;

        class_4588 lines = consumers.method_73477(net.minecraft.class_12249.method_76015());

        var entities = client.field_1687.method_18112();
        for (class_1297 entity : entities) {
            if (!(entity instanceof class_1309) || entity == client.field_1724) continue;
            if (!entity.method_5805()) continue;
            if (client.field_1724.method_5858(entity) > range.get() * range.get()) continue;
            if (entity instanceof class_1657 && !players.enabled()) continue;
            if (entity instanceof class_1588 && !hostiles.enabled()) continue;

            class_243 target = entity.method_5829().method_1005();
            double dist = client.field_1724.method_5739(entity);

            if (!throughWalls.enabled() && !client.field_1724.method_6057(entity)) continue;

            int color = getEntityColor(entity, dist, client);

            if (toggleBlink.enabled()) {
                float phase = (System.currentTimeMillis() % 1000) / 1000.0f;
                int alpha = (int) (class_3532.method_15374(phase * class_3532.field_29846) * 127 + 128);
                color = (color & 0x00FFFFFF) | (class_3532.method_15340(alpha, 0, 255) << 24);
            }

            float x1 = (float) (eyes.field_1352 - camPos.field_1352);
            float y1 = (float) (eyes.field_1351 - camPos.field_1351);
            float z1 = (float) (eyes.field_1350 - camPos.field_1350);
            float x2 = (float) (target.field_1352 - camPos.field_1352);
            float y2 = (float) (target.field_1351 - camPos.field_1351);
            float z2 = (float) (target.field_1350 - camPos.field_1350);

            class_4587.class_4665 entry = context.matrices().method_23760();

            lines.method_56824(entry, x1, y1, z1).method_39415(color);
            lines.method_56824(entry, x2, y2, z2).method_39415(color);
        }
    }

    private int getEntityColor(class_1297 entity, double distance, class_310 client) {
        return switch (colorMode.get()) {
            case "Health" -> {
                float health = 1.0f;
                if (entity instanceof class_1309 le) {
                    health = le.method_6032() / le.method_6063();
                }
                int r = (int) (255 * (1 - health));
                int g = (int) (255 * health);
                yield 0xFF000000 | (r << 16) | (g << 8);
            }
            case "Friend" -> {
                if (entity instanceof class_1657 pe && dev.falaris.client.FalarisClient.getInstance().getFriendsManager().isFriend(pe.method_5477().getString())) {
                    yield 0xFF00FF00;
                }
                yield 0xFFFF0000;
            }
            case "Fade" -> {
                float factor = (float) class_3532.method_15350(distance / range.get(), 0.0, 1.0);
                int r = (int) (255 * (1 - factor));
                int g = (int) (255 * factor);
                int b = (int) (128 * (1 - factor));
                yield 0xFF000000 | (r << 16) | (g << 8) | b;
            }
            default -> { // Distance
                float factor = (float) class_3532.method_15350(distance / 50.0, 0.0, 1.0);
                int r = (int) (255 * factor);
                int g = (int) (255 * (1 - factor));
                yield 0xFF000000 | (r << 16) | (g << 8);
            }
        };
    }
}
