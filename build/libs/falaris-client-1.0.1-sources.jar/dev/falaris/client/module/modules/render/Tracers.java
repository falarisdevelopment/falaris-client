package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import java.util.ArrayList;
import java.util.List;

public final class Tracers extends RenderModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Max tracer range.", 128.0, 8.0, 512.0));
    private final DoubleSetting lineWidth = setting(new DoubleSetting("Line Width", "Tracer thickness.", 1.5, 0.5, 4.0));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Tracers to players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Tracers to hostile mobs.", false));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Tracers to passive mobs.", false));
    private final BooleanSetting invisibles = setting(new BooleanSetting("Invisibles", "Show invisible.", false));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Tracers through blocks.", true));
    private final ModeSetting colorMode = setting(new ModeSetting("Color Mode", "Tracer coloring.", "Friend", "Distance", "Health", "Friend", "Team", "Rainbow"));
    private final ModeSetting style = setting(new ModeSetting("Style", "Tracer origin.", "Head", "Head", "Feet", "Middle", "Crosshair"));

    public Tracers() {
        super("Tracers", "Prestige-style player tracers with multiple origins and color modes.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_4184 camera = client.field_1773.method_19418();
        class_243 camPos = camera.method_71156();
        class_243 origin = getOrigin(client, camPos);
        double rangeSq = range.get() * range.get();

        List<TracerTarget> targets = new ArrayList<>();
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309) || entity == client.field_1724 || !entity.method_5805()) continue;
            if (!invisibles.enabled() && entity.method_5767()) continue;
            if (client.field_1724.method_5858(entity) > rangeSq) continue;
            if (entity instanceof class_1657 && !players.enabled()) continue;
            boolean isHostile = !(entity instanceof class_1657);
            if (isHostile && !hostiles.enabled()) continue;
            if (!(entity instanceof class_1657) && !isHostile && !passives.enabled()) continue;
            if (!throughWalls.enabled() && !client.field_1724.method_6057(entity)) continue;

            class_243 target = entity.method_5829().method_1005().method_1020(camPos);
            double dist = client.field_1724.method_5739(entity);
            int color = getColor(entity, dist, client);
            targets.add(new TracerTarget(target, color));
        }

        if (targets.isEmpty()) return;

        class_4597 consumers = context.consumers();
        if (consumers == null) return;
        class_4588 buffer = consumers.method_73477(class_12249.method_76015());
        class_4587.class_4665 entry = context.matrices().method_23760();
        float ox = (float) origin.field_1352, oy = (float) origin.field_1351, oz = (float) origin.field_1350;

        for (TracerTarget t : targets) {
            float r = ((t.color >> 16) & 0xFF) / 255f;
            float g = ((t.color >> 8) & 0xFF) / 255f;
            float b = (t.color & 0xFF) / 255f;
            float a = ((t.color >> 24) & 0xFF) / 255f;
            buffer.method_56824(entry, ox, oy, oz).method_22915(r, g, b, a).method_60831(entry, 0, 1, 0).method_75298(1.0f);
            buffer.method_56824(entry, (float) t.pos.field_1352, (float) t.pos.field_1351, (float) t.pos.field_1350).method_22915(r, g, b, a).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        }
    }

    private class_243 getOrigin(class_310 client, class_243 camPos) {
        return switch (style.get()) {
            case "Feet" -> new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321()).method_1020(camPos);
            case "Middle" -> new class_243(client.field_1724.method_23317(), client.field_1724.method_23318() + client.field_1724.method_17682() / 2, client.field_1724.method_23321()).method_1020(camPos);
            case "Crosshair" -> {
                var hit = client.field_1765;
                yield hit != null ? hit.method_17784().method_1020(camPos) : client.field_1724.method_33571().method_1020(camPos);
            }
            default -> client.field_1724.method_33571().method_1020(camPos);
        };
    }

    private int getColor(class_1297 entity, double distance, class_310 client) {
        return switch (colorMode.get()) {
            case "Health" -> {
                if (entity instanceof class_1309 le) {
                    float hp = le.method_6032() / le.method_6063();
                    int r = (int) (255 * (1 - hp));
                    int g = (int) (255 * hp);
                    yield 0xFF000000 | (r << 16) | (g << 8);
                }
                yield 0xFFFFFFFF;
            }
            case "Friend" -> {
                if (entity instanceof class_1657 pe && dev.falaris.client.FalarisClient.getInstance().getFriendsManager().isFriend(pe.method_5477().getString()))
                    yield 0xFF00FF00;
                yield 0xFFFF5555;
            }
            case "Team" -> {
                if (entity instanceof class_1657 pe) {
                    var team = pe.method_5781();
                    if (team != null && team.method_1202() != null) {
                        var fc = team.method_1202().method_532();
                        if (fc != null) yield 0xFF000000 | fc;
                    }
                }
                yield 0xFFFFFFFF;
            }
            case "Rainbow" -> {
                long time = System.currentTimeMillis() / 20;
                float hue = ((time + (long)(distance * 10)) % 360L) / 360f;
                int rgb = java.awt.Color.HSBtoRGB(hue, 0.8f, 0.95f);
                yield 0xFF000000 | (rgb & 0x00FFFFFF);
            }
            default -> {
                float factor = (float) class_3532.method_15350(distance / 50.0, 0.0, 1.0);
                int r = (int) (255 * factor);
                int g = (int) (255 * (1 - factor));
                yield 0xFF000000 | (r << 16) | (g << 8);
            }
        };
    }

    private record TracerTarget(class_243 pos, int color) {}
}
