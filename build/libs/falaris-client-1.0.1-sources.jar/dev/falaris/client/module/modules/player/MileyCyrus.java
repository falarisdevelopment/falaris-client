package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_310;

public final class MileyCyrus extends PlayerModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Twerk style.", "Sneak", "Sneak", "Spin", "Both"));
    private final IntegerSetting speed = setting(new IntegerSetting("Speed", "Ticks between toggles.", 2, 1, 10));

    private int tickCounter;
    private boolean toggle;

    public MileyCyrus() {
        super("MileyCyrus", "Rapidly toggles sneak for a twerking effect.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        tickCounter++;
        if (tickCounter < speed.get()) return;
        tickCounter = 0;

        toggle = !toggle;

        if (mode.is("Sneak") || mode.is("Both")) {
            client.field_1724.method_5660(toggle);
        }

        if (mode.is("Spin") || mode.is("Both")) {
            client.field_1724.method_36456(client.field_1724.method_36454() + 15.0f);
            client.field_1724.method_5847(client.field_1724.method_36454());
        }
    }
}
