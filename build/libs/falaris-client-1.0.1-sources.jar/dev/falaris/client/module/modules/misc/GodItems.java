package dev.falaris.client.module.modules.misc;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_2873;
import net.minecraft.class_310;
import net.minecraft.class_9334;

public final class GodItems extends MiscModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Item to generate.", "Kill Potion",
            "Kill Potion", "Hyperion Sword", "God Apple", "Stacked Totem", "God Armor", "Give All"));
    private final IntegerSetting amplifier = setting(new IntegerSetting("Amplifier", "Potion amplifier / enchant level.", 255, 1, 255));
    private final IntegerSetting count = setting(new IntegerSetting("Count", "Generated stack count.", 1, 1, 64));
    private final BooleanSetting requireCreative = setting(new BooleanSetting("Require Creative", "Only generate while in creative.", true));

    private boolean generated;

    public GodItems() {
        super("GodItems", "Generates creative-only items including kill potions and stacked totems.");
    }

    @Override
    protected void onEnable() {
        generated = false;
        super.onEnable();
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (generated || client.field_1724 == null || client.field_1724.field_3944 == null) return;
        if (requireCreative.enabled() && !client.field_1724.method_31549().field_7477) {
            client.field_1724.method_7353(class_2561.method_43470("[Falaris] GodItems requires creative mode."), false);
            generated = true;
            setEnabled(false);
            return;
        }

        if (mode.is("Give All")) {
            giveAll(client);
        } else {
            class_1799 stack = createItem(mode.get());
            giveStack(client, stack, mode.get());
        }
        generated = true;
        setEnabled(false);
    }

    private void giveAll(class_310 client) {
        String[] allModes = {"Kill Potion", "Hyperion Sword", "God Apple", "Stacked Totem", "God Armor"};
        int slot = client.field_1724.method_31548().method_67532();
        for (String m : allModes) {
            class_1799 stack = createItem(m);
            int s = 36 + slot;
            client.field_1724.method_31548().method_5447(slot, stack);
            client.field_1724.field_3944.method_52787(new class_2873(s, stack));
            slot = (slot + 1) % 9;
        }
        client.field_1724.method_7353(class_2561.method_43470("[Falaris] Generated all items in your hotbar."), false);
    }

    private void giveStack(class_310 client, class_1799 stack, String name) {
        int selectedSlot = client.field_1724.method_31548().method_67532();
        int slot = 36 + selectedSlot;
        client.field_1724.method_31548().method_5447(selectedSlot, stack);
        client.field_1724.field_3944.method_52787(new class_2873(slot, stack));
        client.field_1724.method_7353(class_2561.method_43470("[Falaris] Generated " + name + " in your selected hotbar slot."), false);
    }

    private class_1799 createItem(String modeName) {
        return switch (modeName) {
            case "Kill Potion" -> createKillPotion();
            case "Hyperion Sword" -> createHyperionSword();
            case "God Apple" -> createGodApple();
            case "Stacked Totem" -> createStackedTotem();
            case "God Armor" -> createGodArmor();
            default -> class_1799.field_8037;
        };
    }

    private class_1799 createKillPotion() {
        class_1799 stack = new class_1799(class_1802.field_8436, count.get());
        class_1844 contents = new class_1844(
                Optional.empty(),
                Optional.of(0x4B0082),
                List.of(new class_1293(class_1294.field_5921, 1, amplifier.get())),
                Optional.of("falaris_kill_potion")
        );
        stack.method_57379(class_9334.field_49651, contents);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470("Falaris Kill Potion"));
        return stack;
    }

    private class_1799 createHyperionSword() {
        class_1799 stack = new class_1799(class_1802.field_8371, 1);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470("\u00A7b\u00A7lHyperion X"));
        stack.method_57379(class_9334.field_49641, true);
        return stack;
    }

    private class_1799 createGodApple() {
        class_1799 stack = new class_1799(class_1802.field_8367, count.get());
        stack.method_57379(class_9334.field_49631, class_2561.method_43470("\u00A76\u00A7lGod Apple"));
        return stack;
    }

    private class_1799 createStackedTotem() {
        class_1799 stack = new class_1799(class_1802.field_8288, Math.min(count.get(), 64));
        stack.method_57379(class_9334.field_49631, class_2561.method_43470("\u00A7d\u00A7lStacked Totem"));
        return stack;
    }

    private class_1799 createGodArmor() {
        class_1799 stack = new class_1799(class_1802.field_22028, 1);
        stack.method_57379(class_9334.field_49631, class_2561.method_43470("\u00A76\u00A7lGod Armor"));
        stack.method_57379(class_9334.field_49641, true);
        return stack;
    }
}
