package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_310;

public final class Flight extends MovementModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Flight implementation.", "Normal", "Normal", "Packet", "Creative", "Legit"));
    private final DoubleSetting speed = setting(new DoubleSetting("Speed", "Horizontal flight speed.", 0.75, 0.05, 5.0));
    private final DoubleSetting verticalSpeed = setting(new DoubleSetting("Vertical Speed", "Vertical flight speed.", 0.55, 0.05, 3.0));
    private final IntegerSetting packetInterval = setting(new IntegerSetting("Packet Interval", "Ticks between packet nudges.", 2, 1, 20));
    private final IntegerSetting packetJitter = setting(new IntegerSetting("Packet Jitter", "Random extra ticks for packet mode.", 1, 0, 8));
    private final BooleanSetting antiKick = setting(new BooleanSetting("Anti Kick", "Adds a small downward pulse while hovering.", true));
    private final DoubleSetting acceleration = setting(new DoubleSetting("Acceleration", "Speed ramp per tick (0 = instant).", 0.15, 0.0, 1.0));
    private final BooleanSetting glide = setting(new BooleanSetting("Glide", "Gentle downward drift when idle.", true));

    private boolean previousAllowFlying;
    private boolean previousFlying;
    private double currentSpeedX, currentSpeedZ;

    public Flight() {
        super("Flight", "Free movement through the air with normal, packet, creative, and legit modes.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            previousAllowFlying = client.field_1724.method_31549().field_7478;
            previousFlying = client.field_1724.method_31549().field_7479;
        }
        currentSpeedX = 0;
        currentSpeedZ = 0;
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && mode.is("Creative")) {
            client.field_1724.method_31549().field_7478 = previousAllowFlying;
            client.field_1724.method_31549().field_7479 = previousFlying;
            client.field_1724.method_7355();
        }
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (mode.is("Creative")) {
            client.field_1724.method_31549().field_7478 = true;
            client.field_1724.method_31549().field_7479 = true;
            client.field_1724.method_31549().method_7248((float) (speed.get() / 10.0));
            client.field_1724.method_7355();
            return;
        }

        class_243 input = MovementUtil.inputVelocity(client.field_1724, speed.get(), false, client);
        double targetX = input.field_1352;
        double targetZ = input.field_1350;

        if (acceleration.get() > 0.01) {
            currentSpeedX += (targetX - currentSpeedX) * acceleration.get();
            currentSpeedZ += (targetZ - currentSpeedZ) * acceleration.get();
            if (Math.abs(currentSpeedX) < 0.001 && Math.abs(targetX) < 0.001) currentSpeedX = 0;
            if (Math.abs(currentSpeedZ) < 0.001 && Math.abs(targetZ) < 0.001) currentSpeedZ = 0;
        } else {
            currentSpeedX = targetX;
            currentSpeedZ = targetZ;
        }

        double y = 0;
        if (client.field_1690.field_1903.method_1434()) {
            y = verticalSpeed.get();
        } else if (client.field_1690.field_1832.method_1434()) {
            y = -verticalSpeed.get();
        } else if (glide.enabled() && input.method_37268() < 0.01 && client.field_1724.method_18798().field_1351 > -0.1) {
            y = -0.01;
        }

        if (antiKick.enabled() && y == 0 && client.field_1724.field_6012 % 20 == 0) {
            y = -0.04;
        }

        if (mode.is("Legit")) {
            client.field_1724.method_31549().field_7478 = true;
            client.field_1724.method_31549().field_7479 = true;
            client.field_1724.method_31549().method_7248((float) Math.min(speed.get() / 15.0, 0.1));
            client.field_1724.method_7355();
        } else {
            client.field_1724.method_18800(currentSpeedX, y, currentSpeedZ);
            client.field_1724.field_6017 = 0;

            if (mode.is("Packet") && client.field_1724.field_3944 != null && ready(packetInterval.get(), packetJitter.get())) {
                class_243 pos = new class_243(client.field_1724.method_23317() + currentSpeedX, client.field_1724.method_23318() + y, client.field_1724.method_23321() + currentSpeedZ);
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(pos.field_1352, pos.field_1351, pos.field_1350, true, client.field_1724.field_5976));
            }
        }
    }
}
