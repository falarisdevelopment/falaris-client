package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class AutoGap extends PlayerModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "When to eat.", "Health", "Always", "Health", "Hunger", "Both"));
    private final DoubleSetting health = setting(new DoubleSetting("Health", "Health threshold to eat at.", 12.0, 1.0, 20.0));
    private final IntegerSetting hunger = setting(new IntegerSetting("Hunger", "Hunger threshold to eat at.", 10, 1, 20));
    private final BooleanSetting preferEnchanted = setting(new BooleanSetting("Prefer Enchanted", "Use enchanted golden apples first.", true));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between eating sessions.", 15, 1, 60));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks.", 5, 0, 20));
    private final BooleanSetting pauseOnAttack = setting(new BooleanSetting("Pause on Attack", "Don't start eating while attacking.", true));
    private final BooleanSetting pauseOnMove = setting(new BooleanSetting("Pause on Move", "Don't start eating while moving.", false));
    private final BooleanSetting stopOnFull = setting(new BooleanSetting("Stop on Full", "Stop eating when health is full.", true));
    private final BooleanSetting switchBack = setting(new BooleanSetting("Switch Back", "Return to previous slot after eating.", true));

    private int prevSlot = -1;
    private boolean wasEating;

    public AutoGap() {
        super("AutoGap", "Automatically eats golden apples when health or hunger is low.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        // Handle ongoing eating
        if (client.field_1724.method_6115()) {
            wasEating = true;
            if (stopOnFull.enabled() && client.field_1724.method_6032() >= client.field_1724.method_6063()) {
                stopEating(client);
            } else if (pauseOnAttack.enabled() && client.field_1690.field_1886.method_1434()) {
                stopEating(client);
            }
            return;
        }

        // If we just finished eating, switch back
        if (wasEating) {
            wasEating = false;
            switchBackToPrev(client);
            return;
        }

        // Check if we should eat
        if (!shouldEat(client)) return;

        // Check pause conditions
        if (pauseOnAttack.enabled() && client.field_1690.field_1886.method_1434()) return;
        if (pauseOnMove.enabled() && (client.field_1690.field_1894.method_1434() || client.field_1690.field_1881.method_1434()
            || client.field_1690.field_1913.method_1434() || client.field_1690.field_1849.method_1434())) return;

        if (!ready(delay.get(), jitter.get())) return;

        // Find golden apple
        int slot = -1;
        if (preferEnchanted.enabled()) {
            slot = InventoryUtil.findItem(client.field_1724, class_1802.field_8367, true);
        }
        if (slot == -1) {
            slot = InventoryUtil.findItem(client.field_1724, class_1802.field_8463, true);
        }
        if (slot == -1) {
            slot = InventoryUtil.findItem(client.field_1724, class_1802.field_8367, false);
        }
        if (slot == -1) {
            slot = InventoryUtil.findItem(client.field_1724, class_1802.field_8463, false);
        }
        if (slot == -1) return;

        prevSlot = client.field_1724.method_31548().method_67532();
        if (slot >= 0 && slot < 9) {
            client.field_1724.method_31548().method_61496(slot);
        }
        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
    }

    private boolean shouldEat(class_310 client) {
        return switch (mode.get()) {
            case "Always" -> true;
            case "Health" -> client.field_1724.method_6032() <= health.get();
            case "Hunger" -> client.field_1724.method_7344().method_7586() <= hunger.get();
            case "Both" -> client.field_1724.method_6032() <= health.get()
                || client.field_1724.method_7344().method_7586() <= hunger.get();
            default -> false;
        };
    }

    private void stopEating(class_310 client) {
        client.field_1724.method_6075();
        client.field_1761.method_2897(client.field_1724);
        wasEating = false;
        switchBackToPrev(client);
    }

    private void switchBackToPrev(class_310 client) {
        if (switchBack.enabled() && prevSlot >= 0 && prevSlot < 9) {
            client.field_1724.method_31548().method_61496(prevSlot);
        }
        prevSlot = -1;
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            if (client.field_1724.method_6115()) {
                client.field_1724.method_6075();
                client.field_1761.method_2897(client.field_1724);
            }
            if (prevSlot >= 0 && prevSlot < 9) {
                client.field_1724.method_31548().method_61496(prevSlot);
            }
        }
        prevSlot = -1;
        wasEating = false;
    }
}
