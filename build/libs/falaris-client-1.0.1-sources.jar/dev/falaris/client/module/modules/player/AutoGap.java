package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class AutoGap extends PlayerModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "When to eat.", "Low Health", "Always", "Low Health"));
    private final DoubleSetting health = setting(new DoubleSetting("Health", "Health threshold to eat at.", 10.0, 1.0, 20.0));
    private final BooleanSetting preferEnchanted = setting(new BooleanSetting("Prefer Enchanted", "Use enchanted golden apples first.", true));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between actions.", 10, 1, 40));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks.", 5, 0, 20));

    private int prevSlot = -1;
    private boolean startingUse;

    public AutoGap() {
        super("AutoGap", "Auto-eats golden apples when health is low.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (mode.is("Low Health") && client.field_1724.method_6032() > health.get()) return;

        if (client.field_1724.method_6115()) return;
        if (!ready(delay.get(), jitter.get())) return;

        // Reset item use cooldown via reflection
        try {
            java.lang.reflect.Field cooldownField = class_310.class.getDeclaredField("itemUseCooldown");
            cooldownField.setAccessible(true);
            cooldownField.setInt(client, 0);
        } catch (Exception ignored) {
        }

        int slot = -1;
        if (preferEnchanted.enabled()) {
            slot = InventoryUtil.findItem(client.field_1724, class_1802.field_8367, true);
        }
        if (slot == -1) {
            slot = InventoryUtil.findItem(client.field_1724, class_1802.field_8463, true);
        }
        if (slot == -1) return;

        prevSlot = client.field_1724.method_31548().method_67532();
        client.field_1724.method_31548().method_61496(slot);
        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
        startingUse = true;
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            if (client.field_1724.method_6115()) {
                client.field_1724.method_6075();
                client.field_1761.method_2897(client.field_1724);
            }
            if (prevSlot != -1) {
                client.field_1724.method_31548().method_61496(prevSlot);
            }
        }
        prevSlot = -1;
        startingUse = false;
    }
}
