package dev.falaris.client.module.modules.player;

import net.minecraft.class_1713;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class InventoryUtil {
    public static final int OFFHAND_SLOT = 45;
    public static final int HELMET_SLOT = 5;
    public static final int CHESTPLATE_SLOT = 6;
    public static final int LEGGINGS_SLOT = 7;
    public static final int BOOTS_SLOT = 8;

    InventoryUtil() {
    }

    public static int screenSlotForInventoryIndex(int inventoryIndex) {
        if (inventoryIndex >= 0 && inventoryIndex <= 8) {
            return 36 + inventoryIndex;
        }
        if (inventoryIndex >= 9 && inventoryIndex <= 35) {
            return inventoryIndex;
        }
        return -1;
    }

    public static int findItem(class_746 player, class_1792 item, boolean hotbarOnly) {
        int end = hotbarOnly ? 9 : 36;
        for (int index = 0; index < end; index++) {
            if (player.method_31548().method_5438(index).method_31574(item)) {
                return index;
            }
        }
        return -1;
    }

    static int findBestSword(class_746 player, boolean allowAxes, boolean hotbarOnly) {
        int end = hotbarOnly ? 9 : 36;
        int best = -1;
        double bestScore = -1.0;
        for (int index = 0; index < end; index++) {
            class_1799 stack = player.method_31548().method_5438(index);
            double score = weaponScore(stack, allowAxes);
            if (score > bestScore) {
                best = index;
                bestScore = score;
            }
        }
        return best;
    }

    static double weaponScore(class_1799 stack, boolean allowAxes) {
        if (stack.method_7960()) {
            return -1.0;
        }
        if (isSword(stack.method_7909())) {
            return 100.0 + stack.method_7936() - stack.method_7919();
        }
        if (allowAxes && stack.method_7909() instanceof class_1743) {
            return 80.0 + stack.method_7936() - stack.method_7919();
        }
        return -1.0;
    }

    static int findBestTool(class_746 player, net.minecraft.class_2680 state, boolean hotbarOnly) {
        int end = hotbarOnly ? 9 : 36;
        int best = -1;
        float bestSpeed = 1.0f;
        for (int index = 0; index < end; index++) {
            class_1799 stack = player.method_31548().method_5438(index);
            if (stack.method_7924(state) <= 1.0f) {
                continue;
            }
            float speed = stack.method_7924(state);
            if (speed > bestSpeed) {
                best = index;
                bestSpeed = speed;
            }
        }
        return best;
    }

    static int armorTargetSlot(class_1799 stack) {
        class_1792 item = stack.method_7909();
        if (item == class_1802.field_8267 || item == class_1802.field_8283 || item == class_1802.field_61343 || item == class_1802.field_8743 || item == class_1802.field_8862 || item == class_1802.field_8805 || item == class_1802.field_22027 || item == class_1802.field_8090) {
            return HELMET_SLOT;
        }
        if (item == class_1802.field_8577 || item == class_1802.field_8873 || item == class_1802.field_61344 || item == class_1802.field_8523 || item == class_1802.field_8678 || item == class_1802.field_8058 || item == class_1802.field_22028) {
            return CHESTPLATE_SLOT;
        }
        if (item == class_1802.field_8570 || item == class_1802.field_8218 || item == class_1802.field_61345 || item == class_1802.field_8396 || item == class_1802.field_8416 || item == class_1802.field_8348 || item == class_1802.field_22029) {
            return LEGGINGS_SLOT;
        }
        if (item == class_1802.field_8370 || item == class_1802.field_8313 || item == class_1802.field_61346 || item == class_1802.field_8660 || item == class_1802.field_8753 || item == class_1802.field_8285 || item == class_1802.field_22030) {
            return BOOTS_SLOT;
        }
        return -1;
    }

    static double armorScore(class_1799 stack) {
        return armorProtection(stack.method_7909()) * 1000.0 + stack.method_7936() - stack.method_7919();
    }

    public static boolean clickMove(class_310 client, int fromScreenSlot, int toScreenSlot) {
        if (client.field_1724 == null || client.field_1761 == null || fromScreenSlot < 0 || toScreenSlot < 0) {
            return false;
        }
        int syncId = client.field_1724.field_7512.field_7763;
        client.field_1761.method_2906(syncId, fromScreenSlot, 0, class_1713.field_7790, client.field_1724);
        client.field_1761.method_2906(syncId, toScreenSlot, 0, class_1713.field_7790, client.field_1724);
        client.field_1761.method_2906(syncId, fromScreenSlot, 0, class_1713.field_7790, client.field_1724);
        return true;
    }

    static boolean quickMove(class_310 client, int screenSlot) {
        if (client.field_1724 == null || client.field_1761 == null || screenSlot < 0) {
            return false;
        }
        client.field_1761.method_2906(client.field_1724.field_7512.field_7763, screenSlot, 0, class_1713.field_7794, client.field_1724);
        return true;
    }

    static boolean selectHotbar(class_746 player, int inventoryIndex) {
        if (inventoryIndex < 0 || inventoryIndex > 8) {
            return false;
        }
        player.method_31548().method_61496(inventoryIndex);
        return true;
    }

    public static boolean isTotem(class_1799 stack) {
        return stack.method_31574(class_1802.field_8288);
    }

    private static boolean isSword(class_1792 item) {
        return item == class_1802.field_8091 || item == class_1802.field_8528 || item == class_1802.field_61338 || item == class_1802.field_8371 || item == class_1802.field_8845 || item == class_1802.field_8802 || item == class_1802.field_22022;
    }

    private static int armorProtection(class_1792 item) {
        if (item == class_1802.field_8267 || item == class_1802.field_8370 || item == class_1802.field_8862 || item == class_1802.field_8753 || item == class_1802.field_8283 || item == class_1802.field_8313 || item == class_1802.field_61343 || item == class_1802.field_61346 || item == class_1802.field_8090) return 1;
        if (item == class_1802.field_8570 || item == class_1802.field_8416) return 2;
        if (item == class_1802.field_8577 || item == class_1802.field_8218 || item == class_1802.field_61345) return 3;
        if (item == class_1802.field_8743 || item == class_1802.field_8660 || item == class_1802.field_8873 || item == class_1802.field_61344) return 4;
        if (item == class_1802.field_8396 || item == class_1802.field_8805 || item == class_1802.field_8285 || item == class_1802.field_22027 || item == class_1802.field_22030) return 5;
        if (item == class_1802.field_8523 || item == class_1802.field_8348 || item == class_1802.field_22029) return 6;
        if (item == class_1802.field_8058 || item == class_1802.field_22028) return 8;
        return -1;
    }
}
