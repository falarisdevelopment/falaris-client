package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_310;
import net.minecraft.class_418;

public final class AutoRespawn extends PlayerModule {
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks to wait before respawning.", 10, 0, 60));
    private final BooleanSetting autoRelease = setting(new BooleanSetting("Auto Release", "Click respawn button automatically.", true));

    private int tickCounter;

    public AutoRespawn() {
        super("AutoRespawn", "Automatically respawns after death.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        tickCounter = 0;
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (client.field_1755 instanceof class_418) {
            tickCounter++;
            if (tickCounter >= delay.get() && autoRelease.enabled()) {
                client.field_1724.method_7331();
                client.method_1507(null);
                tickCounter = 0;
            }
        } else {
            tickCounter = 0;
        }
    }
}
