package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class AutoTool extends PlayerModule {
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between tool switches.", 1, 1, 20));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks between tool switches.", 0, 0, 10));
    private final BooleanSetting hotbarOnly = setting(new BooleanSetting("Hotbar Only", "Only select tools already in the hotbar.", true));
    private final BooleanSetting requireAttack = setting(new BooleanSetting("Require Attack", "Only switch while mining.", true));

    public AutoTool() {
        super("AutoTool", "Selects the fastest tool for the block under the crosshair.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1765 == null) {
            return;
        }
        if (requireAttack.enabled() && !client.field_1690.field_1886.method_1434()) {
            return;
        }
        if (client.field_1765.method_17783() != class_239.class_240.field_1332 || !ready(delay.get(), jitter.get())) {
            return;
        }

        class_3965 hit = (class_3965) client.field_1765;
        class_2680 state = client.field_1687.method_8320(hit.method_17777());
        int best = InventoryUtil.findBestTool(client.field_1724, state, hotbarOnly.enabled());
        if (best >= 0 && best <= 8) {
            InventoryUtil.selectHotbar(client.field_1724, best);
        } else if (!hotbarOnly.enabled() && best != -1) {
            InventoryUtil.quickMove(client, InventoryUtil.screenSlotForInventoryIndex(best));
        }
    }
}
