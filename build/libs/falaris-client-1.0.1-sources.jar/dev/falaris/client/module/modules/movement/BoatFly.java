package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.minecraft.class_1297;
import net.minecraft.class_1690;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class BoatFly extends MovementModule {
    private final DoubleSetting speed = setting(new DoubleSetting("Speed", "Horizontal boat speed.", 0.9, 0.05, 5.0));
    private final DoubleSetting verticalSpeed = setting(new DoubleSetting("Vertical Speed", "Boat climb/drop speed.", 0.45, 0.05, 3.0));
    private final BooleanSetting onlyBoats = setting(new BooleanSetting("Only Boats", "Only affect boat entities.", true));
    private final BooleanSetting noGravity = setting(new BooleanSetting("No Gravity", "Disables vehicle gravity client-side.", true));

    public BoatFly() {
        super("BoatFly", "Lets mounted boats move freely through the air.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) {
            return;
        }

        class_1297 vehicle = client.field_1724.method_5854();
        if (vehicle == null || (onlyBoats.enabled() && !(vehicle instanceof class_1690))) {
            return;
        }

        class_243 input = MovementUtil.inputVelocity(client.field_1724, speed.get(), false, client);
        double y = 0.0;
        if (client.field_1690.field_1903.method_1434()) {
            y += verticalSpeed.get();
        }
        if (client.field_1690.field_1832.method_1434()) {
            y -= verticalSpeed.get();
        }

        vehicle.method_18800(input.field_1352, y, input.field_1350);
        vehicle.method_5875(noGravity.enabled());
        vehicle.field_6017 = 0.0f;
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && client.field_1724.method_5854() != null) {
            client.field_1724.method_5854().method_5875(false);
        }
    }
}
