package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public final class ESP extends RenderModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum entity render range.", 96.0, 8.0, 256.0));
    private final DoubleSetting expand = setting(new DoubleSetting("Expand", "Box expansion amount.", 0.15, 0.0, 1.0));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Render player ESP.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Render hostile mobs.", true));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Render passive mobs.", false));
    private final BooleanSetting invisibles = setting(new BooleanSetting("Invisibles", "Render invisible entities.", true));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Show ESP through walls.", true));
    private final ModeSetting style = setting(new ModeSetting("Style", "ESP rendering style.", "Box", "Box", "Outline", "Both"));

    public ESP() {
        super("ESP", "Draws outline boxes around configured entities.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (!(entity instanceof class_1309) || entity == client.field_1724 || !entity.method_5805()) {
                continue;
            }
            if (!invisibles.enabled() && entity.method_5767()) {
                continue;
            }
            if (client.field_1724.method_5858(entity) > range.get() * range.get() || !allowed(entity)) {
                continue;
            }

            RenderUtil.Color espColor = color(entity);
            boolean wallOpaque = throughWalls.enabled();

            RenderUtil.Color drawColor = wallOpaque
                    ? RenderUtil.Color.rgba((int)(espColor.red() * 255), (int)(espColor.green() * 255), (int)(espColor.blue() * 255), 180)
                    : espColor;

            RenderUtil.drawEntityBox(context, entity, drawColor, expand.get(), throughWalls.enabled());
        }
    }

    private boolean allowed(class_1297 entity) {
        if (entity instanceof class_1657) {
            return players.enabled();
        }
        if (entity instanceof class_1588) {
            return hostiles.enabled();
        }
        if (entity instanceof class_1296) {
            return passives.enabled();
        }
        return false;
    }

    private RenderUtil.Color color(class_1297 entity) {
        if (entity instanceof class_1657) {
            return RenderUtil.Color.rgba(122, 156, 255, 210);
        }
        if (entity instanceof class_1588) {
            return RenderUtil.Color.rgba(255, 92, 122, 210);
        }
        return RenderUtil.Color.rgba(120, 235, 170, 210);
    }
}
