package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

public final class ESP extends RenderModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Max render range.", 96.0, 8.0, 256.0));
    private final DoubleSetting expand = setting(new DoubleSetting("Expand", "Box expansion.", 0.1, 0.0, 0.5));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Show players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Show hostile mobs.", true));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Show passive mobs.", false));
    private final BooleanSetting invisibles = setting(new BooleanSetting("Invisibles", "Show invisible.", true));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Show behind walls.", true));
    private final BooleanSetting healthColor = setting(new BooleanSetting("Health Color", "Color by health.", false));
    private final BooleanSetting showItems = setting(new BooleanSetting("Show Items", "ESP for ground items.", false));
    private final ModeSetting style = setting(new ModeSetting("Style", "ESP style.", "Box", "Box", "Outline", "2D", "Both"));

    public ESP() {
        super("ESP", "Prestige-style entity boxes with health colors and 2D tags.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;
        class_4184 camera = client.field_1773.method_19418();
        class_243 cam = camera.method_71156();

        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity == client.field_1724 || !entity.method_5805()) continue;
            if (!invisibles.enabled() && entity.method_5767()) continue;
            if (client.field_1724.method_5858(entity) > range.get() * range.get()) continue;

            if (entity instanceof class_1309 le) {
                if (!allowed(le)) continue;
                RenderUtil.Color c = healthColor.enabled() ? healthColor(le) : color(le);
                class_238 bb = le.method_5829().method_1014(expand.get());
                boolean wall = throughWalls.enabled();
                String s = style.get();

                if (s.equals("Box") || s.equals("Both"))
                    RenderUtil.drawBox(context, bb, c, wall);
                if (s.equals("Outline") || s.equals("Both"))
                    RenderUtil.drawBox(context, bb, RenderUtil.Color.rgba((int)(c.red()*255), (int)(c.green()*255), (int)(c.blue()*255), 60), wall);
                if (s.equals("2D") || s.equals("Both"))
                    draw2DTag(context, le, c, cam);
            } else if (showItems.enabled() && entity instanceof net.minecraft.class_1542 ie) {
                if (!ie.method_6983().method_7960())
                    RenderUtil.drawBox(context, ie.method_5829().method_1014(0.2), RenderUtil.Color.rgba(255, 220, 80, 180), throughWalls.enabled());
            }
        }
    }

    private void draw2DTag(WorldRenderContext context, class_1309 entity, RenderUtil.Color c, class_243 cam) {
        class_310 client = class_310.method_1551();
        class_327 tr = client.field_1772;
        class_4587 ms = context.matrices();
        double x = entity.method_23317() - cam.field_1352;
        double y = entity.method_23318() - cam.field_1351 + entity.method_17682() + 0.5;
        double z = entity.method_23321() - cam.field_1350;

        ms.method_22903();
        ms.method_22904(x, y, z);
        ms.method_22907(class_7833.field_40716.rotationDegrees(-client.field_1773.method_19418().method_19330()));
        ms.method_22907(class_7833.field_40714.rotationDegrees(client.field_1773.method_19418().method_19329()));
        ms.method_22905(-0.025f, -0.025f, 0.025f);

        String hp = entity instanceof class_1657 pe ? String.format("%.0f", pe.method_6032()) : "";
        String text = hp.isEmpty() ? String.valueOf((int) entity.method_6032()) : hp + "❤";
        float tw = tr.method_1727(text);
        var cons = context.consumers();
        if (cons == null) { ms.method_22909(); return; }
        Matrix4f mat = ms.method_23760().method_23761();
        tr.method_27521(text, -tw / 2, 0, c.asArgb(), false, mat, cons, net.minecraft.class_327.class_6415.field_33994, 0x44000000, 0xF000F0);
        ms.method_22909();
    }

    private RenderUtil.Color healthColor(class_1309 e) {
        float hp = e.method_6032() / e.method_6063();
        int r = (int) (255 * (1 - hp));
        int g = (int) (255 * hp);
        return RenderUtil.Color.rgba(r, g, 60, 200);
    }

    private boolean allowed(class_1297 e) {
        if (e instanceof class_1657) return players.enabled();
        if (e instanceof class_1588) return hostiles.enabled();
        if (e instanceof class_1296) return passives.enabled();
        return false;
    }

    private RenderUtil.Color color(class_1297 entity) {
        if (entity instanceof class_1657) return RenderUtil.Color.rgba(122, 156, 255, 200);
        if (entity instanceof class_1588) return RenderUtil.Color.rgba(255, 92, 122, 200);
        return RenderUtil.Color.rgba(120, 235, 170, 200);
    }
}
