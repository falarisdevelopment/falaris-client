package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_310;

public final class AntiAFK extends MiscModule {
    private final ModeSetting action = setting(new ModeSetting("Action", "AFK prevention action.", "Jump", "Jump", "Move", "Look", "Swing"));
    private final IntegerSetting interval = setting(new IntegerSetting("Interval", "Ticks between actions.", 60, 10, 400));

    private int tickCounter;

    public AntiAFK() {
        super("AntiAFK", "Prevents being kicked for inactivity on anarchy servers.");
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null) return;
        tickCounter++;
        if (tickCounter < interval.get()) return;
        tickCounter = 0;

        switch (action.get()) {
            case "Jump" -> {
                if (client.field_1724.method_24828()) client.field_1724.method_6043();
            }
            case "Move" -> {
                client.field_1724.method_18800(
                    client.field_1724.method_18798().field_1352 + (Math.random() - 0.5) * 0.05,
                    client.field_1724.method_18798().field_1351,
                    client.field_1724.method_18798().field_1350 + (Math.random() - 0.5) * 0.05
                );
            }
            case "Look" -> {
                client.field_1724.method_36456(client.field_1724.method_36454() + (float) (Math.random() * 30 - 15));
                client.field_1724.method_36457(Math.max(-90, Math.min(90, client.field_1724.method_36455() + (float) (Math.random() * 10 - 5))));
            }
            case "Swing" -> client.field_1724.method_6104(net.minecraft.class_1268.field_5808);
        }
    }

    @Override protected void onEnable() { super.onEnable(); tickCounter = 0; }
}
