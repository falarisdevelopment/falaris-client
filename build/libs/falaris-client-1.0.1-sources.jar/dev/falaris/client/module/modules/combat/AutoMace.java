package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class AutoMace extends CombatModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Attack range.", 3.5, 1.0, 6.0));
    private final DoubleSetting minFallDist = setting(new DoubleSetting("Min Fall Dist", "Minimum fall distance for bonus.", 2.5, 0.0, 10.0));
    private final DoubleSetting cps = setting(new DoubleSetting("CPS", "Attacks per second.", 7.0, 1.0, 20.0));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks.", 2, 0, 8));
    private final ModeSetting priority = setting(new ModeSetting("Priority", "Target sort.", "Distance", "Distance", "Health", "Angle"));
    private final BooleanSetting autoSwitch = setting(new BooleanSetting("Auto Switch", "Swap to mace.", true));
    private final BooleanSetting silentRotate = setting(new BooleanSetting("Silent Rotate", "Face target.", true));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Rotation speed.", 25.0, 1.0, 60.0));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Target players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Target hostile mobs.", true));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Target passive mobs.", false));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Ignore line of sight.", false));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anti-cheat.", "Vanilla", "Vanilla", "Vanilla", "Ghost", "Grim", "Legit"));

    // Ghost settings
    private final IntegerSetting faceDelay = setting(new IntegerSetting("Face Delay", "Ticks to face before hitting.", 2, 0, 10));
    private final DoubleSetting missChance = setting(new DoubleSetting("Miss Chance", "% chance to miss.", 5.0, 0.0, 30.0));

    // Boom settings
    private final BooleanSetting autoJump = setting(new BooleanSetting("Auto Jump", "Jump to build fall.", true));
    private final BooleanSetting onlySlam = setting(new BooleanSetting("Only Slam", "Only attack when falling.", false));
    private final DoubleSetting fallAttackRange = setting(new DoubleSetting("Fall Attack Range", "Range during fall slam.", 4.0, 1.0, 7.0));
    private final BooleanSetting airStrafe = setting(new BooleanSetting("Air Strafe", "Control movement in air.", true));
    private final DoubleSetting airStrafeSpeed = setting(new DoubleSetting("Air Strafe Speed", "Horizontal air velocity.", 0.4, 0.1, 2.0));
    private final BooleanSetting autoWind = setting(new BooleanSetting("Auto Wind Charge", "Wind charge to launch.", false));
    private final IntegerSetting windCooldown = setting(new IntegerSetting("Wind Cooldown", "Ticks between wind uses.", 20, 5, 60));

    private final Random random = new Random();
    private int windTick;
    private int faceTicks;
    private boolean hasFaced;

    public AutoMace() {
        super("AutoMace", "Mace slam automation with ghost bypass and fall prediction.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        windTick = 0;
        faceTicks = 0;
        hasFaced = false;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (windTick > 0) windTick--;

        class_1309 target = CombatUtil.bestLivingTarget(
            client, range.get() + 2.0,
            players.enabled(), hostiles.enabled(), passives.enabled(),
            throughWalls.enabled(), priority.get()
        ).orElse(null);
        if (target == null) return;

        if (autoSwitch.enabled()) {
            int maceSlot = findMace(client.field_1724);
            if (maceSlot < 0) return;
            client.field_1724.method_31548().method_61496(maceSlot);
        }

        double dist = client.field_1724.method_5739(target);
        boolean isFalling = !client.field_1724.method_24828() && client.field_1724.method_18798().field_1351 < -0.1;
        boolean hasFallDist = client.field_1724.field_6017 >= minFallDist.get();
        boolean isGhost = bypass.is("Ghost") || bypass.is("Legit") || bypass.is("Grim");

        // Wind charge launch
        if (autoWind.enabled() && windTick <= 0 && client.field_1724.method_24828() && dist <= range.get() + 2.0) {
            int windSlot = findWindCharge(client.field_1724);
            if (windSlot >= 0) {
                client.field_1724.method_31548().method_61496(windSlot);
                client.field_1724.method_6043();
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                windTick = windCooldown.get() + random.nextInt(5);
                if (autoSwitch.enabled()) {
                    int mSlot = findMace(client.field_1724);
                    if (mSlot >= 0) client.field_1724.method_31548().method_61496(mSlot);
                }
            }
        }

        // Air strafe toward target
        if (airStrafe.enabled() && isFalling && dist > range.get()) {
            class_243 toTarget = new class_243(target.method_23317() - client.field_1724.method_23317(), 0, target.method_23321() - client.field_1724.method_23321()).method_1029();
            client.field_1724.method_18800(toTarget.field_1352 * airStrafeSpeed.get(), client.field_1724.method_18798().field_1351, toTarget.field_1350 * airStrafeSpeed.get());
        }

        // Jump to build fall
        if (autoJump.enabled() && client.field_1724.method_24828() && dist <= range.get() + 1.5 && !isGhost) {
            client.field_1724.method_6043();
        }

        // Face delay for ghost modes
        if (isGhost && !hasFaced && (isFalling || !onlySlam.enabled())) {
            float[] rots = CombatUtil.rotationsTo(client.field_1724, target.method_33571());
            rotations().setMaxStep(rotationSpeed.get().floatValue());
            float noiseYaw = (random.nextFloat() - 0.5f) * 2.0f;
            float noisePitch = (random.nextFloat() - 0.5f) * 1.0f;
            rotations().rotateToSilent(rots[0] + noiseYaw, rots[1] + noisePitch, Math.max(2, faceDelay.get()));
            faceTicks++;
            if (faceTicks >= faceDelay.get()) { hasFaced = true; faceTicks = 0; }
            return;
        }

        // Attack logic
        boolean canSlam = isFalling && hasFallDist && dist <= fallAttackRange.get();
        boolean canHit = !onlySlam.enabled() && dist <= range.get();

        if (isGhost && !hasFaced && !canSlam && !canHit) return;

        // Rotations
        if (silentRotate.enabled()) {
            float[] rots = CombatUtil.rotationsTo(client.field_1724, target.method_33571());
            rotations().setMaxStep(rotationSpeed.get().floatValue());

            int rotTicks = isGhost ? Math.max(2, faceDelay.get()) : 1;
            if (isGhost) {
                float ny = (random.nextFloat() - 0.5f) * 2.0f;
                float np = (random.nextFloat() - 0.5f) * 1.0f;
                rotations().rotateToSilent(rots[0] + ny, rots[1] + np, rotTicks);
            } else {
                rotations().rotateToSilent(rots[0], rots[1], rotTicks);
            }
        }

        // Timing
        int minTicks = Math.max(1, (int) Math.round(20.0 / cps.get()));
        int adjustedJitter = isGhost ? jitter.get() + random.nextInt(3) : jitter.get();
        boolean shouldMiss = isGhost && random.nextFloat() * 100 < missChance.get();

        if ((canSlam || canHit) && !shouldMiss && actionReady(minTicks, adjustedJitter)) {
            CombatUtil.attack(client, target);
            if (isGhost) { hasFaced = false; faceTicks = 0; }
        }
    }

    private int findMace(class_746 player) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.method_31548().method_5438(slot).method_31574(class_1802.field_49814)) return slot;
        }
        return -1;
    }

    private int findWindCharge(class_746 player) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.method_31548().method_5438(slot).method_31574(class_1802.field_49098)) return slot;
        }
        return -1;
    }
}
