package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

public final class AutoMace extends CombatModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Attack range.", 3.5, 1.0, 6.0));
    private final DoubleSetting minFallDist = setting(new DoubleSetting("Min Fall Dist", "Minimum fall distance for bonus.", 2.0, 0.0, 10.0));
    private final DoubleSetting cps = setting(new DoubleSetting("CPS", "Attacks per second.", 8.0, 1.0, 20.0));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks.", 2, 0, 8));
    private final ModeSetting priority = setting(new ModeSetting("Priority", "Target sort.", "Distance", "Distance", "Health", "Angle"));
    private final BooleanSetting autoSwitch = setting(new BooleanSetting("Auto Switch", "Swap to mace.", true));
    private final BooleanSetting autoJump = setting(new BooleanSetting("Auto Jump", "Jump to build fall distance.", true));
    private final BooleanSetting silentRotate = setting(new BooleanSetting("Silent Rotate", "Face target.", true));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Rotation speed.", 25.0, 1.0, 60.0));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Target players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Target hostile mobs.", true));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Target passive mobs.", false));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Ignore line of sight.", false));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anti-cheat.", "Vanilla", "Vanilla", "Legit", "Grim"));

    private final BooleanSetting autoWind = setting(new BooleanSetting("Auto Wind Charge", "Use wind charge to launch upward.", true));
    private final DoubleSetting windRange = setting(new DoubleSetting("Wind Range", "Target range to wind charge up.", 6.0, 2.0, 20.0));
    private final BooleanSetting airStrafe = setting(new BooleanSetting("Air Strafe", "Control movement in air toward target.", true));
    private final DoubleSetting airStrafeSpeed = setting(new DoubleSetting("Air Strafe Speed", "Horizontal air velocity.", 0.5, 0.1, 2.0));
    private final BooleanSetting onlySlam = setting(new BooleanSetting("Only Slam", "Only attack when falling with fall distance.", false));
    private final DoubleSetting fallAttackRange = setting(new DoubleSetting("Fall Attack Range", "Range during fall slam.", 4.0, 1.0, 7.0));

    // Prestige-style additions
    private final BooleanSetting breachCheck = setting(new BooleanSetting("Breach Check", "Only slam if target armor is not breached.", true));
    private final BooleanSetting triggerbotTiming = setting(new BooleanSetting("Triggerbot Timing", "Hit exactly when crosshair on target.", false));
    private final DoubleSetting breachArmorThreshold = setting(new DoubleSetting("Armor Threshold", "Max armor % to consider breached.", 0.3, 0.1, 1.0));

    // Wind charge integration
    private final BooleanSetting shortWindCharge = setting(new BooleanSetting("Short Wind Charge", "Fire wind at feet to launch up.", false));
    private final IntegerSetting shortWindCooldown = setting(new IntegerSetting("Short Wind Cooldown", "Ticks between short wind charges.", 30, 10, 80));

    private final Random random = new Random();
    private int windCooldown;
    private int shortWindCooldownCounter;

    public AutoMace() {
        super("AutoMace", "Prestige-style mace automation with breach check and wind charge integration.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        windCooldown = 0;
        shortWindCooldownCounter = 0;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (windCooldown > 0) windCooldown--;
        if (shortWindCooldownCounter > 0) shortWindCooldownCounter--;

        class_1309 target = CombatUtil.bestLivingTarget(
                client, range.get() + 2.0,
                players.enabled(), hostiles.enabled(), passives.enabled(),
                throughWalls.enabled(), priority.get()
        ).orElse(null);
        if (target == null) return;

        boolean isFalling = !client.field_1724.method_24828() && client.field_1724.method_18798().field_1351 < -0.1;
        boolean hasFallDist = client.field_1724.field_6017 >= minFallDist.get();

        if (autoSwitch.enabled()) {
            int maceSlot = findMace(client.field_1724);
            if (maceSlot < 0) return;
            if (maceSlot < 9) client.field_1724.method_31548().method_61496(maceSlot);
        }

        double dist = client.field_1724.method_5739(target);

        // Short Wind Charge at feet to launch up (Prestige-style)
        if (shortWindCharge.enabled() && shortWindCooldownCounter <= 0 && client.field_1724.method_24828() && dist <= range.get() + 2.0) {
            int windSlot = findWindCharge(client.field_1724);
            if (windSlot >= 0 && windSlot < 9) {
                client.field_1724.method_31548().method_61496(windSlot);
                client.field_1724.method_6043();
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                shortWindCooldownCounter = shortWindCooldown.get() + random.nextInt(10);
                windCooldown = 5;
            }
        }

        // Wind charge launch toward target
        if (autoWind.enabled() && windCooldown <= 0 && client.field_1724.method_24828() && dist <= windRange.get() && shortWindCooldownCounter <= 0) {
            int windSlot = findWindCharge(client.field_1724);
            if (windSlot >= 0 && windSlot < 9) {
                if (silentRotate.enabled()) {
                    float[] rots = CombatUtil.rotationsTo(client.field_1724, target.method_33571());
                    rotations().setMaxStep(rotationSpeed.get().floatValue());
                    rotations().rotateToSilent(rots[0], rots[1], 2);
                }
                client.field_1724.method_31548().method_61496(windSlot);
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                windCooldown = 10 + random.nextInt(5);
            }
        }

        // Air strafe toward target when falling
        if (airStrafe.enabled() && isFalling && dist > range.get()) {
            class_243 toTarget = new class_243(target.method_23317() - client.field_1724.method_23317(), 0, target.method_23321() - client.field_1724.method_23321()).method_1029();
            double vx = toTarget.field_1352 * airStrafeSpeed.get();
            double vz = toTarget.field_1350 * airStrafeSpeed.get();
            client.field_1724.method_18800(vx, client.field_1724.method_18798().field_1351, vz);
        }

        if (silentRotate.enabled()) {
            float[] rots = CombatUtil.rotationsTo(client.field_1724, target.method_33571());
            float yawDelta = Math.abs(class_3532.method_15393(rots[0] - client.field_1724.method_36454()));
            int ticks = Math.max(1, (int) Math.ceil(yawDelta / rotationSpeed.get().floatValue()));
            rotations().setMaxStep(rotationSpeed.get().floatValue());

            if (bypass.is("Grim") || bypass.is("Legit")) {
                float noiseYaw = (random.nextFloat() - 0.5f) * 2.0f;
                float noisePitch = (random.nextFloat() - 0.5f) * 1.0f;
                rotations().rotateToSilent(rots[0] + noiseYaw, rots[1] + noisePitch, Math.max(2, ticks));
            } else {
                rotations().rotateToSilent(rots[0], rots[1], Math.max(1, ticks));
            }
        }

        // Jump to build fall distance when close
        if (autoJump.enabled() && client.field_1724.method_24828() && dist <= range.get() + 1.5 && shortWindCooldownCounter <= 0) {
            client.field_1724.method_6043();
        }

        int minTicks = Math.max(1, (int) Math.round(20.0 / cps.get()));
        boolean shouldMiss = (bypass.is("Grim") || bypass.is("Legit")) && random.nextFloat() < 0.08f;
        boolean canSlam = isFalling && hasFallDist && dist <= fallAttackRange.get();
        boolean canHit = !onlySlam.enabled() && dist <= range.get();
        boolean groundHit = !onlySlam.enabled() && client.field_1724.method_24828() && dist <= range.get() && client.field_1724.field_6017 < 0.5f;

        // Breach check: skip slam if target's armor is already breached
        if (breachCheck.enabled() && canSlam) {
            double targetArmor = target.method_45325(net.minecraft.class_5134.field_23724);
            double maxArmor = 20.0;
            double armorRatio = targetArmor / maxArmor;
            if (armorRatio < breachArmorThreshold.get()) {
                canSlam = false;
            }
        }

        // Triggerbot timing: only hit when crosshair is on target
        if (triggerbotTiming.enabled()) {
            var crosshair = client.field_1765;
            if (crosshair == null || crosshair.method_17783() != net.minecraft.class_239.class_240.field_1331) {
                canSlam = false;
                canHit = false;
                groundHit = false;
            }
        }

        if ((canSlam || canHit || groundHit) && !shouldMiss) {
            if (actionReady(minTicks, jitter.get())) {
                CombatUtil.attack(client, target);
            }
        }
    }

    private int findMace(class_746 player) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.method_31548().method_5438(slot).method_31574(class_1802.field_49814)) return slot;
        }
        return -1;
    }

    private int findWindCharge(class_746 player) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.method_31548().method_5438(slot).method_31574(class_1802.field_49098)) return slot;
        }
        return -1;
    }
}
