package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_310;

public final class AntiVoid extends PlayerModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Anti-void method.", "Packet", "Packet", "Rubberband"));
    private final IntegerSetting triggerY = setting(new IntegerSetting("Trigger Y", "Y level to trigger.", -32, -64, 0));
    private final IntegerSetting packetCount = setting(new IntegerSetting("Packet Count", "Packets to send per tick.", 10, 1, 50));
    private final BooleanSetting pullUp = setting(new BooleanSetting("Pull Up", "Increases Y to pull back up.", true));

    private boolean wasFalling;

    public AntiVoid() {
        super("AntiVoid", "Prevents falling into the void.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        double y = client.field_1724.method_23318();
        if (y > triggerY.get()) {
            wasFalling = false;
            return;
        }

        if (client.field_1724.field_6017 <= 0 && wasFalling) return;
        wasFalling = true;

        class_243 pos = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());

        if (mode.is("Packet")) {
            for (int i = 0; i < packetCount.get(); i++) {
                double fakeY = pullUp.enabled() ? y + 10 + i : y;
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(
                    pos.field_1352, fakeY, pos.field_1350, true, false
                ));
            }
        } else if (mode.is("Rubberband") && client.field_1724.field_3944 != null) {
            client.field_1724.field_3944.method_52787(new class_2828.class_2829(
                pos.field_1352, pos.field_1351 + 20, pos.field_1350, false, false
            ));
        }
    }
}
