package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class AutoWindCharge extends CombatModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "When to use wind charges.", "On Jump", "On Jump", "Always", "Manual"));
    private final BooleanSetting requireMace = setting(new BooleanSetting("Require Mace", "Only use wind charges while holding a mace.", true));
    private final BooleanSetting autoSwitch = setting(new BooleanSetting("Auto Switch", "Auto-switch to wind charge in hotbar.", true));
    private final IntegerSetting useDelay = setting(new IntegerSetting("Use Delay", "Ticks between wind charge uses.", 10, 1, 40));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks between uses.", 3, 0, 10));

    private final BooleanSetting humanFailure = setting(new BooleanSetting("Human Failure", "Simulate human-like imperfections.", true));
    private final DoubleSetting failureChance = setting(new DoubleSetting("Failure Chance", "Chance per activation to skip (0-1).", 0.05, 0.0, 0.5));
    private final IntegerSetting aimVariance = setting(new IntegerSetting("Aim Variance", "Random pitch offset when using (degrees).", 5, 0, 30));
    private final IntegerSetting holdVariance = setting(new IntegerSetting("Hold Variance", "Extra ticks wind charge is 'held' before use.", 2, 0, 10));
    private final BooleanSetting doubleClickChance = setting(new BooleanSetting("Double Click Chance", "Small chance to use twice rapidly.", false));
    private final DoubleSetting doubleClickOdds = setting(new DoubleSetting("Double Click Odds", "Chance of double-click (0-1).", 0.03, 0.0, 0.2));

    private boolean wasOnGround = true;
    private int lastUseTick;
    private boolean doubleClickPending;
    private int heldTicks;
    private final Random random = new Random();

    public AutoWindCharge() {
        super("AutoWindCharge", "Automatically uses wind charges with human-like imperfections.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        wasOnGround = true;
        lastUseTick = 0;
        doubleClickPending = false;
        heldTicks = 0;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) return;

        lastUseTick++;

        if (requireMace.enabled() && !client.field_1724.method_6047().method_31574(class_1802.field_49814)) {
            doubleClickPending = false;
            return;
        }

        if (doubleClickPending) {
            int slot = findWindCharge(client);
            if (slot >= 0) {
                if (autoSwitch.enabled() && slot < 9) {
                    client.field_1724.method_31548().method_61496(slot);
                }
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
            }
            doubleClickPending = false;
            lastUseTick = 0;
            return;
        }

        boolean shouldUse = false;

        if (mode.is("On Jump")) {
            boolean onGround = client.field_1724.method_24828();
            if (wasOnGround && !onGround && client.field_1724.method_18798().field_1351 > 0) {
                shouldUse = true;
            }
            wasOnGround = onGround;
        } else if (mode.is("Always")) {
            if (client.field_1724.method_24828()) {
                shouldUse = true;
            }
        }

        if (!shouldUse) return;

        int baseDelay = useDelay.get();
        int extraJitter = jitter.get() > 0 ? random.nextInt(jitter.get() + 1) : 0;
        int humanHold = (humanFailure.enabled() && holdVariance.get() > 0) ? random.nextInt(holdVariance.get() + 1) : 0;
        int totalDelay = baseDelay + extraJitter + humanHold;

        if (lastUseTick < totalDelay) return;

        if (humanFailure.enabled() && failureChance.get() > 0 && random.nextFloat() < failureChance.get()) {
            lastUseTick = (int)(lastUseTick * 0.5);
            return;
        }

        int slot = findWindCharge(client);
        if (slot < 0) return;

        if (autoSwitch.enabled()) {
            if (slot < 9) {
                client.field_1724.method_31548().method_61496(slot);
            }
        }

        if (humanFailure.enabled() && aimVariance.get() > 0) {
            float pitchVar = (random.nextFloat() - 0.5f) * 2 * aimVariance.get();
            client.field_1724.method_36457(client.field_1724.method_36455() + pitchVar);
        }

        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
        lastUseTick = 0;

        if (humanFailure.enabled() && doubleClickChance.enabled() && doubleClickOdds.get() > 0 && random.nextFloat() < doubleClickOdds.get()) {
            doubleClickPending = true;
        }
    }

    private int findWindCharge(class_310 client) {
        for (int slot = 0; slot < 9; slot++) {
            if (client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_49098)) {
                return slot;
            }
        }
        return -1;
    }
}
