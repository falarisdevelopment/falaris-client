package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_310;
public final class AutoAttributeSwap extends CombatModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Swap mode.", "Smart", "Smart", "Air Only", "Ground Only"));
    private final BooleanSetting useBreach = setting(new BooleanSetting("Use Breach", "Swap to Breach mace on ground.", true));
    private final BooleanSetting useDensity = setting(new BooleanSetting("Use Density", "Swap to Density mace in air.", true));
    private final BooleanSetting preferBreach = setting(new BooleanSetting("Prefer Breach", "Prefer Breach when both enchants present.", true));
    private final BooleanSetting switchBack = setting(new BooleanSetting("Switch Back", "Return to sword after attacking.", true));
    private final IntegerSetting switchBackDelay = setting(new IntegerSetting("Switch Back Delay", "Ticks before switching back.", 5, 0, 20));
    private final DoubleSetting manualOverrideTime = setting(new DoubleSetting("Manual Override", "Seconds to respect manual slot change.", 2.0, 0.0, 10.0));
    private final BooleanSetting requireSword = setting(new BooleanSetting("Require Sword", "Only swap if holding a sword.", false));
    private final BooleanSetting hotbarOnly = setting(new BooleanSetting("Hotbar Only", "Only search hotbar for mace.", true));

    private int prevSlot = -1;
    private int tickCounter;
    private int switchBackWait;
    private long lastManualTime;
    private int lastKnownSlot = -1;
    private boolean hasAttacked;

    public AutoAttributeSwap() {
        super("AutoAttributeSwap", "Smart Breach/Density mace swapping based on ground/air state with manual override.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        tickCounter = 0;
        prevSlot = -1;
        switchBackWait = 0;
        lastManualTime = 0;
        lastKnownSlot = -1;
        hasAttacked = false;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null) return;
        tickCounter++;

        int currentSlot = client.field_1724.method_31548().method_67532();
        class_1799 mainHand = client.field_1724.method_6047();
        boolean isMace = mainHand.method_31574(class_1802.field_49814);
        boolean isSword = mainHand.method_7909() == class_1802.field_8091 || mainHand.method_7909() == class_1802.field_8528
            || mainHand.method_7909() == class_1802.field_8371 || mainHand.method_7909() == class_1802.field_8845
            || mainHand.method_7909() == class_1802.field_8802 || mainHand.method_7909() == class_1802.field_22022;

        // Detect manual override: user switched slots without our help
        if (lastKnownSlot != -1 && currentSlot != lastKnownSlot && !isMace && switchBackWait <= 0) {
            lastManualTime = System.currentTimeMillis();
        }
        lastKnownSlot = currentSlot;

        // Check if we're in manual override period
        if (isManualOverride()) return;

        // Handle switch-back after attack
        if (switchBackWait > 0) {
            switchBackWait--;
            if (switchBackWait <= 0 && switchBack.enabled() && isMace && prevSlot >= 0 && prevSlot < 9) {
                client.field_1724.method_31548().method_61496(prevSlot);
                prevSlot = -1;
            }
            return;
        }

        // Detect attack with mace - start switch-back timer
        if (isMace && client.field_1690.field_1886.method_1434() && client.field_1724.field_6252) {
            hasAttacked = true;
            if (switchBack.enabled() && prevSlot >= 0 && prevSlot < 9) {
                switchBackWait = switchBackDelay.get();
            }
        }

        boolean isAirborne = !client.field_1724.method_24828() || client.field_1724.field_6017 > 1.0f;
        boolean airMode = mode.is("Smart") || mode.is("Air Only");
        boolean groundMode = mode.is("Smart") || mode.is("Ground Only");

        // Check if we should equip mace
        boolean shouldEquip = false;
        String enchantPreference = null;

        if (airMode && isAirborne) {
            shouldEquip = useDensity.enabled() && findBestMace(client, "density") != -1;
            enchantPreference = "density";
        } else if (groundMode && !isAirborne) {
            shouldEquip = useBreach.enabled() && (findBestMace(client, "breach") != -1 || findBestMace(client, null) != -1);
            enchantPreference = preferBreach.enabled() ? "breach" : null;
        }

        if (!shouldEquip) {
            // If we have a mace equipped and shouldn't, consider switching back
            if (isMace && prevSlot >= 0 && prevSlot < 9 && switchBack.enabled() && tickCounter > 5) {
                client.field_1724.method_31548().method_61496(prevSlot);
                prevSlot = -1;
            }
            return;
        }

        // Don't swap if we require sword and aren't holding one
        if (requireSword.enabled() && !isMace && !isSword) return;

        // Find and equip the best mace
        int maceSlot = findBestMace(client, enchantPreference);
        if (maceSlot == -1) return;

        if (!isMace && tickCounter >= 3) {
            if (prevSlot == -1) {
                prevSlot = currentSlot;
            }
            if (maceSlot < 9) {
                client.field_1724.method_31548().method_61496(maceSlot);
                tickCounter = 0;
            }
        }
    }

    private boolean isManualOverride() {
        if (manualOverrideTime.get() <= 0) return false;
        return System.currentTimeMillis() - lastManualTime < manualOverrideTime.get() * 1000;
    }

    private int findBestMace(class_310 client, String preferredEnchant) {
        int bestSlot = -1;
        int bestScore = -1;
        int limit = hotbarOnly.enabled() ? 9 : 36;

        for (int slot = 0; slot < limit; slot++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(slot);
            if (!stack.method_31574(class_1802.field_49814)) continue;

            int score = slot < 9 ? 3 : 0;
            boolean hasBreach = hasEnchantment(stack, "breach");
            boolean hasDensity = hasEnchantment(stack, "density");

            if (preferredEnchant != null) {
                if (preferredEnchant.equals("breach") && hasBreach) score += 5;
                if (preferredEnchant.equals("density") && hasDensity) score += 5;
                // Still usable even without preferred enchant
                if (hasBreach || hasDensity) score += 1;
            } else {
                if (hasBreach) score += 2;
                if (hasDensity) score += 2;
            }

            if (score > bestScore) {
                bestScore = score;
                bestSlot = slot;
            }
        }
        return bestSlot;
    }

    private boolean hasEnchantment(class_1799 stack, String name) {
        var ench = class_1890.method_57532(stack);
        if (ench == null) return false;
        var list = ench.method_57534();
        if (list.isEmpty()) return false;
        // Use toString as a simple check matching existing codebase pattern
        return ench.toString().toLowerCase().contains(name);
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && prevSlot >= 0 && prevSlot < 9) {
            client.field_1724.method_31548().method_61496(prevSlot);
        }
        prevSlot = -1;
        tickCounter = 0;
        switchBackWait = 0;
        hasAttacked = false;
    }
}
