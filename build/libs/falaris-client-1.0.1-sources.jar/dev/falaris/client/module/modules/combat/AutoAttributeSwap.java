package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class AutoAttributeSwap extends CombatModule {
    private final BooleanSetting swordToMace = setting(new BooleanSetting("Sword to Mace", "Swap sword to mace when airborne.", true));
    private final BooleanSetting preferBreach = setting(new BooleanSetting("Prefer Breach", "Prefer mace with Breach enchant.", true));
    private final BooleanSetting preferDensity = setting(new BooleanSetting("Prefer Density", "Prefer mace with Density enchant.", true));
    private final BooleanSetting detectAirborne = setting(new BooleanSetting("Detect Airborne", "Swap when falling or flying.", true));
    private final BooleanSetting detectElytra = setting(new BooleanSetting("Detect Elytra", "Swap when elytra flying.", true));
    private final IntegerSetting swapDelay = setting(new IntegerSetting("Swap Delay", "Ticks between swaps.", 10, 1, 40));
    private final BooleanSetting swapBackOnGround = setting(new BooleanSetting("Swap Back on Ground", "Return to previous slot when on ground.", true));
    private final BooleanSetting preferMaceOnly = setting(new BooleanSetting("Spear Mace", "Swap to mace even when holding non-sword weapons.", false));

    private int lastNonMaceSlot = -1;
    private int tickCounter;
    private boolean hasMaceEquipped;

    public AutoAttributeSwap() {
        super("AutoAttributeSwap", "Auto-swaps between sword and mace based on fall state. Spear mace mode swaps any held item to mace.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        tickCounter = 0;
        lastNonMaceSlot = -1;
        hasMaceEquipped = false;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null) return;

        tickCounter++;
        class_1799 mainHand = client.field_1724.method_6047();
        boolean isMace = mainHand.method_7909() == class_1802.field_49814;
        boolean shouldUseMace = shouldUseMace(client);

        int currentSlot = client.field_1724.method_31548().method_67532();

        if (isMace) {
            hasMaceEquipped = true;
        }

        if (!shouldUseMace && isMace && hasMaceEquipped && lastNonMaceSlot >= 0 && lastNonMaceSlot < 9 && tickCounter >= swapDelay.get()) {
            if (swapBackOnGround.enabled()) {
                client.field_1724.method_31548().method_61496(lastNonMaceSlot);
                lastNonMaceSlot = -1;
                hasMaceEquipped = false;
                tickCounter = 0;
            }
            return;
        }

        if (shouldUseMace) {
            if (!isMace && tickCounter >= swapDelay.get()) {
                int maceSlot = findBestMace(client.field_1724);
                if (maceSlot >= 0 && maceSlot < 9) {
                    if (!isMace && preferMaceOnly.enabled() && swordToMace.enabled()) {
                        lastNonMaceSlot = currentSlot;
                    } else if (!isMace && isSwordItem(mainHand.method_7909()) && swordToMace.enabled()) {
                        lastNonMaceSlot = currentSlot;
                    }
                    if (lastNonMaceSlot >= 0) {
                        client.field_1724.method_31548().method_61496(maceSlot);
                        hasMaceEquipped = true;
                        tickCounter = 0;
                    }
                }
            }
        } else {
            if (!isMace && lastNonMaceSlot == -1) {
                lastNonMaceSlot = currentSlot;
            }
        }
    }

    private boolean shouldUseMace(class_310 client) {
        class_746 player = client.field_1724;
        if (detectAirborne.enabled()) {
            if (!player.method_24828() || player.field_6017 > 2.0f) return true;
        }
        if (detectElytra.enabled()) {
            class_1799 chest = player.method_6118(class_1304.field_6174);
            if (chest.method_31574(class_1802.field_8833) && player.method_6128()) return true;
        }
        return false;
    }

    private int findBestMace(class_746 player) {
        int bestSlot = -1;
        int bestScore = -1;

        for (int slot = 0; slot < 36; slot++) {
            class_1799 stack = player.method_31548().method_5438(slot);
            if (!stack.method_31574(class_1802.field_49814)) continue;

            int score = 0;
            if (slot < 9) score += 3;
            var ench = stack.method_58694(net.minecraft.class_9334.field_49633);
            if (ench != null && preferBreach.enabled()) {
                String s = ench.toString().toLowerCase();
                if (s.contains("breach")) score += 2;
            }
            if (ench != null && preferDensity.enabled()) {
                String s = ench.toString().toLowerCase();
                if (s.contains("density")) score += 2;
            }

            if (score > bestScore) {
                bestScore = score;
                bestSlot = slot;
            }
        }
        return bestSlot;
    }

    private boolean isSwordItem(net.minecraft.class_1792 item) {
        return item == class_1802.field_8091 || item == class_1802.field_8528
            || item == class_1802.field_8371 || item == class_1802.field_8845
            || item == class_1802.field_8802 || item == class_1802.field_22022;
    }
}
