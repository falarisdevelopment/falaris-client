package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4174;
import net.minecraft.class_9334;

public final class AutoEat extends PlayerModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "When to eat.", "Hunger", "Hunger", "Always"));
    private final DoubleSetting hungerThreshold = setting(new DoubleSetting("Hunger", "Hunger bar level to eat at.", 6.0, 1.0, 19.0));
    private final DoubleSetting saturationThreshold = setting(new DoubleSetting("Saturation", "Saturation threshold.", 4.0, 0.0, 20.0));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between actions.", 10, 1, 40));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks.", 5, 0, 20));
    private final BooleanSetting preferCooked = setting(new BooleanSetting("Prefer Cooked", "Prefer cooked food over raw.", true));
    private final ModeSetting foodPriority = setting(new ModeSetting("Food Priority", "Which food to prefer.", "Best Saturation", "Best Saturation", "Best Hunger"));

    public AutoEat() {
        super("AutoEat", "Auto-eats food when hunger or saturation is low.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (client.field_1724.method_6115()) return;
        if (mode.is("Hunger")) {
            if (client.field_1724.method_7344().method_7586() > hungerThreshold.get()) return;
            if (client.field_1724.method_7344().method_7589() > saturationThreshold.get()) return;
        }
        if (!ready(delay.get(), jitter.get())) return;

        int bestSlot = -1;
        double bestScore = -1;

        for (int i = 0; i < 36; i++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_7960()) continue;

            class_4174 food = stack.method_58694(class_9334.field_50075);
            if (food == null) continue;

            double score = scoreFood(food);
            if (preferCooked.enabled() && stack.method_58694(class_9334.field_50075) != null) {
                String itemName = stack.method_7909().method_7876().toLowerCase();
                if (itemName.contains("raw") || itemName.contains("rotten") || itemName.contains("poison")) {
                    score -= 5.0;
                }
            }
            if (score > bestScore) {
                bestScore = score;
                bestSlot = i;
            }
        }

        if (bestSlot == -1) return;

        int hotbarSlot = bestSlot;
        if (bestSlot >= 9) {
            int emptyHotbar = -1;
            for (int h = 0; h < 9; h++) {
                if (client.field_1724.method_31548().method_5438(h).method_7960()) {
                    emptyHotbar = h;
                    break;
                }
            }
            if (emptyHotbar != -1) {
                int screenSlot = InventoryUtil.screenSlotForInventoryIndex(bestSlot);
                int targetSlot = 36 + emptyHotbar;
                InventoryUtil.clickMove(client, screenSlot, targetSlot);
                hotbarSlot = emptyHotbar;
            } else {
                hotbarSlot = bestSlot >= 36 ? bestSlot - 36 : client.field_1724.method_31548().method_67532();
            }
        }

        client.field_1724.method_31548().method_61496(hotbarSlot);
        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
    }

    private double scoreFood(class_4174 food) {
        if (foodPriority.is("Best Hunger")) {
            return food.comp_2491();
        }
        return food.comp_2492();
    }
}
