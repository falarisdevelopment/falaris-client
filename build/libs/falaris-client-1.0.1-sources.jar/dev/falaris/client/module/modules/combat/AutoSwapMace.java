package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class AutoSwapMace extends CombatModule {
    private final DoubleSetting fallThreshold = setting(new DoubleSetting("Fall Threshold", "Minimum fall distance to swap to mace.", 3.0, 1.0, 10.0));
    private final ModeSetting swapBack = setting(new ModeSetting("Swap Back", "When to swap back to previous slot.", "Never", "Never", "After Attack", "On Landing"));
    private final IntegerSetting swapBackDelay = setting(new IntegerSetting("Swap Back Delay", "Ticks after swap before switching back.", 5, 0, 20));
    private final BooleanSetting requireTarget = setting(new BooleanSetting("Require Target", "Only swap when a target is nearby.", true));
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Range to detect nearby targets.", 6.0, 2.0, 12.0));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Target players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Target hostile mobs.", false));
    private final BooleanSetting passives = setting(new BooleanSetting("Passives", "Target passive mobs.", false));
    private final IntegerSetting cooldown = setting(new IntegerSetting("Cooldown", "Ticks before next swap attempt.", 10, 0, 40));

    private int previousSlot = -1;
    private int swapTimer;
    private int cooldownTimer;
    private boolean swappedThisFall;

    public AutoSwapMace() {
        super("AutoSwapMace", "Automatically swaps to a mace when falling for slam attacks.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        previousSlot = -1;
        swapTimer = 0;
        cooldownTimer = 0;
        swappedThisFall = false;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (cooldownTimer < cooldown.get()) { cooldownTimer++; return; }

        boolean isFalling = !client.field_1724.method_24828() && client.field_1724.method_18798().field_1351 < -0.1;
        boolean onGround = client.field_1724.method_24828();

        if (onGround) {
            if (swapBack.is("On Landing") && swappedThisFall && swapTimer <= 0) {
                restoreSlot(client);
            }
            swappedThisFall = false;
            swapTimer = 0;
        }

        if (swapTimer > 0) swapTimer--;

        if (!isFalling || client.field_1724.field_6017 < fallThreshold.get()) {
            if (swapBack.is("After Attack") && swappedThisFall && swapTimer <= 0) {
                if (onGround) restoreSlot(client);
            }
            return;
        }

        if (requireTarget.enabled()) {
            boolean hasTarget = client.field_1687.method_8390(
                class_1309.class,
                client.field_1724.method_5829().method_1014(targetRange.get()),
                e -> e != client.field_1724 && e.method_5805() && CombatUtil.isValidTarget(
                    client.field_1724, e, targetRange.get(),
                    players.enabled(), hostiles.enabled(), passives.enabled(), false
                )
            ).stream().findAny().isPresent();
            if (!hasTarget) return;
        }

        if (client.field_1724.method_6047().method_31574(class_1802.field_49814)) {
            swappedThisFall = true;
            return;
        }

        int maceSlot = findMace(client);
        if (maceSlot < 0) return;

        if (!swappedThisFall) {
            previousSlot = client.field_1724.method_31548().method_67532();
        }
        client.field_1724.method_31548().method_61496(maceSlot);
        swappedThisFall = true;
        swapTimer = swapBackDelay.get();
        cooldownTimer = 0;
    }

    private void restoreSlot(class_310 client) {
        if (previousSlot >= 0 && previousSlot < 9 && swappedThisFall) {
            client.field_1724.method_31548().method_61496(previousSlot);
            previousSlot = -1;
            swappedThisFall = false;
        }
    }

    private int findMace(class_310 client) {
        for (int slot = 0; slot < 9; slot++) {
            if (client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_49814)) {
                return slot;
            }
        }
        return -1;
    }
}
