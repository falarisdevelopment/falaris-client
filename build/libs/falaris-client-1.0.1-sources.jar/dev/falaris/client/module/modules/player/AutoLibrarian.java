package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import dev.falaris.client.setting.Setting;
import java.util.Locale;
import java.util.stream.Collectors;
import net.minecraft.class_1728;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1914;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_492;

public final class AutoLibrarian extends PlayerModule {
    private final TextSetting enchantQuery = setting(new TextSetting("Enchant Query", "Case-insensitive enchant text to look for.", "mending"));
    private final IntegerSetting maxEmeralds = setting(new IntegerSetting("Max Emeralds", "Maximum emerald price accepted.", 24, 1, 64));
    private final IntegerSetting minLevel = setting(new IntegerSetting("Min Level", "Minimum trade index to scan from.", 1, 1, 5));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks between librarian checks.", 10, 1, 100));
    private final IntegerSetting jitter = setting(new IntegerSetting("Jitter", "Random extra ticks between checks.", 5, 0, 100));
    private final ModeSetting mode = setting(new ModeSetting("Mode", "What to do when a matching trade is found.", "Notify", "Notify", "Select", "Close On Miss"));
    private final BooleanSetting enchantedBooksOnly = setting(new BooleanSetting("Books Only", "Only accept enchanted book trades.", true));

    private String lastMatch = "";

    public AutoLibrarian() {
        super("AutoLibrarian", "Scans librarian trades for desired enchanted books.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (!(client.field_1755 instanceof class_492) || !(client.field_1724.field_7512 instanceof class_1728 handler)) {
            return;
        }
        if (!ready(delay.get(), jitter.get())) {
            return;
        }

        String query = enchantQuery.get().toLowerCase(Locale.ROOT).trim();
        for (int index = Math.max(0, minLevel.get() - 1); index < handler.method_17438().size(); index++) {
            class_1914 offer = handler.method_17438().get(index);
            class_1799 sell = offer.method_8250();
            int emeralds = emeraldCost(offer);
            String text = searchableText(client, sell);
            boolean book = sell.method_31574(class_1802.field_8598);

            if (enchantedBooksOnly.enabled() && !book) {
                continue;
            }
            if (emeralds > maxEmeralds.get()) {
                continue;
            }
            if (!query.isEmpty() && !text.contains(query)) {
                continue;
            }

            handler.method_7650(index);
            lastMatch = "Trade " + (index + 1) + ": " + sell.method_7964().getString() + " for " + emeralds + " emeralds";
            if (mode.is("Notify") || mode.is("Select")) {
                client.field_1724.method_7353(net.minecraft.class_2561.method_43470("[Falaris] Librarian match: " + lastMatch), false);
            }
            return;
        }

        lastMatch = "";
        if (mode.is("Close On Miss")) {
            client.field_1724.method_7346();
        }
    }

    private int emeraldCost(class_1914 offer) {
        int cost = 0;
        if (offer.method_19272().method_31574(class_1802.field_8687)) {
            cost += offer.method_19272().method_7947();
        }
        if (offer.method_8247().method_31574(class_1802.field_8687)) {
            cost += offer.method_8247().method_7947();
        }
        return cost == 0 ? 64 : cost;
    }

    private String searchableText(class_310 client, class_1799 stack) {
        String tooltip = stack.method_7950(class_1792.class_9635.method_59528(client.field_1687), client.field_1724, class_1836.field_41070)
                .stream()
                .map(class_2561::getString)
                .collect(Collectors.joining(" "));
        return (stack.method_7964().getString() + " " + tooltip).toLowerCase(Locale.ROOT);
    }

    public String getLastMatch() {
        return lastMatch;
    }

    private static final class TextSetting extends Setting<String> {
        private TextSetting(String name, String description, String defaultValue) {
            super(name, description, defaultValue);
        }
    }
}
