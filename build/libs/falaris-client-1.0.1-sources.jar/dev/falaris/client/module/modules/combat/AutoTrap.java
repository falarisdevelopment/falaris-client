package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class AutoTrap extends CombatModule {
    private final ModeSetting blockType = setting(new ModeSetting("Block Type", "Block to place.", "Obsidian", "Obsidian", "Crying Obsidian", "Netherite Block", "End Stone"));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Target range.", 5.0, 2.0, 8.0));
    private final BooleanSetting above = setting(new BooleanSetting("Above", "Place block above target.", true));
    private final BooleanSetting surround = setting(new BooleanSetting("Surround", "Place blocks around target.", true));
    private final BooleanSetting ceiling = setting(new BooleanSetting("Ceiling", "Place block at target head level.", false));
    private final BooleanSetting toggleAfterTrap = setting(new BooleanSetting("Toggle After Trap", "Disable after full trap.", false));
    private final IntegerSetting blocksPerTick = setting(new IntegerSetting("Blocks Per Tick", "Max blocks per tick.", 2, 1, 6));

    private int tickCounter;
    private class_1309 target;

    public AutoTrap() {
        super("AutoTrap", "Traps enemies by placing blocks around them.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        tickCounter++;
        if (tickCounter < 2) return;
        tickCounter = 0;

        target = CombatUtil.bestLivingTarget(client, range.get(), true, false, false, false, "Distance").orElse(null);
        if (target == null) return;

        if (!hasBlock(client)) return;
        class_2338 tPos = target.method_24515();
        int placed = 0;

        if (above.enabled() && placed < blocksPerTick.get()) {
            class_2338 up = tPos.method_10086(2);
            if (canPlace(client, up) && tryPlace(client, up)) placed++;
        }
        if (ceiling.enabled() && placed < blocksPerTick.get()) {
            class_2338 ceil = tPos.method_10086(1);
            if (canPlace(client, ceil) && tryPlace(client, ceil)) placed++;
        }
        if (surround.enabled()) {
            class_2338[] around = {
                tPos.method_10095(), tPos.method_10072(), tPos.method_10078(), tPos.method_10067(),
                tPos.method_10095().method_10078(), tPos.method_10095().method_10067(), tPos.method_10072().method_10078(), tPos.method_10072().method_10067()
            };
            for (class_2338 p : around) {
                if (placed >= blocksPerTick.get()) break;
                if (canPlace(client, p) && tryPlace(client, p)) placed++;
            }
        }

        if (toggleAfterTrap.enabled() && placed == 0) setEnabled(false);
    }

    private boolean canPlace(class_310 client, class_2338 pos) {
        return client.field_1687.method_8320(pos).method_26215() &&
               client.field_1724.method_5707(class_243.method_24953(pos)) <= 36 &&
               client.field_1687.method_8320(pos.method_10074()).method_51367();
    }

    private boolean tryPlace(class_310 client, class_2338 pos) {
        int slot = findBlock(client);
        if (slot < 0) return false;
        client.field_1724.method_31548().method_61496(slot);

        for (class_2350 dir : class_2350.values()) {
            class_2338 neighbor = pos.method_10093(dir);
            if (!client.field_1687.method_8320(neighbor).method_26215()) {
                class_243 hit = class_243.method_24953(neighbor).method_1019(class_243.method_24954(dir.method_10153().method_62675()).method_1021(0.5));
                class_3965 result = new class_3965(hit, dir.method_10153(), neighbor, false);
                client.field_1761.method_2896(client.field_1724, class_1268.field_5808, result);
                client.field_1724.method_6104(class_1268.field_5808);
                return true;
            }
        }
        return false;
    }

    private int findBlock(class_310 client) {
        for (int slot = 0; slot < 9; slot++) {
            var stack = client.field_1724.method_31548().method_5438(slot);
            if (stack.method_7960()) continue;
            boolean match = switch (blockType.get()) {
                case "Obsidian" -> stack.method_31574(net.minecraft.class_1802.field_8281);
                case "Crying Obsidian" -> stack.method_31574(net.minecraft.class_1802.field_22421);
                case "Netherite Block" -> stack.method_31574(net.minecraft.class_1802.field_22018);
                case "End Stone" -> stack.method_31574(net.minecraft.class_1802.field_20399);
                default -> false;
            };
            if (match) return slot;
        }
        return -1;
    }

    private boolean hasBlock(class_310 client) {
        return findBlock(client) >= 0;
    }

    @Override protected void onEnable() { super.onEnable(); target = null; tickCounter = 0; }
}
