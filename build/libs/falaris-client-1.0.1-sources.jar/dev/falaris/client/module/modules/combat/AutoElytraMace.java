package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Comparator;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class AutoElytraMace extends CombatModule {
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Max target distance.", 30.0, 4.0, 60.0));
    private final DoubleSetting minFallDistance = setting(new DoubleSetting("Min Fall Distance", "Min fall distance to attack.", 5.0, 2.0, 20.0));
    private final DoubleSetting attackRange = setting(new DoubleSetting("Attack Range", "Range to attack.", 4.0, 1.0, 6.0));
    private final BooleanSetting autoEquip = setting(new BooleanSetting("Auto Equip", "Equip elytra from hotbar.", true));
    private final BooleanSetting autoStartFlying = setting(new BooleanSetting("Auto Start Flying", "Auto-start elytra when falling.", true));
    private final BooleanSetting players = setting(new BooleanSetting("Players", "Target players.", true));
    private final BooleanSetting hostiles = setting(new BooleanSetting("Hostiles", "Target hostiles.", false));
    private final BooleanSetting diveBomb = setting(new BooleanSetting("Dive Bomb", "Rocket boost to dive.", true));
    private final ModeSetting diveMode = setting(new ModeSetting("Dive Mode", "Dive propellant.", "Firework", "Firework", "Wind Charge", "Both"));
    private final DoubleSetting diveRange = setting(new DoubleSetting("Dive Range", "Range to start dive.", 12.0, 4.0, 35.0));
    private final IntegerSetting fireworkDelay = setting(new IntegerSetting("Firework Delay", "Ticks between boosts.", 15, 5, 50));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anti-cheat.", "Vanilla", "Vanilla", "Legit", "Grim"));

    private final Random random = new Random();
    private class_1309 target;
    private int fireworkTick;

    public AutoElytraMace() {
        super("AutoElytraMace", "Auto elytra combat with mace slam and dive bomb.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        target = null;
        fireworkTick = 0;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        if (target == null || !target.method_5805() || client.field_1724.method_5858(target) > targetRange.get() * targetRange.get()) {
            target = findTarget(client);
        }
        if (target == null) return;

        boolean isLegit = bypass.is("Legit") || bypass.is("Grim");
        if (isLegit && random.nextFloat() < 0.10f) return;

        fireworkTick++;

        if (autoEquip.enabled()) {
            int elytraSlot = CombatUtil.findItem(client.field_1724, class_1802.field_8833);
            if (elytraSlot != -1 && !client.field_1724.method_6118(net.minecraft.class_1304.field_6174).method_31574(class_1802.field_8833)) {
                CombatUtil.selectHotbarSlot(client.field_1724, elytraSlot);
            }
        }

        if (autoStartFlying.enabled() && !client.field_1724.method_24828() && !client.field_1724.method_6128() && client.field_1724.method_18798().field_1351 < -0.3) {
            client.field_1724.field_3944.method_52787(new net.minecraft.class_2848(
                client.field_1724, net.minecraft.class_2848.class_2849.field_12982
            ));
        }

        double dist = client.field_1724.method_5739(target);

        if (client.field_1724.method_6128() && diveBomb.enabled() && dist <= diveRange.get() && fireworkTick >= fireworkDelay.get()) {
            boolean above = client.field_1724.method_23318() > target.method_23318() + 2.0;
            if (above || dist > attackRange.get()) {
                boolean used = false;
                if (diveMode.is("Firework") || diveMode.is("Both")) {
                    int fw = CombatUtil.findItem(client.field_1724, class_1802.field_8639);
                    if (fw >= 0 && fw < 9) {
                        CombatUtil.selectHotbarSlot(client.field_1724, fw);
                        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                        used = true;
                    }
                }
                if (!used && (diveMode.is("Wind Charge") || diveMode.is("Both"))) {
                    int wc = CombatUtil.findItem(client.field_1724, class_1802.field_49098);
                    if (wc >= 0 && wc < 9) {
                        CombatUtil.selectHotbarSlot(client.field_1724, wc);
                        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                    }
                }
                fireworkTick = 0;
            }
        }

        if (client.field_1724.field_6017 >= minFallDistance.get() && dist <= attackRange.get()) {
            int maceSlot = CombatUtil.findItem(client.field_1724, class_1802.field_49814);
            if (maceSlot != -1 && maceSlot < 9) {
                CombatUtil.selectHotbarSlot(client.field_1724, maceSlot);
            }
            if (actionReady(1, 0)) {
                CombatUtil.attack(client, target);
            }
        }
    }

    private class_1309 findTarget(class_310 client) {
        return client.field_1687.method_8390(class_1309.class, client.field_1724.method_5829().method_1014(targetRange.get()), entity -> {
            if (entity == client.field_1724 || !entity.method_5805()) return false;
            if (entity instanceof class_1657) return players.enabled();
            return hostiles.enabled() && entity instanceof net.minecraft.class_1588;
        }).stream().min(Comparator.comparingDouble(client.field_1724::method_5739)).orElse(null);
    }
}
