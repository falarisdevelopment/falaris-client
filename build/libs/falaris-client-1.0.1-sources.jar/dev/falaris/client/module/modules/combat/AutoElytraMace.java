package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Comparator;
import java.util.Optional;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class AutoElytraMace extends CombatModule {
    private final ModeSetting targetMode = setting(new ModeSetting("Target Mode", "Who to target.", "Players", "Players", "Hostiles", "All"));
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Max target distance.", 40.0, 8.0, 80.0));
    private final DoubleSetting attackRange = setting(new DoubleSetting("Attack Range", "Range to perform mace hit.", 4.5, 2.0, 6.0));
    private final DoubleSetting minFallDistance = setting(new DoubleSetting("Min Fall Distance", "Min fall for mace damage.", 4.0, 2.0, 30.0));
    private final DoubleSetting idealFallDistance = setting(new DoubleSetting("Ideal Fall", "Ideal fall for max damage.", 12.0, 4.0, 50.0));
    private final DoubleSetting diveHeight = setting(new DoubleSetting("Dive Height", "Height above target to start dive.", 15.0, 5.0, 50.0));

    private final BooleanSetting autoEquip = setting(new BooleanSetting("Auto Equip", "Equip elytra and mace.", true));
    private final BooleanSetting autoStartFlying = setting(new BooleanSetting("Auto Start Flying", "Auto-start elytra.", true));
    private final ModeSetting boostMode = setting(new ModeSetting("Boost Mode", "Dive propellant.", "Firework", "Firework", "Wind Charge", "Pearl", "Both"));
    private final IntegerSetting boostDelay = setting(new IntegerSetting("Boost Delay", "Ticks between boosts.", 10, 2, 30));
    private final BooleanSetting boostInDive = setting(new BooleanSetting("Boost in Dive", "Use boosts during dive.", true));

    private final BooleanSetting silentRotate = setting(new BooleanSetting("Silent Rotate", "Face target silently.", true));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Rotation speed.", 25.0, 5.0, 60.0));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anti-cheat.", "Vanilla", "Vanilla", "Vanilla", "Ghost", "Grim"));

    private final BooleanSetting autoSwitchMace = setting(new BooleanSetting("Auto Switch Mace", "Switch to mace before hitting.", true));
    private final BooleanSetting autoSwitchSword = setting(new BooleanSetting("Auto Switch Sword", "Switch back to sword after hit.", true));
    private final IntegerSetting postHitDelay = setting(new IntegerSetting("Post-Hit Delay", "Ticks after hit before next action.", 10, 1, 30));

    private final Random random = new Random();
    private class_1309 target;
    private int boostTick;
    private int postHitWait;
    private int prevSlot;
    private boolean hitThisDive;
    private DivePhase divePhase;

    private enum DivePhase { CLIMB, DIVE, STRIKE, RECOVER }

    public AutoElytraMace() {
        super("AutoElytraMace", "Advanced elytra+mace dive bomb with boost management and smart timing.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        target = null;
        boostTick = 0;
        postHitWait = 0;
        prevSlot = -1;
        hitThisDive = false;
        divePhase = DivePhase.CLIMB;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        if (postHitWait > 0) { postHitWait--; return; }

        // Find/refresh target
        if (target == null || !target.method_5805() || client.field_1724.method_5858(target) > targetRange.get() * targetRange.get()) {
            target = findTarget(client);
        }
        if (target == null) return;

        boolean isGhost = bypass.is("Ghost") || bypass.is("Grim");
        if (isGhost && random.nextFloat() < 0.06f) return;

        boostTick++;

        // Auto equip elytra
        if (autoEquip.enabled()) {
            ensureElytraEquipped(client);
        }

        // Auto start flying
        if (autoStartFlying.enabled() && shouldStartGliding(client)) {
            startGliding(client);
        }

        // Determine dive phase based on state
        updateDivePhase(client);

        // Execute phase actions
        switch (divePhase) {
            case CLIMB -> doClimb(client);
            case DIVE -> doDive(client);
            case STRIKE -> doStrike(client);
            case RECOVER -> doRecover(client);
        }
    }

    private void updateDivePhase(class_310 client) {
        if (!client.field_1724.method_6128()) {
            divePhase = DivePhase.CLIMB;
            hitThisDive = false;
            return;
        }

        double heightAbove = client.field_1724.method_23318() - target.method_23318();
        double dist = client.field_1724.method_5739(target);

        if (divePhase == DivePhase.STRIKE) return; // Don't override while striking

        if (divePhase == DivePhase.RECOVER && client.field_1724.method_24828()) {
            divePhase = DivePhase.CLIMB;
            hitThisDive = false;
            return;
        }

        if (heightAbove >= diveHeight.get() && dist > attackRange.get() * 2) {
            divePhase = DivePhase.DIVE;
        } else if (heightAbove < diveHeight.get() && dist > attackRange.get() && client.field_1724.method_18798().field_1351 < -0.5) {
            divePhase = DivePhase.DIVE;
        } else if (heightAbove > 2.0 && dist <= attackRange.get() && client.field_1724.field_6017 >= minFallDistance.get()) {
            divePhase = DivePhase.STRIKE;
        } else if (heightAbove <= 2.0 && dist > attackRange.get()) {
            divePhase = DivePhase.CLIMB;
        }
    }

    private void doClimb(class_310 client) {
        // Face toward target while climbing
        faceTarget(client, target, 1.0f);

        // Boost upward
        if (boostTick >= boostDelay.get()) {
            useBoostItem(client);
            boostTick = 0;
        }

        // Start gliding if falling
        if (client.field_1724.method_18798().field_1351 < -0.3 && !client.field_1724.method_6128()) {
            startGliding(client);
        }
    }

    private void doDive(class_310 client) {
        double dist = client.field_1724.method_5739(target);
        double heightAbove = client.field_1724.method_23318() - target.method_23318();

        // Face target while diving
        faceTarget(client, target, 1.0f);

        // Boost toward target
        if (boostInDive.enabled() && boostTick >= boostDelay.get() && heightAbove > 2.0) {
            useBoostItem(client);
            boostTick = 0;
        }

        // Check if we're close enough to strike
        if (dist <= attackRange.get() && client.field_1724.field_6017 >= minFallDistance.get()) {
            divePhase = DivePhase.STRIKE;
        }

        // If we overshot, climb again
        if (heightAbove < -5.0) {
            divePhase = DivePhase.CLIMB;
        }
    }

    private void doStrike(class_310 client) {
        double dist = client.field_1724.method_5739(target);

        // Switch to mace
        if (autoSwitchMace.enabled()) {
            int maceSlot = findItemInInventory(client.field_1724, class_1802.field_49814);
            if (maceSlot >= 0 && maceSlot < 9) {
                prevSlot = client.field_1724.method_31548().method_67532();
                client.field_1724.method_31548().method_61496(maceSlot);
            }
        }

        // Face target for attack
        faceTarget(client, target, 0.5f);

        // Attack when close enough with sufficient fall distance
        if (dist <= attackRange.get() && client.field_1724.field_6017 >= minFallDistance.get()) {
            if (actionReady(isGhost(client) ? 1 + random.nextInt(2) : 1, 0)) {
                CombatUtil.attack(client, target);
                hitThisDive = true;

                // Switch back to sword
                if (autoSwitchSword.enabled() && prevSlot >= 0 && prevSlot < 9) {
                    int swordSlot = findBestSwordSlot(client);
                    if (swordSlot >= 0 && swordSlot < 9) {
                        client.field_1724.method_31548().method_61496(swordSlot);
                    } else {
                        client.field_1724.method_31548().method_61496(prevSlot);
                    }
                }

                postHitWait = postHitDelay.get();
                divePhase = DivePhase.RECOVER;
            }
        }

        // If we missed the window, climb again
        if (dist > attackRange.get() * 1.5) {
            divePhase = DivePhase.CLIMB;
        }
    }

    private void doRecover(class_310 client) {
        // Let the player fall safely or boost up again
        if (client.field_1724.method_24828() || client.field_1724.field_6017 < 1.0f) {
            divePhase = DivePhase.CLIMB;
            hitThisDive = false;
        }
    }

    private void faceTarget(class_310 client, class_1297 target, float speedMul) {
        if (!silentRotate.enabled()) return;
        class_243 targetPos = target.method_5829().method_1005();
        float[] rots = CombatUtil.rotationsTo(client.field_1724, targetPos);

        rotations().setMaxStep(rotationSpeed.get().floatValue() * speedMul);

        if (isGhost(client)) {
            float ny = (random.nextFloat() - 0.5f) * 2.0f;
            float np = (random.nextFloat() - 0.5f) * 1.0f;
            rotations().rotateToSilent(rots[0] + ny, rots[1] + np, Math.max(2, (int)(distTo(client.field_1724, targetPos) * 0.5)));
            rotations().setServerRotation(rots[0], rots[1], Math.max(2, (int)(distTo(client.field_1724, targetPos) * 0.3)));
        } else {
            rotations().rotateToSilent(rots[0], rots[1], Math.max(1, (int)(distTo(client.field_1724, targetPos) * 0.3)));
        }
    }

    private void useBoostItem(class_310 client) {
        boolean used = false;

        if (boostMode.is("Firework") || boostMode.is("Both")) {
            int slot = findItemInInventory(client.field_1724, class_1802.field_8639);
            if (slot >= 0 && slot < 9) {
                client.field_1724.method_31548().method_61496(slot);
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                used = true;
            }
        }
        if (!used && (boostMode.is("Wind Charge") || boostMode.is("Both"))) {
            int slot = findItemInInventory(client.field_1724, class_1802.field_49098);
            if (slot >= 0 && slot < 9) {
                client.field_1724.method_31548().method_61496(slot);
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                used = true;
            }
        }
        if (!used && (boostMode.is("Pearl") || boostMode.is("Both"))) {
            int slot = findItemInInventory(client.field_1724, class_1802.field_8634);
            if (slot >= 0 && slot < 9) {
                client.field_1724.method_31548().method_61496(slot);
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
            }
        }
    }

    private void ensureElytraEquipped(class_310 client) {
        class_1799 chest = client.field_1724.method_6118(class_1304.field_6174);
        if (chest.method_31574(class_1802.field_8833)) return;

        int elytraSlot = findItemInInventory(client.field_1724, class_1802.field_8833);
        if (elytraSlot >= 0 && elytraSlot < 9) {
            client.field_1724.method_31548().method_61496(elytraSlot);
        }
    }

    private boolean shouldStartGliding(class_310 client) {
        if (client.field_1724.method_6128()) return false;
        if (client.field_1724.method_24828()) return false;
        if (client.field_1724.method_18798().field_1351 >= -0.2) return false;
        // Only start gliding when above target
        if (target != null && client.field_1724.method_23318() < target.method_23318() + 5.0) return false;
        return true;
    }

    private void startGliding(class_310 client) {
        client.field_1724.field_3944.method_52787(new class_2848(
            client.field_1724, class_2848.class_2849.field_12982
        ));
    }

    private class_1309 findTarget(class_310 client) {
        double range = targetRange.get();
        return client.field_1687.method_8390(class_1309.class, client.field_1724.method_5829().method_1014(range), entity -> {
            if (entity == client.field_1724 || !entity.method_5805()) return false;
            if (client.field_1724.method_5858(entity) > range * range) return false;
            // Only target entities below us (for dive bomb)
            if (entity.method_23318() > client.field_1724.method_23318() + 2.0) return false;
            return switch (targetMode.get()) {
                case "Players" -> entity instanceof class_1657;
                case "Hostiles" -> entity instanceof net.minecraft.class_1588;
                case "All" -> true;
                default -> false;
            };
        }).stream().min(Comparator.comparingDouble(client.field_1724::method_5739)).orElse(null);
    }

    private int findItemInInventory(class_746 player, net.minecraft.class_1792 item) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.method_31548().method_5438(slot).method_31574(item)) return slot;
        }
        // Search rest of inventory
        for (int slot = 9; slot < 36; slot++) {
            if (player.method_31548().method_5438(slot).method_31574(item)) return slot;
        }
        return -1;
    }

    private int findBestSwordSlot(class_310 client) {
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = client.field_1724.method_31548().method_5438(slot);
            if (stack.method_31574(class_1802.field_8091) || stack.method_31574(class_1802.field_8528)
                || stack.method_31574(class_1802.field_8371) || stack.method_31574(class_1802.field_8845)
                || stack.method_31574(class_1802.field_8802) || stack.method_31574(class_1802.field_22022)) return slot;
        }
        return -1;
    }

    private boolean isGhost(class_310 client) {
        return bypass.is("Ghost") || bypass.is("Grim");
    }

    private double distTo(class_746 player, class_243 pos) {
        return player.method_5707(pos);
    }

    @Override
    protected void onDisable() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && prevSlot >= 0 && prevSlot < 9) {
            client.field_1724.method_31548().method_61496(prevSlot);
        }
        target = null;
        boostTick = 0;
        postHitWait = 0;
        prevSlot = -1;
        hitThisDive = false;
        divePhase = DivePhase.CLIMB;
    }
}
