package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.minecraft.class_310;

public final class KeepSprint extends MovementModule {
    private final BooleanSetting cancelVelocity = setting(new BooleanSetting("Cancel Velocity", "Cancel knockback when sprinting.", true));
    private final DoubleSetting motionMultiplier = setting(new DoubleSetting("Motion Multiplier", "Keep sprint momentum multiplier.", 0.8, 0.0, 1.0));

    public KeepSprint() {
        super("KeepSprint", "Prevents sprint from being cancelled after attacking.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (!client.field_1724.method_5624() && client.field_1724.method_18798().method_37268() > 0.001) {
            client.field_1724.method_5728(true);
        }

        if (cancelVelocity.enabled() && client.field_1724.field_6235 > 0 && client.field_1724.method_5624()) {
            var vel = client.field_1724.method_18798();
            client.field_1724.method_18800(vel.field_1352 * motionMultiplier.get(), vel.field_1351, vel.field_1350 * motionMultiplier.get());
        }
    }
}
