package dev.falaris.client.module.modules.movement;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_746;

final class MovementUtil {
    private MovementUtil() {
    }

    static class_243 inputVelocity(class_746 player, double speed, boolean includeY, class_310 client) {
        double forward = client.field_1690.field_1894.method_1434() ? 1.0 : 0.0;
        forward -= client.field_1690.field_1881.method_1434() ? 1.0 : 0.0;
        double strafe = client.field_1690.field_1913.method_1434() ? 1.0 : 0.0;
        strafe -= client.field_1690.field_1849.method_1434() ? 1.0 : 0.0;

        double y = 0.0;
        if (includeY) {
            y += client.field_1690.field_1903.method_1434() ? speed : 0.0;
            y -= client.field_1690.field_1832.method_1434() ? speed : 0.0;
        }

        if (forward == 0.0 && strafe == 0.0) {
            return new class_243(0.0, y, 0.0);
        }

        double length = Math.sqrt(forward * forward + strafe * strafe);
        forward /= length;
        strafe /= length;

        double yaw = Math.toRadians(player.method_36454());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double x = (strafe * cos - forward * sin) * speed;
        double z = (forward * cos + strafe * sin) * speed;
        return new class_243(x, y, z);
    }

    static void setHorizontalSpeed(class_1297 entity, double speed, class_310 client) {
        if (!(entity instanceof class_746 player)) {
            return;
        }
        class_243 input = inputVelocity(player, speed, false, client);
        entity.method_18800(input.field_1352, entity.method_18798().field_1351, input.field_1350);
    }

    static int findItem(class_746 player, class_1792 item) {
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = player.method_31548().method_5438(slot);
            if (stack.method_31574(item)) {
                return slot;
            }
        }
        return -1;
    }

    static boolean selectSlot(class_746 player, int slot) {
        if (slot < 0 || slot > 8) {
            return false;
        }
        player.method_31548().method_61496(slot);
        return true;
    }

    static boolean interactBlock(class_310 client, class_2338 pos, class_2350 side, class_1268 hand) {
        if (client.field_1724 == null || client.field_1761 == null) {
            return false;
        }

        class_243 hit = class_243.method_24953(pos).method_1019(class_243.method_24954(side.method_62675()).method_1021(0.5));
        class_3965 result = new class_3965(hit, side, pos, false);
        client.field_1761.method_2896(client.field_1724, hand, result);
        client.field_1724.method_6104(hand);
        return true;
    }

    static float yawTo(class_243 from, class_243 to) {
        double diffX = to.field_1352 - from.field_1352;
        double diffZ = to.field_1350 - from.field_1350;
        return (float) class_3532.method_15338(Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0);
    }
}
