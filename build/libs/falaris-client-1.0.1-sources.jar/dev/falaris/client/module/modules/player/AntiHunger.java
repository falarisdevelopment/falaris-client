package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.minecraft.class_310;

public final class AntiHunger extends PlayerModule {
    private final BooleanSetting stopSprint = setting(new BooleanSetting("Stop Sprint", "Disable sprinting when hunger is low.", true));
    private final BooleanSetting stopJump = setting(new BooleanSetting("Stop Jump", "Release jump when hunger is low.", true));
    private final BooleanSetting stopSwimming = setting(new BooleanSetting("Stop Swimming", "Disable sprint-swimming when hunger is low.", true));
    private final DoubleSetting foodThreshold = setting(new DoubleSetting("Food Threshold", "Food level at or below which conservation starts.", 14.0, 1.0, 20.0));
    private final BooleanSetting onlySurvival = setting(new BooleanSetting("Only Survival", "Ignore creative and spectator modes.", true));

    public AntiHunger() {
        super("AntiHunger", "Reduces hunger-draining movement when food is low.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null || client.field_1761 == null) {
            return;
        }
        if (onlySurvival.enabled() && !client.field_1761.method_2920().method_8388()) {
            return;
        }
        if (client.field_1724.method_7344().method_7586() > foodThreshold.get()) {
            return;
        }

        if (stopSprint.enabled()) {
            client.field_1724.method_5728(false);
            client.field_1690.field_1867.method_23481(false);
        }
        if (stopJump.enabled()) {
            client.field_1690.field_1903.method_23481(false);
        }
        if (stopSwimming.enabled() && client.field_1724.method_5681()) {
            client.field_1724.method_5728(false);
        }
    }
}
