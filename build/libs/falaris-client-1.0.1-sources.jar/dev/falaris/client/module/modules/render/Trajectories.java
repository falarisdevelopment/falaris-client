package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1835;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class Trajectories extends RenderModule {
    private final IntegerSetting steps = setting(new IntegerSetting("Steps", "Maximum simulated ticks.", 80, 10, 200));
    private final DoubleSetting width = setting(new DoubleSetting("Width", "Marker size.", 0.055, 0.01, 0.2));
    private final BooleanSetting showImpact = setting(new BooleanSetting("Impact", "Show impact position.", true));

    public Trajectories() {
        super("Trajectories", "Renders predicted projectile paths for throwable and ranged items.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        class_1799 stack = client.field_1724.method_6047();
        Projectile projectile = projectile(stack.method_7909());
        if (projectile == null) {
            stack = client.field_1724.method_6079();
            projectile = projectile(stack.method_7909());
        }
        if (projectile == null) {
            return;
        }

        class_243 position = client.field_1724.method_33571();
        class_243 velocity = client.field_1724.method_5720().method_1029().method_1021(projectile.speed);
        RenderUtil.Color color = RenderUtil.Color.rgba(118, 156, 255, 210);

        for (int i = 0; i < steps.get(); i++) {
            class_243 next = position.method_1019(velocity);
            class_239 hit = client.field_1687.method_17742(new net.minecraft.class_3959(
                    position,
                    next,
                    net.minecraft.class_3959.class_3960.field_17558,
                    net.minecraft.class_3959.class_242.field_1348,
                    client.field_1724
            ));

            RenderUtil.drawBox(context, class_238.method_30048(position, width.get(), width.get(), width.get()), color);
            if (hit.method_17783() == class_239.class_240.field_1332) {
                if (showImpact.enabled()) {
                    class_3965 blockHit = (class_3965) hit;
                    RenderUtil.drawBlockBox(context, blockHit.method_17777(), RenderUtil.Color.rgba(255, 92, 122, 230));
                }
                break;
            }

            position = next;
            velocity = velocity.method_1021(projectile.drag).method_1031(0.0, -projectile.gravity, 0.0);
        }
    }

    private Projectile projectile(class_1792 item) {
        if (item instanceof class_1753) {
            return new Projectile(3.0, 0.99, 0.05);
        }
        if (item instanceof class_1764) {
            return new Projectile(3.15, 0.99, 0.05);
        }
        if (item instanceof class_1835) {
            return new Projectile(2.5, 0.99, 0.05);
        }
        if (item == class_1802.field_8634 || item == class_1802.field_8543 || item == class_1802.field_8803) {
            return new Projectile(1.5, 0.99, 0.03);
        }
        if (item == class_1802.field_8436 || item == class_1802.field_8150) {
            return new Projectile(0.9, 0.99, 0.05);
        }
        return null;
    }

    private record Projectile(double speed, double drag, double gravity) {
    }
}
