package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_12249;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public final class ReachVisualizer extends RenderModule {
    private final DoubleSetting reach = setting(new DoubleSetting("Reach", "Reach distance to visualize.", 3.0, 1.0, 6.0));
    private final BooleanSetting showCircle = setting(new BooleanSetting("Show Circle", "Draw reach circle on ground.", true));
    private final BooleanSetting showLine = setting(new BooleanSetting("Show Line", "Draw line from you to crosshair target.", true));
    private final IntegerSetting segments = setting(new IntegerSetting("Segments", "Circle smoothness.", 48, 12, 96));
    private final DoubleSetting colorR = setting(new DoubleSetting("Red", "Circle color red.", 0.0, 0.0, 1.0));
    private final DoubleSetting colorG = setting(new DoubleSetting("Green", "Circle color green.", 1.0, 0.0, 1.0));
    private final DoubleSetting colorB = setting(new DoubleSetting("Blue", "Circle color blue.", 0.8, 0.0, 1.0));
    private final DoubleSetting lineR = setting(new DoubleSetting("Line Red", "Line color red.", 1.0, 0.0, 1.0));
    private final DoubleSetting lineG = setting(new DoubleSetting("Line Green", "Line color green.", 0.3, 0.0, 1.0));
    private final DoubleSetting lineB = setting(new DoubleSetting("Line Blue", "Line color blue.", 0.3, 0.0, 1.0));

    public ReachVisualizer() {
        super("ReachVisualizer", "Shows a reach circle on the ground and a line to your crosshair target.");
    }

    @Override
    protected void onWorldRender(WorldRenderContext context) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        class_4587 matrices = context.matrices();
        class_4597 consumers = context.consumers();
        if (consumers == null) return;

        class_4184 camera = client.field_1773.method_19418();
        class_243 cam = camera.method_71156();
        float r = reach.get().floatValue();

        if (showCircle.enabled()) {
            drawCircle(context, client, cam, r);
        }

        if (showLine.enabled()) {
            drawTargetLine(context, client, cam);
        }
    }

    private void drawCircle(WorldRenderContext context, class_310 client, class_243 cam, float radius) {
        class_4588 buffer = context.consumers().method_73477(class_12249.method_76015());
        class_4587.class_4665 entry = context.matrices().method_23760();

        double px = client.field_1724.method_23317() - cam.field_1352;
        double py = client.field_1724.method_23318() - cam.field_1351;
        double pz = client.field_1724.method_23321() - cam.field_1350;

        int segs = segments.get();
        double r = radius;
        float cr = colorR.get().floatValue();
        float cg = colorG.get().floatValue();
        float cb = colorB.get().floatValue();

        for (int i = 0; i < segs; i++) {
            double a1 = Math.PI * 2 * i / segs;
            double a2 = Math.PI * 2 * (i + 1) / segs;

            double x1 = px + Math.cos(a1) * r;
            double z1 = pz + Math.sin(a1) * r;
            double x2 = px + Math.cos(a2) * r;
            double z2 = pz + Math.sin(a2) * r;

            buffer.method_56824(entry, (float) x1, (float) py, (float) z1)
                .method_22915(cr, cg, cb, 0.6f).method_60831(entry, 0, 1, 0).method_75298(1.0f);
            buffer.method_56824(entry, (float) x2, (float) py, (float) z2)
                .method_22915(cr, cg, cb, 0.6f).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        }
    }

    private void drawTargetLine(WorldRenderContext context, class_310 client, class_243 cam) {
        if (!(client.field_1765 instanceof class_3966 ehr)) return;

        class_4588 buffer = context.consumers().method_73477(class_12249.method_76015());
        class_4587.class_4665 entry = context.matrices().method_23760();

        class_243 start = client.field_1724.method_5836(1.0f).method_1020(cam);
        class_243 end = ehr.method_17782().method_5829().method_1005().method_1020(cam);

        float lr = lineR.get().floatValue();
        float lg = lineG.get().floatValue();
        float lb = lineB.get().floatValue();

        buffer.method_56824(entry, (float) start.field_1352, (float) start.field_1351, (float) start.field_1350)
            .method_22915(lr, lg, lb, 0.5f).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, (float) end.field_1352, (float) end.field_1351, (float) end.field_1350)
            .method_22915(lr, lg, lb, 0.3f).method_60831(entry, 0, 1, 0).method_75298(1.0f);
    }
}
