package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1536;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class AutoFish extends PlayerModule {
    private final BooleanSetting autoCast = setting(new BooleanSetting("Auto Cast", "Auto-cast rod after catching.", true));
    private final IntegerSetting castDelay = setting(new IntegerSetting("Cast Delay", "Ticks before recasting.", 5, 0, 20));
    private final BooleanSetting soundDetection = setting(new BooleanSetting("Sound Detection", "Reel in when bobber splash sound plays.", true));
    private final BooleanSetting visualDetection = setting(new BooleanSetting("Visual Detection", "Reel in when bobber goes under.", true));

    private int delayTicks;
    private boolean shouldReel;

    public AutoFish() {
        super("AutoFish", "Automatically catches and re-casts fishing rods.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        if (!isHoldingRod(client)) return;

        if (shouldReel) {
            client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
            shouldReel = false;
            delayTicks = 0;
            return;
        }

        if (autoCast.enabled() && client.field_1724.field_7513 == null && !client.field_1724.method_6115()) {
            delayTicks++;
            if (delayTicks >= castDelay.get()) {
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                delayTicks = 0;
            }
        }

        if (soundDetection.enabled() && client.field_1724.field_7513 != null) {
            // Listen for bobber splash sound
            var sound = client.method_1483();
            if (sound != null) {
                // Check fish hook state: when it goes under water, bobber changes state
                class_1536 bobber = client.field_1724.field_7513;
                // If the bobber is no longer visible or has a different velocity
                if (bobber != null && bobber.method_18798().method_1027() > 0.1 && bobber.method_31481()) {
                    // Bobber was pulled under
                }
            }
        }

        // Alternative: right-click when bobber entity disappears or changes state
        if (client.field_1724.field_7513 != null && client.field_1724.field_7513.method_31481()) {
            shouldReel = true;
        }
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        shouldReel = false;
        delayTicks = 0;
    }

    private boolean isHoldingRod(class_310 client) {
        return client.field_1724.method_6047().method_31574(class_1802.field_8378)
            || client.field_1724.method_6079().method_31574(class_1802.field_8378);
    }
}
