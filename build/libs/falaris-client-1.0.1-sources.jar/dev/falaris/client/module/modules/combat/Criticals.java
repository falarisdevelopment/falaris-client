package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_2828;
import net.minecraft.class_310;

public final class Criticals extends CombatModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Critical hit method.", "Jump", "Jump", "Packet", "MiniJump"));
    private final ModeSetting bypass = setting(new ModeSetting("Bypass", "Anticheat bypass.", "Vanilla", "Vanilla", "Vulcan", "Verus", "Grim", "Watchdog"));
    private final BooleanSetting onlyGround = setting(new BooleanSetting("Only Ground", "Only crit when standing on ground.", true));
    private final BooleanSetting checkDistance = setting(new BooleanSetting("Check Distance", "Only crit within 3 blocks of target.", false));

    private boolean wasAttacking;

    public Criticals() {
        super("Criticals", "Ensures every hit is a critical strike.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null) return;

        boolean attacking = client.field_1690.field_1886.method_1434();

        if (!attacking) {
            wasAttacking = false;
            return;
        }

        if (!client.field_1724.method_24828()) return;
        if (onlyGround.enabled() && !client.field_1724.method_24828()) return;

        if (attacking && !wasAttacking) {
            doCrit(client);
        }

        wasAttacking = attacking;
    }

    private void doCrit(class_310 client) {
        String b = bypass.get();

        if (mode.is("Jump")) {
            if (b.equals("Vulcan")) {
                client.field_1724.method_18800(client.field_1724.method_18798().field_1352, 0.25, client.field_1724.method_18798().field_1350);
            } else if (b.equals("Verus")) {
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(
                    client.field_1724.method_23317(), client.field_1724.method_23318() + 1.0E-6, client.field_1724.method_23321(),
                    false, client.field_1724.field_5976));
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(
                    client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321(),
                    false, client.field_1724.field_5976));
            } else if (b.equals("Grim")) {
                client.field_1724.method_6043();
            } else {
                client.field_1724.method_6043();
            }
        } else if (mode.is("Packet")) {
            if (b.equals("Grim")) {
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(
                    client.field_1724.method_23317(), client.field_1724.method_23318() + 0.0625, client.field_1724.method_23321(),
                    false, client.field_1724.field_5976));
            } else if (b.equals("Watchdog")) {
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(
                    client.field_1724.method_23317(), client.field_1724.method_23318() + 0.0625, client.field_1724.method_23321(),
                    false, client.field_1724.field_5976));
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(
                    client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321(),
                    false, client.field_1724.field_5976));
            } else {
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(
                    client.field_1724.method_23317(), client.field_1724.method_23318() + 0.0625, client.field_1724.method_23321(),
                    false, client.field_1724.field_5976));
                client.field_1724.field_3944.method_52787(new class_2828.class_2829(
                    client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321(),
                    false, client.field_1724.field_5976));
            }
        } else if (mode.is("MiniJump")) {
            client.field_1724.method_18800(client.field_1724.method_18798().field_1352, 0.1, client.field_1724.method_18798().field_1350);
        }
    }
}
