package dev.falaris.client.module.modules.movement;

import dev.falaris.client.event.EventPriority;
import dev.falaris.client.event.events.RenderWorldEvent;
import dev.falaris.client.module.modules.render.RenderUtil;
import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2846;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4184;

public final class PacketMine extends MovementModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Mining packet flow.", "Normal", "Normal", "Instant"));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum mining distance.", 5.0, 1.0, 6.0));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Face the mined block.", true));
    private final BooleanSetting showProgress = setting(new BooleanSetting("Show Progress", "Visual progress overlay on block.", true));

    private class_2338 miningPos;
    private class_2350 miningSide;
    private float progress;

    public PacketMine() {
        super("PacketMine", "Mines blocks by sending dig packets without animation.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        track(eventBus().subscribe(RenderWorldEvent.class, EventPriority.NORMAL, event -> onWorldRender(event.context())));
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        miningPos = null;
        miningSide = null;
        progress = 0;
    }

    private void onWorldRender(WorldRenderContext context) {
        if (miningPos == null || !showProgress.enabled()) return;
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_4184 camera = client.field_1773.method_19418();
        class_243 cam = camera.method_71156();
        class_238 box = new class_238(miningPos).method_989(-cam.field_1352, -cam.field_1351, -cam.field_1350);

        float pct = Math.min(1.0f, progress);
        int r = (int) (255 * (1 - pct));
        int g = (int) (255 * pct);
        int b = 80;
        int a = (int) (60 + 60 * pct);
        int fillA = (int) (50 * pct);

        var matrices = context.matrices();
        matrices.method_22903();
        var entry = matrices.method_23760();
        var consumers = context.consumers();
        if (consumers == null) { matrices.method_22909(); return; }
        var buffer = consumers.method_73477(net.minecraft.class_12249.method_76015());

        // Fill
        RenderUtil.drawBox(context, new class_238(miningPos), new RenderUtil.Color(r / 255f, g / 255f, b / 255f, fillA / 255f));
        // Outline
        drawBoxLines(buffer, entry, box, r, g, b, a);
        // Progress line at top
        double pw = box.method_17939() * pct;
        drawProgressBar(buffer, entry, box, r, g, b);

        matrices.method_22909();
    }

    private static void drawBoxLines(net.minecraft.class_4588 buffer, net.minecraft.class_4587.class_4665 entry, class_238 box, int r, int g, int b, int a) {
        int argb = (a << 24) | (r << 16) | (g << 8) | b;
        float x1 = (float) box.field_1323, y1 = (float) box.field_1322, z1 = (float) box.field_1321;
        float x2 = (float) box.field_1320, y2 = (float) box.field_1325, z2 = (float) box.field_1324;
        buffer.method_56824(entry, x1, y1, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y1, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y1, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y1, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y1, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x1, y1, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x1, y1, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x1, y1, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        // bottom
        buffer.method_56824(entry, x1, y2, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y2, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y2, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y2, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y2, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x1, y2, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x1, y2, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x1, y2, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        // pillars
        buffer.method_56824(entry, x1, y1, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x1, y2, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y1, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y2, z1).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y1, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x2, y2, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x1, y1, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, x1, y2, z2).method_39415(argb).method_60831(entry, 0, 1, 0).method_75298(1.0f);
    }

    private static void drawProgressBar(net.minecraft.class_4588 buffer, net.minecraft.class_4587.class_4665 entry, class_238 box, int r, int g, int b) {
        float pct = Math.min(1.0f, (float) (System.currentTimeMillis() % 2000) / 2000.0f); // animated
        float xMin = (float) box.field_1323, xMax = (float) box.field_1320;
        float y = (float) box.field_1325;
        float z = (float) box.field_1321;
        float xEnd = xMin + (xMax - xMin) * pct;
        int color = 0xFF000000 | (r << 16) | (g << 8) | b;
        buffer.method_56824(entry, xMin, y + 0.02f, z).method_39415(color).method_60831(entry, 0, 1, 0).method_75298(1.0f);
        buffer.method_56824(entry, xEnd, y + 0.02f, z).method_39415(color).method_60831(entry, 0, 1, 0).method_75298(1.0f);
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1724.field_3944 == null) return;

        if (miningPos != null) {
            if (client.field_1724.method_5707(class_243.method_24953(miningPos)) > range.get() * range.get() || client.field_1687.method_8320(miningPos).method_26215()) {
                miningPos = null;
                miningSide = null;
                progress = 0;
            } else {
                if (rotate.enabled()) {
                    float yaw = MovementUtil.yawTo(client.field_1724.method_33571(), class_243.method_24953(miningPos));
                    rotations().rotateTo(yaw, client.field_1724.method_36455(), 2);
                }
                progress += client.field_1687.method_8320(miningPos).method_26165(client.field_1724, client.field_1687, miningPos);
                if (progress >= 1.0f) {
                    send(client, class_2846.class_2847.field_12973, miningPos, miningSide);
                    client.field_1724.method_6104(class_1268.field_5808);
                    miningPos = null;
                    miningSide = null;
                    progress = 0;
                }
                return;
            }
        }

        if (client.field_1690.field_1886.method_1434() && client.field_1765 != null && client.field_1765.method_17783() == class_239.class_240.field_1332) {
            class_3965 hit = (class_3965) client.field_1765;
            class_2338 pos = hit.method_17777();
            class_2350 side = hit.method_17780();

            if (client.field_1724.method_5707(class_243.method_24953(pos)) <= range.get() * range.get() && !client.field_1687.method_8320(pos).method_26215()) {
                miningPos = pos;
                miningSide = side;
                progress = 0;
                send(client, class_2846.class_2847.field_12968, miningPos, miningSide);
                client.field_1724.method_6104(class_1268.field_5808);
                if (mode.is("Instant")) {
                    send(client, class_2846.class_2847.field_12973, miningPos, miningSide);
                    miningPos = null;
                }
            }
        }
    }

    private void send(class_310 client, class_2846.class_2847 action, class_2338 pos, class_2350 side) {
        client.field_1724.field_3944.method_52787(new class_2846(action, pos, side));
    }
}
