package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2846;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class PacketMine extends MovementModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Mining packet flow.", "Normal", "Normal", "Instant"));
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Maximum mining distance.", 5.0, 1.0, 6.0));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Face the mined block.", true));

    private class_2338 miningPos;
    private class_2350 miningSide;
    private float progress;

    public PacketMine() {
        super("PacketMine", "Mines blocks by sending dig packets without animation.");
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        miningPos = null;
        miningSide = null;
        progress = 0;
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || client.field_1724.field_3944 == null) {
            return;
        }

        if (miningPos != null) {
            if (client.field_1724.method_5707(class_243.method_24953(miningPos)) > range.get() * range.get() || client.field_1687.method_8320(miningPos).method_26215()) {
                miningPos = null;
                miningSide = null;
                progress = 0;
            } else {
                if (rotate.enabled()) {
                    float yaw = MovementUtil.yawTo(client.field_1724.method_33571(), class_243.method_24953(miningPos));
                    rotations().rotateTo(yaw, client.field_1724.method_36455(), 2);
                }

                progress += client.field_1687.method_8320(miningPos).method_26165(client.field_1724, client.field_1687, miningPos);

                if (progress >= 1.0f) {
                    send(client, class_2846.class_2847.field_12973, miningPos, miningSide);
                    client.field_1724.method_6104(class_1268.field_5808);
                    miningPos = null;
                    miningSide = null;
                    progress = 0;
                }
                return;
            }
        }

        if (client.field_1690.field_1886.method_1434() && client.field_1765 != null && client.field_1765.method_17783() == class_239.class_240.field_1332) {
            class_3965 hit = (class_3965) client.field_1765;
            class_2338 pos = hit.method_17777();
            class_2350 side = hit.method_17780();

            if (client.field_1724.method_5707(class_243.method_24953(pos)) <= range.get() * range.get() && !client.field_1687.method_8320(pos).method_26215()) {
                miningPos = pos;
                miningSide = side;
                progress = 0;

                send(client, class_2846.class_2847.field_12968, miningPos, miningSide);
                client.field_1724.method_6104(class_1268.field_5808);

                if (mode.is("Instant")) {
                    send(client, class_2846.class_2847.field_12973, miningPos, miningSide);
                    miningPos = null;
                }
            }
        }
    }

    private void send(class_310 client, class_2846.class_2847 action, class_2338 pos, class_2350 side) {
        client.field_1724.field_3944.method_52787(new class_2846(action, pos, side));
    }
}
