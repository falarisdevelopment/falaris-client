package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1304;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class ElytraSwapper extends MiscModule {
    private final BooleanSetting autoEquipElytra = setting(new BooleanSetting("Auto Equip Elytra", "Swap chestplate to elytra when airborne.", true));
    private final BooleanSetting autoSwapBack = setting(new BooleanSetting("Auto Swap Back", "Swap elytra back to chestplate on ground.", true));
    private final DoubleSetting minFallDistance = setting(new DoubleSetting("Min Fall Distance", "Min fall distance before swap.", 3.0, 0.0, 10.0));
    private final IntegerSetting swapCooldown = setting(new IntegerSetting("Swap Cooldown", "Ticks between swaps.", 10, 1, 40));
    private final BooleanSetting maceMode = setting(new BooleanSetting("Mace Mode", "Swap to mace after elytra equip.", false));
    private final BooleanSetting dropChest = setting(new BooleanSetting("Drop Chest", "Drop chestplate when swapping.", false));
    private final BooleanSetting autoGlide = setting(new BooleanSetting("Auto Glide", "Auto-start gliding when falling.", true));
    private final BooleanSetting targetSwap = setting(new BooleanSetting("Target Swap", "Only swap when target is nearby.", false));
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Range for target detection.", 15.0, 5.0, 50.0));

    private int tickCounter;
    private boolean hasElytra;
    private int chestplateSlot = -1;

    public ElytraSwapper() {
        super("ElytraSwapper", "Auto-swaps between elytra and chestplate for elytra combat.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        tickCounter = 0;
        hasElytra = false;
        chestplateSlot = -1;
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null) return;
        tickCounter++;
        if (tickCounter < swapCooldown.get()) return;

        boolean hasChestplate = client.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);

        boolean shouldEquip = autoEquipElytra.enabled() && shouldUseElytra(client);
        boolean shouldSwapBack = autoSwapBack.enabled() && !shouldUseElytra(client) && hasElytra;

        if (targetSwap.enabled()) {
            boolean targetNear = client.field_1687 != null && client.field_1687.method_18456().stream()
                .anyMatch(p -> p != client.field_1724 && !p.method_29504() && client.field_1724.method_5739(p) < targetRange.get());
            if (!targetNear) {
                shouldEquip = false;
                shouldSwapBack = true;
            }
        }

        if (shouldEquip && !hasChestplate && chestplateSlot == -1) {
            for (int slot = 9; slot < 36; slot++) {
                if (client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8058) ||
                    client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_22028) ||
                    client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8873) ||
                    client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8523) ||
                    client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8678) ||
                    client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8577)) {
                    chestplateSlot = slot;
                    break;
                }
            }
            if (chestplateSlot == -1) chestplateSlot = -2;
        }

        if (shouldEquip && !hasChestplate) {
            int elytraSlot = findElytraSlot(client);
            if (elytraSlot >= 0) {
                equipFromSlot(client, elytraSlot);
                hasElytra = true;
                tickCounter = 0;
            }
        }

        if (shouldSwapBack && hasChestplate) {
            if (chestplateSlot >= 0 && chestplateSlot < 36) {
                equipFromSlot(client, chestplateSlot);
                hasElytra = false;
                tickCounter = 0;
            } else {
                int chestSlot = findChestSlot(client);
                if (chestSlot >= 0) {
                    equipFromSlot(client, chestSlot);
                    hasElytra = false;
                    tickCounter = 0;
                }
            }
        }

        if (autoGlide.enabled() && hasElytra && !client.field_1724.method_24828() && !client.field_1724.method_6128()) {
            client.field_1724.field_3944.method_52787(new net.minecraft.class_2848(
                client.field_1724, net.minecraft.class_2848.class_2849.field_12982
            ));
        }

        if (maceMode.enabled() && hasElytra && client.field_1724.method_6128() && client.field_1724.field_6017 > minFallDistance.get()) {
            int maceSlot = dev.falaris.client.module.modules.combat.CombatUtil.findItem(client.field_1724, class_1802.field_49814);
            if (maceSlot >= 0 && maceSlot < 9) {
                client.field_1724.method_31548().method_61496(maceSlot);
            }
        }
    }

    private boolean shouldUseElytra(class_310 client) {
        return !client.field_1724.method_24828() && client.field_1724.field_6017 > minFallDistance.get();
    }

    private int findElytraSlot(class_310 client) {
        for (int slot = 0; slot < 36; slot++) {
            if (client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8833)) return slot;
        }
        return -1;
    }

    private int findChestSlot(class_310 client) {
        for (int slot = 9; slot < 36; slot++) {
            var stack = client.field_1724.method_31548().method_5438(slot);
            if (stack.method_31574(class_1802.field_8058) || stack.method_31574(class_1802.field_22028) ||
                stack.method_31574(class_1802.field_8873) || stack.method_31574(class_1802.field_8523) ||
                stack.method_31574(class_1802.field_8678) || stack.method_31574(class_1802.field_8577)) return slot;
        }
        return -1;
    }

    private void equipFromSlot(class_310 client, int slot) {
        if (slot >= 0 && slot < 9) {
            client.field_1724.method_31548().method_61496(slot);
            client.field_1761.method_2919(client.field_1724, net.minecraft.class_1268.field_5808);
        } else if (slot >= 9 && slot < 36) {
            int prev = client.field_1724.method_31548().method_67532();
            client.field_1724.method_31548().method_61496(slot);
            client.field_1761.method_2919(client.field_1724, net.minecraft.class_1268.field_5808);
            client.field_1724.method_31548().method_61496(prev);
        }
    }
}
