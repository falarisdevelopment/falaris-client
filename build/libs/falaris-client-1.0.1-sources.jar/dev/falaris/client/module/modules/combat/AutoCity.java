package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Optional;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public final class AutoCity extends CombatModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Mining range.", 4.5, 1.0, 6.0));
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Target detection range.", 6.0, 1.0, 12.0));
    private final BooleanSetting autoSwitch = setting(new BooleanSetting("Auto Switch", "Auto-switch to pickaxe.", true));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Face blocks being mined.", true));
    private final BooleanSetting toggleAfterCity = setting(new BooleanSetting("Toggle After City", "Disable after breaking a surround block.", false));
    private final ModeSetting targetMode = setting(new ModeSetting("Target Mode", "Which side to mine.", "Nearest", "Nearest", "Target", "Both"));
    private final IntegerSetting breakDelay = setting(new IntegerSetting("Break Delay", "Ticks between block attempts.", 3, 1, 10));

    private int tickCounter;
    private final Random random = new Random();

    public AutoCity() {
        super("AutoCity", "Mines target's surround blocks to enable crystal hits.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        tickCounter++;
        if (tickCounter < breakDelay.get() + random.nextInt(2)) return;
        tickCounter = 0;

        class_1309 target = CombatUtil.bestLivingTarget(client, targetRange.get(), true, true, false, false, "Distance").orElse(null);
        if (target == null) return;

        class_2338 targetFeet = target.method_24515();
        class_2338 minePos = null;

        if (targetMode.is("Nearest") || targetMode.is("Both")) {
            minePos = findNearestSurround(client, targetFeet);
        }
        if (minePos == null && (targetMode.is("Target") || targetMode.is("Both"))) {
            minePos = findSurroundBlockTowards(client, targetFeet);
        }
        if (minePos == null) return;

        if (autoSwitch.enabled()) {
            int pickSlot = findPickaxe(client);
            if (pickSlot >= 0) {
                client.field_1724.method_31548().method_61496(pickSlot);
            }
        }

        if (rotate.enabled()) {
            class_243 targetPos = class_243.method_24953(minePos);
            float[] rots = CombatUtil.rotationsTo(client.field_1724, targetPos);
            rotations().setMaxStep(20.0f);
            rotations().rotateTo(rots[0], rots[1], 2);
        }

        for (class_2350 dir : class_2350.values()) {
            class_2338 neighbor = minePos.method_10093(dir);
            if (!client.field_1687.method_8320(neighbor).method_26215()) {
                class_243 hit = class_243.method_24953(neighbor).method_1019(class_243.method_24954(dir.method_10153().method_62675()).method_1021(0.5));
                client.field_1761.method_2910(minePos, dir);
                client.field_1724.method_6104(class_1268.field_5808);
                break;
            }
        }

        if (toggleAfterCity.enabled() && isSurroundBlock(client, minePos)) {
            setEnabled(false);
        }
    }

    private class_2338 findNearestSurround(class_310 client, class_2338 feet) {
        class_2338 nearest = null;
        double nearestDist = Double.MAX_VALUE;
        for (class_2338 pos : new class_2338[]{feet.method_10095(), feet.method_10072(), feet.method_10078(), feet.method_10067(),
                feet.method_10095().method_10078(), feet.method_10095().method_10067(), feet.method_10072().method_10078(), feet.method_10072().method_10067()}) {
            if (!isSurroundBlock(client, pos)) continue;
            double dist = client.field_1724.method_5707(class_243.method_24953(pos));
            if (dist > range.get() * range.get()) continue;
            if (dist < nearestDist) {
                nearestDist = dist;
                nearest = pos;
            }
        }
        return nearest;
    }

    private class_2338 findSurroundBlockTowards(class_310 client, class_2338 targetFeet) {
        class_2338 playerFeet = client.field_1724.method_24515();
        class_2350 towards = class_2350.method_10147(targetFeet.method_10263() - playerFeet.method_10263(), 0, targetFeet.method_10260() - playerFeet.method_10260());
        class_2338 check = targetFeet.method_10093(towards);
        if (isSurroundBlock(client, check) && client.field_1724.method_5707(class_243.method_24953(check)) <= range.get() * range.get()) {
            return check;
        }
        return null;
    }

    private boolean isSurroundBlock(class_310 client, class_2338 pos) {
        if (client.field_1687 == null) return false;
        class_2680 state = client.field_1687.method_8320(pos);
        return state.method_27852(class_2246.field_10540) || state.method_27852(class_2246.field_10471) || state.method_27852(class_2246.field_9987)
                || state.method_27852(class_2246.field_22423) || state.method_27852(class_2246.field_22108);
    }

    private int findPickaxe(class_310 client) {
        for (int i = 0; i < 9; i++) {
            var stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(class_1802.field_22024) || stack.method_31574(class_1802.field_8377)
                    || stack.method_31574(class_1802.field_8403)) {
                return i;
            }
        }
        return -1;
    }
}
