package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class BreachSwap extends CombatModule {
    private final DoubleSetting range = setting(new DoubleSetting("Range", "Max sword hit range for trigger.", 3.5, 1.0, 6.0));
    private final IntegerSetting cooldown = setting(new IntegerSetting("Cooldown", "Ticks between swaps.", 20, 5, 60));
    private final BooleanSetting preferBreach = setting(new BooleanSetting("Prefer Breach", "Prefer mace with Breach enchant.", true));
    private final BooleanSetting preferDensity = setting(new BooleanSetting("Prefer Density", "Prefer mace with Density enchant.", true));
    private final BooleanSetting autoSlam = setting(new BooleanSetting("Auto Slam", "Attack with mace after swap.", true));
    private final BooleanSetting onlyPlayers = setting(new BooleanSetting("Only Players", "Only target players.", true));
    private final DoubleSetting chance = setting(new DoubleSetting("Chance", "Chance to swap per hit (0-1).", 0.75, 0.1, 1.0));

    private int tickCounter;

    public BreachSwap() {
        super("BreachSwap", "Auto-swaps to breach mace after landing a sword hit. Prestige-style.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        tickCounter = 0;
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        tickCounter++;
        if (tickCounter < cooldown.get()) return;

        if (!client.field_1690.field_1886.method_1434()) return;

        var target = client.field_1765;
        if (target == null) return;

        if (target.method_17783() != net.minecraft.class_239.class_240.field_1331) return;
        var entity = ((net.minecraft.class_3966) target).method_17782();
        if (!(entity instanceof class_1309 living) || !living.method_5805()) return;
        if (onlyPlayers.enabled() && !(entity instanceof net.minecraft.class_1657)) return;
        if (client.field_1724.method_5739(living) > range.get()) return;

        if (java.util.concurrent.ThreadLocalRandom.current().nextDouble() > chance.get()) return;

        boolean holdingSword = isSword(client.field_1724.method_6047().method_7909());
        if (!holdingSword) return;

        int maceSlot = findBestMace(client);
        if (maceSlot == -1 || maceSlot >= 9) return;

        client.field_1724.method_31548().method_61496(maceSlot);
        tickCounter = 0;

        if (autoSlam.enabled() && client.field_1724.field_6017 > 2.0f) {
            CombatUtil.attack(client, living);
        }
    }

    private int findBestMace(class_310 client) {
        int bestSlot = -1;
        int bestScore = -1;
        for (int slot = 0; slot < 36; slot++) {
            var stack = client.field_1724.method_31548().method_5438(slot);
            if (!stack.method_31574(class_1802.field_49814)) continue;
            int score = slot < 9 ? 3 : 0;
            var ench = stack.method_58694(net.minecraft.class_9334.field_49633);
            if (ench != null) {
                String s = ench.toString().toLowerCase();
                if (s.contains("breach") && preferBreach.enabled()) score += 2;
                if (s.contains("density") && preferDensity.enabled()) score += 2;
            }
            if (score > bestScore) {
                bestScore = score;
                bestSlot = slot;
            }
        }
        return bestSlot;
    }

    private boolean isSword(net.minecraft.class_1792 item) {
        return item == class_1802.field_8091 || item == class_1802.field_8528
            || item == class_1802.field_8371 || item == class_1802.field_8845
            || item == class_1802.field_8802 || item == class_1802.field_22022;
    }
}
