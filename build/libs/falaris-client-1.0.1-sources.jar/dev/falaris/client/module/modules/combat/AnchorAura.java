package dev.falaris.client.module.modules.combat;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.ArrayList;
import java.util.List;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4969;

public final class AnchorAura extends CombatModule {
    private final DoubleSetting targetRange = setting(new DoubleSetting("Target Range", "Maximum target distance.", 6.0, 1.0, 10.0));
    private final DoubleSetting actionRange = setting(new DoubleSetting("Action Range", "Maximum anchor interaction distance.", 3.0, 1.0, 4.0));
    private final DoubleSetting minDamage = setting(new DoubleSetting("Min Damage", "Minimum estimated target damage.", 5.0, 1.0, 20.0));
    private final DoubleSetting maxSelfDamage = setting(new DoubleSetting("Max Self Damage", "Maximum estimated self damage.", 8.0, 1.0, 20.0));
    private final DoubleSetting rotationSpeed = setting(new DoubleSetting("Rotation Speed", "Maximum rotation step per tick.", 18.0, 1.0, 60.0));
    private final IntegerSetting actionJitter = setting(new IntegerSetting("Action Jitter", "Random extra ticks between anchor actions.", 2, 0, 10));
    private final ModeSetting priority = setting(new ModeSetting("Priority", "Target sorting mode.", "Distance", "Distance", "Health", "Angle"));
    private final BooleanSetting placeAnchors = setting(new BooleanSetting("Place Anchors", "Place anchors near targets when none are available.", true));
    private final BooleanSetting chargeAnchors = setting(new BooleanSetting("Charge Anchors", "Charge anchors with glowstone.", true));
    private final BooleanSetting detonateAnchors = setting(new BooleanSetting("Detonate Anchors", "Use charged anchors.", true));
    private final BooleanSetting rotate = setting(new BooleanSetting("Rotate", "Face anchor actions.", true));
    private final BooleanSetting throughWalls = setting(new BooleanSetting("Through Walls", "Allow targets without line of sight.", false));
    private final BooleanSetting autoSafeAnchor = setting(new BooleanSetting("Auto Safe Anchor", "Only detonate when self damage is below threshold.", true));
    private final DoubleSetting safeAnchorMaxSelf = setting(new DoubleSetting("Safe Max Self", "Max safe self damage for auto-safe mode.", 6.0, 1.0, 16.0));
    private final ModeSetting anchorMode = setting(new ModeSetting("Anchor Mode", "Single or double anchor.", "Single", "Single", "Double"));

    private int phaseTick = 0;

    public AnchorAura() {
        super("AnchorAura", "Places, charges, and uses respawn anchors near selected targets. Double-anchor mode.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        phaseTick++;

        class_1309 target = CombatUtil.bestLivingTarget(client, targetRange.get(), true, true, false, throughWalls.enabled(), priority.get()).orElse(null);
        if (target == null) return;

        if (anchorMode.is("Double")) {
            tickDoubleAnchor(client, target);
            return;
        }

        tickSingleAnchor(client, target);
    }

    private void tickSingleAnchor(class_310 client, class_1309 target) {
        if (detonateAnchors.enabled()) {
            Optional<class_2338> charged = findChargedAnchorNearTarget(client, target);
            if (charged.isPresent()) {
                class_2338 pos = charged.get();
                class_243 center = class_243.method_24953(pos);
                double selfDmg = estimatedDamage(class_243.method_24953(client.field_1724.method_24515()), center);
                if (!autoSafeAnchor.enabled() || selfDmg <= safeAnchorMaxSelf.get()) {
                    if (rotate.enabled()) {
                        CombatUtil.face(rotations(), client.field_1724, center, rotationSpeed.get());
                    }
                    if (actionReady(1, actionJitter.get())) {
                        int heldSlot = client.field_1724.method_31548().method_67532();
                        int nonGlowstone = findNonGlowstoneSlot(client);
                        if (nonGlowstone >= 0) {
                            CombatUtil.selectHotbarSlot(client.field_1724, nonGlowstone);
                        }
                        CombatUtil.interactBlock(client, pos, class_2350.field_11036);
                        CombatUtil.selectHotbarSlot(client.field_1724, heldSlot);
                        return;
                    }
                }
            }
        }

        Optional<class_2338> existing = findExistingUnchargedAnchor(client, target);
        if (existing.isPresent() && chargeAnchors.enabled()) {
            chargeAnchor(client, existing.get());
            return;
        }

        if (placeAnchors.enabled()) {
            placeAnchor(client, target);
        }
    }

    private void tickDoubleAnchor(class_310 client, class_1309 target) {
        List<class_2338> charged = findChargedAnchorsNearTargetList(client, target);
        if (charged.size() >= 2) {
            detonateAnchorsList(client, charged);
            return;
        }

        List<class_2338> uncharged = findUnchargedAnchorsNearTargetList(client, target);
        int needed = 2 - charged.size();
        int charged_count = chargeAnchorsList(client, uncharged, needed);

        if (charged.size() + charged_count >= 2) {
            List<class_2338> allCharged = findChargedAnchorsNearTargetList(client, target);
            detonateAnchorsList(client, allCharged);
            return;
        }

        int toPlace = 2 - (charged.size() + charged_count);
        if (placeAnchors.enabled()) {
            placeAnchorsCount(client, target, toPlace);
        }
    }

    private Optional<class_2338> findChargedAnchorNearTarget(class_310 client, class_1309 target) {
        int radius = (int) Math.ceil(actionRange.get());
        class_2338 best = null;
        double bestDamage = -1;

        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 3, radius)) {
            class_2680 state = client.field_1687.method_8320(pos);
            if (!state.method_27852(class_2246.field_23152)) continue;
            int charges = state.method_11654(class_4969.field_23153);
            if (charges <= 0) continue;
            class_243 center = class_243.method_24953(pos);
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
            double dmg = estimatedDamage(targetPos, center);
            if (dmg >= minDamage.get() && dmg > bestDamage) {
                best = pos.method_10062();
                bestDamage = dmg;
            }
        }
        return Optional.ofNullable(best);
    }

    private List<class_2338> findChargedAnchorsNearTargetList(class_310 client, class_1309 target) {
        List<class_2338> list = new ArrayList<>();
        int radius = (int) Math.ceil(actionRange.get());
        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 3, radius)) {
            class_2680 state = client.field_1687.method_8320(pos);
            if (!state.method_27852(class_2246.field_23152)) continue;
            int charges = state.method_11654(class_4969.field_23153);
            if (charges <= 0) continue;
            class_243 center = class_243.method_24953(pos);
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
            double dmg = estimatedDamage(targetPos, center);
            if (dmg < minDamage.get()) continue;
            if (autoSafeAnchor.enabled()) {
                double selfDmg = estimatedDamage(class_243.method_24953(client.field_1724.method_24515()), center);
                if (selfDmg > safeAnchorMaxSelf.get()) continue;
            }
            list.add(pos.method_10062());
        }
        return list;
    }

    private List<class_2338> findUnchargedAnchorsNearTargetList(class_310 client, class_1309 target) {
        List<class_2338> list = new ArrayList<>();
        int radius = (int) Math.ceil(actionRange.get());
        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 3, radius)) {
            class_2680 state = client.field_1687.method_8320(pos);
            if (!state.method_27852(class_2246.field_23152)) continue;
            int charges = state.method_11654(class_4969.field_23153);
            if (charges >= 4) continue;
            class_243 center = class_243.method_24953(pos);
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
            double dmg = estimatedDamage(targetPos, center);
            if (dmg < minDamage.get()) continue;
            list.add(pos.method_10062());
        }
        return list;
    }

    private void detonateAnchorsList(class_310 client, List<class_2338> anchors) {
        for (class_2338 pos : anchors) {
            class_243 center = class_243.method_24953(pos);
            if (rotate.enabled()) {
                CombatUtil.face(rotations(), client.field_1724, center, rotationSpeed.get());
            }
            if (actionReady(1, actionJitter.get())) {
                int heldSlot = client.field_1724.method_31548().method_67532();
                int nonGlowstone = findNonGlowstoneSlot(client);
                if (nonGlowstone >= 0) {
                    CombatUtil.selectHotbarSlot(client.field_1724, nonGlowstone);
                }
                CombatUtil.interactBlock(client, pos, class_2350.field_11036);
                CombatUtil.selectHotbarSlot(client.field_1724, heldSlot);
            }
        }
    }

    private int chargeAnchorsList(class_310 client, List<class_2338> uncharged, int needed) {
        int charged = 0;
        int glowstoneSlot = CombatUtil.findItem(client.field_1724, class_1802.field_8801);
        if (glowstoneSlot == -1) return 0;

        for (class_2338 pos : uncharged) {
            if (charged >= needed) break;
            class_243 center = class_243.method_24953(pos);
            if (rotate.enabled()) {
                CombatUtil.face(rotations(), client.field_1724, center, rotationSpeed.get());
            }
            if (actionReady(2, actionJitter.get())) {
                CombatUtil.selectHotbarSlot(client.field_1724, glowstoneSlot);
                CombatUtil.interactBlock(client, pos, class_2350.field_11036);
                charged++;
            }
        }
        return charged;
    }

    private void placeAnchorsCount(class_310 client, class_1309 target, int count) {
        int anchorSlot = CombatUtil.findItem(client.field_1724, class_1802.field_23141);
        if (anchorSlot == -1) return;

        int radius = (int) Math.ceil(actionRange.get());
        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 2, radius)) {
            if (count <= 0) break;
            if (!client.field_1687.method_8320(pos).method_26215()) continue;
            if (client.field_1687.method_8320(pos.method_10074()).method_26215()) continue;
            class_243 center = class_243.method_24953(pos);
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
            if (estimatedDamage(targetPos, center) < minDamage.get()) continue;
            if (autoSafeAnchor.enabled()) {
                double selfDmg = estimatedDamage(class_243.method_24953(client.field_1724.method_24515()), center);
                if (selfDmg > safeAnchorMaxSelf.get()) continue;
            }
            if (rotate.enabled()) {
                CombatUtil.face(rotations(), client.field_1724, center, rotationSpeed.get());
            }
            if (actionReady(2, actionJitter.get())) {
                CombatUtil.selectHotbarSlot(client.field_1724, anchorSlot);
                CombatUtil.interactBlock(client, pos, class_2350.field_11036);
                count--;
            }
        }
    }

    // Existing methods kept for backward compatibility
    private void chargeAnchor(class_310 client, class_2338 pos) {
        if (rotate.enabled()) {
            CombatUtil.face(rotations(), client.field_1724, class_243.method_24953(pos), rotationSpeed.get());
        }
        int slot = CombatUtil.findItem(client.field_1724, class_1802.field_8801);
        if (slot == -1) return;
        if (actionReady(2, actionJitter.get())) {
            CombatUtil.selectHotbarSlot(client.field_1724, slot);
            CombatUtil.interactBlock(client, pos, class_2350.field_11036);
        }
    }

    private void placeAnchor(class_310 client, class_1309 target) {
        int slot = CombatUtil.findItem(client.field_1724, class_1802.field_23141);
        if (slot == -1) return;

        Optional<class_2338> placePos = findBestAnchorPlacement(client, target);
        if (placePos.isEmpty()) return;

        class_2338 pos = placePos.get();
        if (rotate.enabled()) {
            CombatUtil.face(rotations(), client.field_1724, class_243.method_24953(pos), rotationSpeed.get());
        }

        if (actionReady(3, actionJitter.get())) {
            CombatUtil.selectHotbarSlot(client.field_1724, slot);
            CombatUtil.interactBlock(client, pos.method_10074(), class_2350.field_11036);
        }
    }

    private Optional<class_2338> findExistingUnchargedAnchor(class_310 client, class_1309 target) {
        int radius = (int) Math.ceil(actionRange.get());
        class_2338 best = null;
        double bestDist = Double.MAX_VALUE;

        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 3, radius)) {
            class_243 center = class_243.method_24953(pos);
            class_2680 state = client.field_1687.method_8320(pos);
            if (!state.method_27852(class_2246.field_23152)) continue;
            int charges = state.method_11654(class_4969.field_23153);
            if (charges >= 4) continue;
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            double dist = client.field_1724.method_5707(center);
            if (dist < bestDist) {
                best = pos.method_10062();
                bestDist = dist;
            }
        }
        return Optional.ofNullable(best);
    }

    private Optional<class_2338> findBestAnchorPlacement(class_310 client, class_1309 target) {
        int radius = (int) Math.ceil(actionRange.get());
        class_2338 best = null;
        double bestDistance = Double.MAX_VALUE;

        for (class_2338 pos : class_2338.method_25996(target.method_24515(), radius, 2, radius)) {
            class_243 center = class_243.method_24953(pos);
            if (!client.field_1687.method_8320(pos).method_26215()) continue;
            if (client.field_1687.method_8320(pos.method_10074()).method_26215()) continue;
            if (client.field_1724.method_5707(center) > actionRange.get() * actionRange.get()) continue;
            if (estimatedDamage(new class_243(target.method_23317(), target.method_23318(), target.method_23321()), center) < minDamage.get()) continue;
            double selfDmg = estimatedDamage(new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321()), center);
            if (autoSafeAnchor.enabled() && selfDmg > safeAnchorMaxSelf.get()) continue;
            if (selfDmg > maxSelfDamage.get()) continue;

            double distance = target.method_5707(center);
            if (distance < bestDistance) {
                best = pos.method_10062();
                bestDistance = distance;
            }
        }
        return Optional.ofNullable(best);
    }

    private double estimatedDamage(class_243 target, class_243 anchor) {
        double distance = target.method_1022(anchor);
        return Math.max(0.0, 10.0 - distance * 1.8);
    }

    private int findNonGlowstoneSlot(class_310 client) {
        for (int slot = 0; slot < 9; slot++) {
            if (!client.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8801)) return slot;
        }
        return -1;
    }
}
