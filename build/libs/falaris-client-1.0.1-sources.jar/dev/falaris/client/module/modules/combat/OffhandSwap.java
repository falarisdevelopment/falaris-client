package dev.falaris.client.module.modules.combat;

import dev.falaris.client.module.modules.player.InventoryUtil;
import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Random;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class OffhandSwap extends CombatModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Swap strategy.", "Crystal", "Crystal", "Totem", "Auto"));
    private final BooleanSetting autoBack = setting(new BooleanSetting("Auto Back", "Swap back to previous item after burst.", true));
    private final IntegerSetting minDelay = setting(new IntegerSetting("Min Delay", "Min ticks between swaps.", 2, 1, 10));
    private final IntegerSetting maxDelay = setting(new IntegerSetting("Max Delay", "Max ticks between swaps.", 5, 1, 20));

    private final Random random = new Random();
    private int tickCounter;
    private int prevSlot;
    private boolean swapped;

    public OffhandSwap() {
        super("OffhandSwap", "Auto-swaps between totem and crystal in offhand.");
    }

    @Override
    protected void onCombatTick(class_310 client) {
        if (client.field_1724 == null) return;
        tickCounter++;

        boolean hasCrystal = false;
        boolean hasTotem = false;
        for (int i = 0; i < 36; i++) {
            var stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(class_1802.field_8301)) hasCrystal = true;
            if (stack.method_31574(class_1802.field_8288)) hasTotem = true;
        }

        boolean offhandIsCrystal = client.field_1724.method_6079().method_31574(class_1802.field_8301);
        boolean offhandIsTotem = client.field_1724.method_6079().method_31574(class_1802.field_8288);
        boolean attacking = client.field_1690.field_1886.method_1434();

        int delay = minDelay.get() + random.nextInt(maxDelay.get() - minDelay.get() + 1);
        if (tickCounter < delay) return;
        tickCounter = 0;

        if (mode.is("Crystal")) {
            if (attacking && hasCrystal && !offhandIsCrystal) {
                swapOffhand(client, class_1802.field_8301);
            } else if (!attacking && hasTotem && !offhandIsTotem && autoBack.enabled()) {
                swapOffhand(client, class_1802.field_8288);
            }
        } else if (mode.is("Totem")) {
            if (attacking && hasTotem && !offhandIsTotem) {
                swapOffhand(client, class_1802.field_8288);
            }
        } else if (mode.is("Auto")) {
            float health = client.field_1724.method_6032() + client.field_1724.method_6067();
            if (health < 8.0f && hasTotem && !offhandIsTotem) {
                swapOffhand(client, class_1802.field_8288);
            } else if (health >= 8.0f && hasCrystal && !offhandIsCrystal && attacking) {
                swapOffhand(client, class_1802.field_8301);
            }
        }
    }

    private void swapOffhand(class_310 client, net.minecraft.class_1792 targetItem) {
        for (int i = 0; i < 36; i++) {
            var stack = client.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(targetItem)) {
                int screenSlot = InventoryUtil.screenSlotForInventoryIndex(i);
                InventoryUtil.clickMove(client, screenSlot, InventoryUtil.OFFHAND_SLOT);
                return;
            }
        }
    }
}
