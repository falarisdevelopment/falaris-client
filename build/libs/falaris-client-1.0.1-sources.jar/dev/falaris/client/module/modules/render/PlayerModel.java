package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_742;

public final class PlayerModel extends RenderModule {
    private final IntegerSetting offsetX = setting(new IntegerSetting("Offset X", "Horizontal position.", 50, 0, 800));
    private final IntegerSetting offsetY = setting(new IntegerSetting("Offset Y", "Vertical position.", 150, 0, 600));
    private final IntegerSetting scale = setting(new IntegerSetting("Scale", "Size multiplier.", 100, 40, 300));
    private final BooleanSetting showPose = setting(new BooleanSetting("Show Pose", "Show current action text.", true));
    private final BooleanSetting showEquipment = setting(new BooleanSetting("Show Equipment", "Show armor and held items.", true));
    private final ModeSetting style = setting(new ModeSetting("Style", "Display style.", "Compact", "Compact", "Full"));

    public PlayerModel() {
        super("PlayerModel", "Shows your character model with equipment on screen.");
    }

    @Override
    protected void onHudRender(class_332 ctx, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_742 p = client.field_1724;
        int x = offsetX.get();
        int y = offsetY.get();
        int s = scale.get();

        int headY = y;

        int bodyX = x - s / 6;
        int bodyW = s / 3;
        int bodyH = (int) (s * 0.4);
        int headSize = (int) (s * 0.25);

        String pose = "";
        if (showPose.enabled()) {
            pose = getPoseText(p);
            ctx.method_51433(client.field_1772, "§7" + pose, x - 25, headY - 12, 0xFFFFFFFF, true);
        }

        int nameColor = p.method_5715() ? 0xFFFFFF55 : 0xFFFFFFFF;
        ctx.method_51433(client.field_1772, p.method_5477().getString(), x - client.field_1772.method_1727(p.method_5477().getString()) / 2, headY - headSize / 2 - 10, nameColor, true);

        int headX = x - headSize / 2;
        int skinColor = 0xFFFFD8BE;
        ctx.method_25294(headX, headY, headX + headSize, headY + headSize, skinColor);

        int eyeSize = Math.max(1, headSize / 6);
        int eyeY = headY + headSize / 3;
        int eyeSpacing = headSize / 4;
        ctx.method_25294(headX + eyeSpacing, eyeY, headX + eyeSpacing + eyeSize, eyeY + eyeSize, 0xFF000000);
        ctx.method_25294(headX + headSize - eyeSpacing - eyeSize, eyeY, headX + headSize - eyeSpacing, eyeY + eyeSize, 0xFF000000);

        int mouthY = headY + (int) (headSize * 0.65);
        int mouthW = headSize / 3;
        ctx.method_25294(headX + (headSize - mouthW) / 2, mouthY, headX + (headSize + mouthW) / 2, mouthY + 1, 0xFF000000);

        int bodyY = headY + headSize + 2;
        int armorColor = getArmorColor(p);

        ctx.method_25294(bodyX, bodyY, bodyX + bodyW, bodyY + bodyH, armorColor);

        if (!p.method_6118(class_1304.field_6174).method_7960()) {
            ctx.method_25294(bodyX - 1, bodyY - 1, bodyX + bodyW + 1, bodyY, armorColor);
        }
        if (!p.method_6118(class_1304.field_6172).method_7960()) {
            ctx.method_25294(bodyX, bodyY + bodyH - 2, bodyX + bodyW, bodyY + bodyH, getArmorColor(class_1304.field_6172, p));
        }

        int armW = Math.max(2, bodyW / 4);
        int armH = (int) (bodyH * 0.7);
        ctx.method_25294(bodyX - armW, bodyY + 2, bodyX, bodyY + 2 + armH, skinColor);
        ctx.method_25294(bodyX + bodyW, bodyY + 2, bodyX + bodyW + armW, bodyY + 2 + armH, skinColor);

        class_1799 mainHand = p.method_6047();
        if (showEquipment.enabled() && !mainHand.method_7960()) {
            String handName = mainHand.method_7964().getString();
            if (handName.length() > 10) handName = handName.substring(0, 10) + "..";
            ctx.method_51433(client.field_1772, "§f" + handName, bodyX + bodyW + armW + 2, bodyY + 4, 0xFFFFFFFF, true);
        }

        int legW = bodyW / 3;
        int legH = (int) (bodyH * 0.8);
        int legY = bodyY + bodyH;
        ctx.method_25294(bodyX + legW, legY, bodyX + legW * 2, legY + legH, getLeggingsColor(p));
        ctx.method_25294(bodyX, legY, bodyX + legW, legY + legH, getLeggingsColor(p));

        if (showEquipment.enabled()) {
            class_1799 head = p.method_6118(class_1304.field_6169);
            class_1799 chest = p.method_6118(class_1304.field_6174);
            class_1799 legs = p.method_6118(class_1304.field_6172);
            class_1799 feet = p.method_6118(class_1304.field_6166);

            String info = "";
            if (!head.method_7960()) info += "§f" + abbreviate(head.method_7964().getString(), 6) + " ";
            if (!chest.method_7960()) info += "§f" + abbreviate(chest.method_7964().getString(), 6) + " ";
            if (!legs.method_7960()) info += "§f" + abbreviate(legs.method_7964().getString(), 6) + " ";
            if (!feet.method_7960()) info += "§f" + abbreviate(feet.method_7964().getString(), 6) + " ";
            if (!info.isEmpty()) {
                ctx.method_51433(client.field_1772, info.trim(), x - 35, legY + legH + 2, 0xFFFFFFFF, true);
            }
        }
    }

    private int getArmorColor(class_742 player) {
        class_1799 chest = player.method_6118(class_1304.field_6174);
        if (chest.method_7960()) return 0xFF336699;
        return 0xFF4488AA;
    }

    private int getArmorColor(class_1304 slot, class_742 player) {
        class_1799 stack = player.method_6118(slot);
        if (stack.method_7960()) return 0xFF446688;
        return 0xFF5588AA;
    }

    private int getLeggingsColor(class_742 player) {
        class_1799 leggings = player.method_6118(class_1304.field_6172);
        if (leggings.method_7960()) return 0xFF2255AA;
        return 0xFF3366AA;
    }

    private String getPoseText(class_742 player) {
        if (player.method_6115()) {
            String item = player.method_6047().method_7964().getString();
            return "§6" + item;
        }
        if (player.method_5715()) return "§7Sneaking";
        if (player.method_5624()) return "§eSprinting";
        if (player.method_5681()) return "§bSwimming";
        if (!player.method_24828()) return "§aAir";
        if (player.field_6235 > 0) return "§cHurt";
        return "§7Idle";
    }

    private String abbreviate(String s, int max) {
        return s.length() > max ? s.substring(0, max) + ".." : s;
    }
}
