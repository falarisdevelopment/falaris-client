package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_2828;
import net.minecraft.class_310;

public final class NoFall extends MovementModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Fall damage prevention mode.", "Packet", "Packet", "Motion", "Ground"));
    private final DoubleSetting minFallDistance = setting(new DoubleSetting("Min Fall Distance", "Distance before activating.", 2.5, 0.5, 20.0));
    private final BooleanSetting resetFallDistance = setting(new BooleanSetting("Reset Fall Distance", "Reset client fall distance.", true));

    public NoFall() {
        super("NoFall", "Prevents fall damage entirely.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) return;
        if (client.field_1724.field_6017 < minFallDistance.get() || client.field_1724.method_24828()) {
            if (client.field_1724.method_24828() && resetFallDistance.enabled()) client.field_1724.field_6017 = 0.0f;
            return;
        }

        switch (mode.get()) {
            case "Packet" -> {
                if (client.field_1724.field_3944 != null) {
                    client.field_1724.field_3944.method_52787(new class_2828.class_5911(true, client.field_1724.field_5976));
                }
            }
            case "Motion" -> {
                client.field_1724.method_18800(client.field_1724.method_18798().field_1352, 0.0, client.field_1724.method_18798().field_1350);
            }
            case "Ground" -> {
                client.field_1724.method_24830(true);
                if (client.field_1724.field_3944 != null) {
                    client.field_1724.field_3944.method_52787(new class_2828.class_5911(true, client.field_1724.field_5976));
                }
            }
        }

        if (resetFallDistance.enabled()) {
            client.field_1724.field_6017 = 0.0f;
        }
    }
}
