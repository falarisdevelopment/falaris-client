package dev.falaris.client.module.modules.movement;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_2828;
import net.minecraft.class_310;

public final class NoFall extends MovementModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Fall damage prevention mode.", "Packet", "Packet", "Motion", "Ground"));
    private final DoubleSetting minFallDistance = setting(new DoubleSetting("Min Fall Distance", "Distance before activating.", 2.5, 0.5, 20.0));
    private final IntegerSetting packetDelay = setting(new IntegerSetting("Packet Delay", "Ticks between on-ground packets.", 2, 1, 20));
    private final IntegerSetting packetJitter = setting(new IntegerSetting("Packet Jitter", "Random extra ticks between packets.", 1, 0, 10));
    private final BooleanSetting resetFallDistance = setting(new BooleanSetting("Reset Fall Distance", "Reset client fall distance.", true));
    private final BooleanSetting antiGlitch = setting(new BooleanSetting("Anti Glitch", "Extra checks to prevent damage from position desync.", true));

    private int groundTicks = 0;

    public NoFall() {
        super("NoFall", "Reduces or prevents fall damage entirely.");
    }

    @Override
    protected void onMovementTick(class_310 client) {
        if (client.field_1724 == null) return;

        if (client.field_1724.field_6017 < minFallDistance.get()) {
            groundTicks = 0;
            return;
        }

        if (mode.is("Motion")) {
            client.field_1724.method_18800(client.field_1724.method_18798().field_1352,
                    Math.max(client.field_1724.method_18798().field_1351, -0.1),
                    client.field_1724.method_18798().field_1350);
        } else if (mode.is("Ground")) {
            client.field_1724.method_24830(true);
            // Send periodic ground packets to stay synced
            if (client.field_1724.field_3944 != null && groundTicks++ % 3 == 0) {
                client.field_1724.field_3944.method_52787(new class_2828.class_5911(true, client.field_1724.field_5976));
            }
        } else if (client.field_1724.field_3944 != null && ready(packetDelay.get(), packetJitter.get())) {
            client.field_1724.field_3944.method_52787(new class_2828.class_5911(true, client.field_1724.field_5976));
        }

        if (resetFallDistance.enabled()) {
            client.field_1724.field_6017 = 0.0f;
        }

        if (antiGlitch.enabled() && client.field_1724.method_24828()) {
            groundTicks = 0;
            client.field_1724.field_6017 = 0.0f;
        }
    }
}
