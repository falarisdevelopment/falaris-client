package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class AutoDisconnect extends MiscModule {
    private final ModeSetting trigger = setting(new ModeSetting("Trigger", "What triggers disconnect.", "Health", "Health", "Crystal", "Totem Pop", "Health+Crystal"));
    private final DoubleSetting healthThreshold = setting(new DoubleSetting("Health Threshold", "Disconnect when health drops below.", 6.0, 0.5, 20.0));
    private final DoubleSetting crystalRange = setting(new DoubleSetting("Crystal Range", "Disconnect when crystal within range.", 6.0, 1.0, 12.0));
    private final BooleanSetting onlyTarget = setting(new BooleanSetting("Only Target", "Only disconnect if a player is nearby.", true));
    private final BooleanSetting toggleOff = setting(new BooleanSetting("Toggle Off", "Disable module after disconnect.", true));
    private final IntegerSetting delay = setting(new IntegerSetting("Delay", "Ticks to wait before disconnecting.", 0, 0, 10));

    private int delayTicks;
    private boolean shouldDisconnect;

    public AutoDisconnect() {
        super("AutoDisconnect", "Automatically disconnects on low health, crystal nearby, or totem pop.");
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) return;

        boolean triggered = false;
        String t = trigger.get();

        if (t.contains("Health")) {
            float health = client.field_1724.method_6032() + client.field_1724.method_6067();
            if (health <= healthThreshold.get()) {
                triggered = true;
            }
        }

        if (t.contains("Crystal")) {
            for (class_1297 entity : client.field_1687.method_18112()) {
                if (entity instanceof class_1511 && entity.method_5739(client.field_1724) <= crystalRange.get()) {
                    if (!onlyTarget.enabled() || hasTargetNearby(client)) {
                        triggered = true;
                        break;
                    }
                }
            }
        }

        if (triggered) {
            delayTicks++;
            if (delayTicks >= delay.get() + 1) {
                client.field_1724.field_3944.method_48296().method_10747(class_2561.method_43470("Disconnected by AutoDisconnect"));
                if (toggleOff.enabled()) setEnabled(false);
            }
        } else {
            delayTicks = 0;
        }
    }

    private boolean hasTargetNearby(class_310 client) {
        for (class_1657 player : client.field_1687.method_18456()) {
            if (player != client.field_1724 && player.method_5739(client.field_1724) <= 12.0) return true;
        }
        return false;
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        delayTicks = 0;
    }
}
