package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import java.util.Collection;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class PotionEffects extends RenderModule {
    private final ModeSetting position = setting(new ModeSetting("Position", "Screen position.", "Top Right", "Top Left", "Top Right", "Bottom Left", "Bottom Right"));
    private final IntegerSetting offsetX = setting(new IntegerSetting("Offset X", "Horizontal offset.", 4, 0, 800));
    private final IntegerSetting offsetY = setting(new IntegerSetting("Offset Y", "Vertical offset.", 40, 0, 600));
    private final BooleanSetting showAmplifier = setting(new BooleanSetting("Show Amplifier", "Show potion level.", true));
    private final BooleanSetting showTimer = setting(new BooleanSetting("Show Timer", "Show remaining duration.", true));
    private final BooleanSetting sortByTime = setting(new BooleanSetting("Sort By Time", "Sort by remaining duration.", true));
    private final BooleanSetting icon = setting(new BooleanSetting("Icon", "Show potion effect icon.", true));

    public PotionEffects() {
        super("PotionEffects", "Displays active potion effects with duration and amplifier.");
    }

    @Override
    protected void onHudRender(class_332 ctx, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        Collection<class_1293> effects = client.field_1724.method_6026();
        if (effects.isEmpty()) return;

        var sorted = effects.stream()
            .filter(e -> e.method_5584() > 0)
            .sorted((a, b) -> sortByTime.enabled()
                ? Integer.compare(b.method_5584(), a.method_5584())
                : a.method_5579().comp_349().method_5560().getString().compareTo(b.method_5579().comp_349().method_5560().getString()))
            .toList();

        int sw = client.method_22683().method_4486();
        int sh = client.method_22683().method_4502();
        int x = offsetX.get();
        int y = offsetY.get();

        for (class_1293 effect : sorted) {
            String name = effect.method_5579().comp_349().method_5560().getString();
            StringBuilder line = new StringBuilder(name);

            if (showAmplifier.enabled() && effect.method_5578() > 0) {
                line.append(" ").append(toRoman(effect.method_5578() + 1));
            }
            if (showTimer.enabled()) {
                int total = effect.method_5584() / 20;
                int min = total / 60;
                int sec = total % 60;
                line.append(" §7").append(String.format("%d:%02d", min, sec));
            }

            int color = effect.method_5579().comp_349().method_5556();
            int textW = client.field_1772.method_1727(line.toString());
            int drawX = switch (position.get()) {
                case "Top Right" -> sw - textW - x - 4;
                case "Bottom Right" -> sw - textW - x - 4;
                case "Bottom Left" -> x;
                default -> x;
            };
            int drawY = switch (position.get()) {
                case "Bottom Left" -> sh - y - (sorted.size() - sorted.indexOf(effect)) * 12;
                case "Bottom Right" -> sh - y - (sorted.size() - sorted.indexOf(effect)) * 12;
                default -> y + sorted.indexOf(effect) * 12;
            };

            ctx.method_25294(drawX - 2, drawY - 1, drawX + textW + 4, drawY + 10, 0x60000000);
            if (icon.enabled()) {
                ctx.method_25294(drawX - 2, drawY - 1, drawX, drawY + 10, (color & 0xFFFFFF) | 0xA0000000);
            }
            ctx.method_51433(client.field_1772, line.toString(), drawX + 2, drawY + 1, color, true);
        }
    }

    private String toRoman(int n) {
        return switch (n) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            case 6 -> "VI";
            default -> String.valueOf(n);
        };
    }
}
