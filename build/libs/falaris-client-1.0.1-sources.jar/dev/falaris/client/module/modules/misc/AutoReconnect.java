package dev.falaris.client.module.modules.misc;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_419;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_642;

public final class AutoReconnect extends MiscModule {
    private final IntegerSetting delaySeconds = setting(new IntegerSetting("Delay Seconds", "Seconds to wait before reconnecting.", 5, 1, 120));
    private final IntegerSetting jitterSeconds = setting(new IntegerSetting("Jitter Seconds", "Random extra seconds before reconnecting.", 2, 0, 60));
    private final BooleanSetting multiplayerOnly = setting(new BooleanSetting("Multiplayer Only", "Only reconnect to multiplayer servers.", true));

    private class_642 lastServer;

    public AutoReconnect() {
        super("AutoReconnect", "Reconnects to the last multiplayer server after disconnect screens.");
    }

    @Override
    protected void onMiscTick(class_310 client) {
        if (client.field_1687 != null && client.method_1558() != null) {
            lastServer = client.method_1558();
        }
        if (!(client.field_1755 instanceof class_419) || lastServer == null) {
            return;
        }
        if (multiplayerOnly.enabled() && client.method_1542()) {
            return;
        }
        if (!ready(delaySeconds.get() * 20, jitterSeconds.get() * 20)) {
            return;
        }

        class_412.method_36877(new class_442(), client, class_639.method_2950(lastServer.field_3761), lastServer, false, null);
    }
}
