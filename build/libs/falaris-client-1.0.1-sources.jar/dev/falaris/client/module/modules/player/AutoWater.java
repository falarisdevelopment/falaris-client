package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class AutoWater extends PlayerModule {
    private final ModeSetting mode = setting(new ModeSetting("Mode", "Placement mode.", "Below", "Below", "Crosshair", "Below"));
    private final BooleanSetting autoSwitch = setting(new BooleanSetting("Auto Switch", "Auto-switch to water bucket.", true));
    private final BooleanSetting toggleAfterPlace = setting(new BooleanSetting("Toggle After Place", "Disable after placing.", true));

    private boolean placed;

    public AutoWater() {
        super("AutoWater", "Places water for MLG, escaping fire, or blocking lava.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null || placed) return;

        if (mode.is("Below")) {
            var pos = client.field_1724.method_24515().method_10087(2);
            if (!client.field_1687.method_8320(pos).method_26215()) return;
            if (!selectWater(client)) return;
            class_243 center = class_243.method_24953(pos);
            var result = new class_3965(center, class_2350.field_11036, pos, false);
            client.field_1761.method_2896(client.field_1724, class_1268.field_5808, result);
            client.field_1724.method_6104(class_1268.field_5808);
            placed = true;
        } else if (mode.is("Crosshair") && client.field_1765 instanceof class_3965 bhr && bhr.method_17783() == class_239.class_240.field_1332) {
            if (!client.field_1687.method_8320(bhr.method_17777().method_10093(bhr.method_17780())).method_26215()) return;
            if (!selectWater(client)) return;
            client.field_1761.method_2896(client.field_1724, class_1268.field_5808, bhr);
            client.field_1724.method_6104(class_1268.field_5808);
            placed = true;
        }

        if (placed && toggleAfterPlace.enabled()) setEnabled(false);
    }

    private boolean selectWater(class_310 client) {
        if (!autoSwitch.enabled()) return true;
        var inv = client.field_1724.method_31548();
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_8705)) {
                client.field_1724.method_31548().method_61496(i);
                return true;
            }
        }
        return false;
    }

    @Override protected void onEnable() { super.onEnable(); placed = false; }
}
