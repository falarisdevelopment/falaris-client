package dev.falaris.client.module.modules.player;

import dev.falaris.client.module.modules.combat.CombatUtil;
import dev.falaris.client.setting.DoubleSetting;
import dev.falaris.client.setting.IntegerSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class AutoPearl extends PlayerModule {
    private final DoubleSetting escapeHealth = setting(new DoubleSetting("Escape Health", "Health below which to pearl away.", 6.0, 1.0, 20.0));
    private final DoubleSetting chaseHealth = setting(new DoubleSetting("Chase Health", "Target health below which to pearl towards.", 4.0, 1.0, 20.0));
    private final DoubleSetting chaseRange = setting(new DoubleSetting("Chase Range", "Max range to chase target.", 32.0, 8.0, 64.0));
    private final IntegerSetting cooldown = setting(new IntegerSetting("Cooldown", "Ticks between pearl throws.", 40, 10, 100));

    private int tickCounter;

    public AutoPearl() {
        super("AutoPearl", "Auto-pearl away when low health, chase when target is weak.");
    }

    @Override
    protected void onEnable() {
        super.onEnable();
        tickCounter = 0;
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;
        tickCounter++;
        if (tickCounter < cooldown.get()) return;

        // Escape: pearl away when health is low
        if (client.field_1724.method_6032() <= escapeHealth.get()) {
            int pearlSlot = findPearl(client.field_1724);
            if (pearlSlot >= 0) {
                class_243 lookDir = client.field_1724.method_5828(1.0f);
                client.field_1724.method_36456(client.field_1724.method_36454() + 180.0f);
                client.field_1724.method_36457(30.0f);
                client.field_1724.method_31548().method_61496(pearlSlot);
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                tickCounter = 0;
                return;
            }
        }

        // Chase: pearl towards a weak target
        for (class_1309 target : client.field_1687.method_8390(class_1309.class,
                client.field_1724.method_5829().method_1014(chaseRange.get()),
                e -> e instanceof class_1657 && e != client.field_1724 && e.method_5805()
                        && e.method_6032() <= chaseHealth.get()
                        && client.field_1724.method_5858(e) <= chaseRange.get() * chaseRange.get())) {
            int pearlSlot = findPearl(client.field_1724);
            if (pearlSlot >= 0) {
                float[] rots = CombatUtil.rotationsTo(client.field_1724, new class_243(target.method_23317(), target.method_23318(), target.method_23321()));
                client.field_1724.method_36456(rots[0]);
                client.field_1724.method_36457((float) Math.max(rots[1], 20.0));
                client.field_1724.method_31548().method_61496(pearlSlot);
                client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                tickCounter = 0;
                return;
            }
        }
    }

    private int findPearl(class_746 player) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.method_31548().method_5438(slot).method_31574(class_1802.field_8634)) {
                return slot;
            }
        }
        return -1;
    }
}
