package dev.falaris.client.module.modules.player;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.DoubleSetting;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_408;
import net.minecraft.class_465;
import net.minecraft.class_746;

public final class InvWalk extends PlayerModule {
    private final BooleanSetting onlyInventory = setting(new BooleanSetting("Only Inventory", "Only move in inventory screens, not chat.", true));
    private final BooleanSetting allowSprint = setting(new BooleanSetting("Allow Sprint", "Allow sprinting while in inventory.", true));
    private final DoubleSetting speedMultiplier = setting(new DoubleSetting("Speed Multiplier", "Movement speed while in screens.", 0.6, 0.1, 1.0));

    public InvWalk() {
        super("InvWalk", "Walk around while your inventory or containers are open.");
    }

    @Override
    protected void onPlayerTick(class_310 client) {
        if (client.field_1724 == null) return;
        if (client.field_1755 == null) return;
        if (onlyInventory.enabled() && !(client.field_1755 instanceof class_465)) return;
        if (client.field_1755 instanceof class_408) return;

        simulateMovement(client.field_1724, client);
    }

    private void simulateMovement(class_746 player, class_310 client) {
        double forward = 0, sideways = 0;
        if (client.field_1690.field_1894.method_1434()) forward++;
        if (client.field_1690.field_1881.method_1434()) forward--;
        if (client.field_1690.field_1913.method_1434()) sideways++;
        if (client.field_1690.field_1849.method_1434()) sideways--;

        if (forward == 0 && sideways == 0) return;

        float yaw = player.method_36454();
        double speed = 0.1 * speedMultiplier.get();

        double sx = -Math.sin(Math.toRadians(yaw)) * forward + Math.cos(Math.toRadians(yaw)) * sideways;
        double sz = Math.cos(Math.toRadians(yaw)) * forward + Math.sin(Math.toRadians(yaw)) * sideways;

        class_243 vel = player.method_18798();
        player.method_18800(sx * speed, vel.field_1351, sz * speed);

        if (allowSprint.enabled() && forward > 0) {
            player.method_5728(true);
        }
    }
}
