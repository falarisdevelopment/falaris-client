package dev.falaris.client.module.modules.render;

import dev.falaris.client.setting.BooleanSetting;
import dev.falaris.client.setting.IntegerSetting;
import dev.falaris.client.setting.ModeSetting;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ArmorHud extends RenderModule {
    private final ModeSetting display = setting(new ModeSetting("Display", "Display mode.", "Horizontal", "Horizontal", "Vertical", "Compact", "Off"));
    private final BooleanSetting showDurability = setting(new BooleanSetting("Durability", "Show numeric durability.", true));
    private final BooleanSetting showHands = setting(new BooleanSetting("Show Hands", "Show main hand and offhand items.", true));
    private final BooleanSetting background = setting(new BooleanSetting("Background", "Draw dark background behind items.", true));
    private final IntegerSetting offsetX = setting(new IntegerSetting("Offset X", "Horizontal offset.", 4, 0, 800));
    private final IntegerSetting offsetY = setting(new IntegerSetting("Offset Y", "Vertical offset.", 50, 0, 600));

    public ArmorHud() {
        super("ArmorHUD", "Displays armor and hand items with durability.");
    }

    @Override
    protected void onHudRender(class_332 ctx, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || display.is("Off")) return;

        class_1304[] armorSlots = {class_1304.field_6166, class_1304.field_6172, class_1304.field_6174, class_1304.field_6169};
        boolean compact = display.is("Compact");
        int dir = display.is("Vertical") ? 0 : 1;
        int spacing = compact ? 18 : 20;
        int x = offsetX.get();
        int y = offsetY.get();

        // Offhand
        if (showHands.enabled() && !client.field_1724.method_6079().method_7960()) {
            renderItem(ctx, client.field_1724.method_6118(class_1304.field_6171), x, y, client);
            x += dir * spacing;
            y += (1 - dir) * spacing;
        }

        // Armor
        for (class_1304 slot : armorSlots) {
            class_1799 stack = client.field_1724.method_6118(slot);
            if (!stack.method_7960()) {
                renderItem(ctx, stack, x, y, client);
            } else if (!compact) {
                renderEmpty(ctx, x, y);
            }
            x += dir * spacing;
            y += (1 - dir) * spacing;
        }

        // Main hand
        if (showHands.enabled() && !client.field_1724.method_6047().method_7960()) {
            renderItem(ctx, client.field_1724.method_6047(), x, y, client);
        }
    }

    private void renderItem(class_332 ctx, class_1799 stack, int x, int y, class_310 client) {
        if (stack.method_7960()) return;

        if (background.enabled()) {
            ctx.method_25294(x - 1, y - 1, x + 17, y + 19, 0x50000000);
        }

        ctx.method_51427(stack, x, y);

        if (showDurability.enabled() && stack.method_7963()) {
            Integer dmg = stack.method_58694(net.minecraft.class_9334.field_49629);
            int max = stack.method_7936();
            if (dmg != null && max > 0) {
                int remaining = max - dmg;
                int pct = remaining * 100 / max;
                int barColor = pct > 60 ? 0xFF55AA55 : (pct > 30 ? 0xFFFFAA00 : 0xFFFF5555);
                int barBg = 0x80000000;
                int barW = 14;
                int barH = 2;
                int bx = x + 1;
                int by = y + 16;
                ctx.method_25294(bx, by, bx + barW, by + barH, barBg);
                int fillW = Math.max(1, barW * pct / 100);
                ctx.method_25294(bx, by, bx + fillW, by + barH, barColor);
            }
        }
    }

    private void renderEmpty(class_332 ctx, int x, int y) {
        if (background.enabled()) {
            ctx.method_25294(x - 1, y - 1, x + 17, y + 17, 0x30000000);
        }
    }
}
