package dev.falaris.client.keybind;

import dev.falaris.client.module.Module;
import dev.falaris.client.module.ModuleManager;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_310;
import net.minecraft.class_408;

public final class KeybindManager {
    private final ModuleManager moduleManager;
    private final Set<Integer> pressedKeys = new HashSet<>();

    public KeybindManager(ModuleManager moduleManager) {
        this.moduleManager = moduleManager;
    }

    public void tick(class_310 client) {
        if (client.method_22683() == null || client.field_1755 instanceof class_408) {
            pressedKeys.clear();
            return;
        }

        long handle = client.method_22683().method_4490();
        for (Module module : moduleManager.getModules()) {
            int keyCode = module.getKeyCode();
            if (keyCode < 0) {
                continue;
            }

            boolean pressed = GLFW.glfwGetKey(handle, keyCode) == GLFW.GLFW_PRESS;
            if (pressed && pressedKeys.add(keyCode)) {
                module.toggle();
                moduleManager.save();
            } else if (!pressed) {
                pressedKeys.remove(keyCode);
            }
        }
    }
}
