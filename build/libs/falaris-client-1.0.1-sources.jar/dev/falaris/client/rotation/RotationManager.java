package dev.falaris.client.rotation;

import java.util.Optional;
import java.util.Random;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

public final class RotationManager {
    public enum Easing { LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT }

    private Rotation target;
    private int totalTicks;
    private int remainingTicks;
    private float startYaw, startPitch;
    private float maxStep = 12.0f;
    private Easing easing = Easing.EASE_IN_OUT;
    private final Random random = new Random();

    private Rotation serverTarget;
    private int serverTicks;
    private boolean hasServerRotation;

    public void rotateTo(float yaw, float pitch, int ticks) {
        applyTarget(yaw, pitch, ticks);
    }

    public void rotateToSilent(float yaw, float pitch, int ticks) {
        applyTarget(yaw, pitch, ticks);
    }

    private void applyTarget(float yaw, float pitch, int ticks) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) { target = null; return; }
        this.startYaw = player.method_36454();
        this.startPitch = player.method_36455();
        this.target = new Rotation(yaw, class_3532.method_15363(pitch, -90.0f, 90.0f));
        this.totalTicks = Math.max(1, ticks);
        this.remainingTicks = this.totalTicks;
    }

    public void setServerRotation(float yaw, float pitch, int ticks) {
        this.serverTarget = new Rotation(yaw, class_3532.method_15363(pitch, -90.0f, 90.0f));
        this.serverTicks = Math.max(1, ticks);
        this.hasServerRotation = true;
    }

    public void clearServerRotation() {
        this.hasServerRotation = false;
        this.serverTarget = null;
        this.serverTicks = 0;
    }

    public boolean hasServerRotation() {
        return hasServerRotation;
    }

    public Optional<Rotation> getServerRotation() {
        return Optional.ofNullable(serverTarget);
    }

    public void setEasing(Easing easing) {
        this.easing = easing;
    }

    public void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null) return;

        if (target != null) {
            float t = remainingTicks / (float) totalTicks;
            float eased = ease(1.0f - t);

            float curYaw = startYaw + class_3532.method_15393(target.yaw() - startYaw) * eased;
            float curPitch = startPitch + (target.pitch() - startPitch) * eased;

            float yawDelta = class_3532.method_15393(target.yaw() - player.method_36454());
            float pitchDelta = target.pitch() - player.method_36455();
            float dist = class_3532.method_15355(yawDelta * yawDelta + pitchDelta * pitchDelta);

            float jitter = 0.1f + random.nextFloat() * 0.3f;
            float yawStep = class_3532.method_15363(yawDelta / Math.max(1, remainingTicks), -maxStep, maxStep);
            float pitchStep = class_3532.method_15363(pitchDelta / Math.max(1, remainingTicks), -maxStep, maxStep);

            if (dist < 1.0f) {
                yawStep += (random.nextFloat() - 0.5f) * jitter * 0.3f;
                pitchStep += (random.nextFloat() - 0.5f) * jitter * 0.3f;
            }

            player.method_36456(player.method_36454() + yawStep);
            player.method_36457(class_3532.method_15363(player.method_36455() + pitchStep, -90.0f, 90.0f));

            remainingTicks--;
            if (remainingTicks <= 0) target = null;
        }

        if (hasServerRotation && serverTarget != null && client.method_1562() != null) {
            if (serverTicks > 0) {
                client.method_1562().method_52787(new class_2828.class_2831(
                    serverTarget.yaw(), serverTarget.pitch(),
                    player.method_24828(), player.field_5976
                ));
                serverTicks--;
                if (serverTicks <= 0) {
                    hasServerRotation = false;
                    serverTarget = null;
                }
            }
        }
    }

    private float ease(float t) {
        return switch (easing) {
            case LINEAR -> t;
            case EASE_IN -> t * t;
            case EASE_OUT -> t * (2.0f - t);
            case EASE_IN_OUT -> t < 0.5f ? 2.0f * t * t : -1.0f + (4.0f - 2.0f * t) * t;
        };
    }

    public Optional<Rotation> getTarget() {
        return Optional.ofNullable(target);
    }

    public float getMaxStep() {
        return maxStep;
    }

    public void setMaxStep(float maxStep) {
        this.maxStep = Math.max(1.0f, maxStep);
    }
}
