package dev.falaris.client.command.commands;

import dev.falaris.client.command.Command;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class HClipCommand extends Command {
    public HClipCommand() {
        super("hclip", "Horizontal clip (teleport forward/backward).", "hc");
    }

    @Override
    public void execute(String[] args) {
        if (args.length == 0) {
            message("Usage: .hclip <blocks>");
            return;
        }
        try {
            double blocks = Double.parseDouble(args[0]);
            var c = class_310.method_1551();
            if (c.field_1724 == null) return;
            double yaw = Math.toRadians(c.field_1724.method_36454());
            double x = -Math.sin(yaw) * blocks;
            double z = Math.cos(yaw) * blocks;
            c.field_1724.method_5814(c.field_1724.method_23317() + x, c.field_1724.method_23318(), c.field_1724.method_23321() + z);
            message("Clipped forward " + blocks + " blocks.");
        } catch (NumberFormatException e) {
            message("Invalid number: " + args[0]);
        }
    }

    private void message(String msg) {
        var c = class_310.method_1551();
        if (c.field_1724 != null) c.field_1724.method_7353(class_2561.method_43470("§7[§bFalaris§7] §f" + msg), false);
    }
}
