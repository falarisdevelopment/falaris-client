package dev.falaris.client.command.commands;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.command.Command;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class PresetCommand extends Command {
    public PresetCommand() {
        super("preset", "List, load, or save presets.", "p");
    }

    @Override
    public void execute(String[] args) {
        var pm = FalarisClient.getInstance().getPresetsManager();
        var cm = FalarisClient.getInstance().getModuleManager();
        if (args.length == 0) {
            message("Presets: " + String.join(", ", pm.getPresetNames()));
            return;
        }
        if (args[0].equalsIgnoreCase("save") && args.length >= 2) {
            pm.savePreset(args[1], cm);
            message("Saved preset: " + args[1]);
        } else if (args[0].equalsIgnoreCase("load") && args.length >= 2) {
            if (!pm.hasPreset(args[1])) {
                message("Preset \"" + args[1] + "\" not found.");
                return;
            }
            pm.loadPreset(args[1], cm);
            message("Loaded preset: " + args[1]);
        } else if (pm.hasPreset(args[0])) {
            pm.loadPreset(args[0], cm);
            message("Loaded preset: " + args[0]);
        } else {
            message("Usage: .preset <name>  |  .preset (save|load) <name>");
        }
    }

    private void message(String msg) {
        var c = class_310.method_1551();
        if (c.field_1724 != null) c.field_1724.method_7353(class_2561.method_43470("§7[§bFalaris§7] §f" + msg), false);
    }
}
