package dev.falaris.client.command.commands;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.command.Command;
import dev.falaris.client.command.CommandManager;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class HelpCommand extends Command {
    public HelpCommand() {
        super("help", "List available commands.", "h", "?");
    }

    @Override
    public void execute(String[] args) {
        var sb = new StringBuilder("§7[§bCommands§7]§f ");
        for (Command cmd : CommandManager.getInstance().getCommands()) {
            sb.append("§b.").append(cmd.getName()).append("§7, ");
        }
        if (sb.length() > 3) sb.setLength(sb.length() - 2);
        message(sb.toString());
    }

    private void message(String msg) {
        var c = class_310.method_1551();
        if (c.field_1724 != null) c.field_1724.method_7353(class_2561.method_43470(msg), false);
    }
}
