package dev.falaris.client.command.commands;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.command.Command;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class FriendCommand extends Command {
    public FriendCommand() {
        super("friend", "Add/remove/list friends.", "f");
    }

    @Override
    public void execute(String[] args) {
        var fm = FalarisClient.getInstance().getFriendsManager();
        if (args.length == 0) {
            message("Friends: " + String.join(", ", fm.getAll()));
            return;
        }
        String name = args[0];
        if (fm.isFriend(name)) {
            fm.remove(name);
            message("Removed " + name + " from friends.");
        } else {
            fm.add(name);
            message("Added " + name + " to friends.");
        }
    }

    private void message(String msg) {
        var c = class_310.method_1551();
        if (c.field_1724 != null) c.field_1724.method_7353(class_2561.method_43470("§7[§bFalaris§7] §f" + msg), false);
    }
}
