package dev.falaris.client.command.commands;

import dev.falaris.client.FalarisClient;
import dev.falaris.client.command.Command;
import dev.falaris.client.module.Module;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class PanicCommand extends Command {
    public PanicCommand() {
        super("panic", "Disable all modules.", "p");
    }

    @Override
    public void execute(String[] args) {
        int count = 0;
        for (Module m : FalarisClient.getInstance().getModuleManager().getModules()) {
            if (m.isEnabled()) { m.setEnabled(false); count++; }
        }
        message("Disabled " + count + " module(s).");
    }

    private void message(String msg) {
        var c = class_310.method_1551();
        if (c.field_1724 != null) c.field_1724.method_7353(class_2561.method_43470("§7[§bFalaris§7] §f" + msg), false);
    }
}
