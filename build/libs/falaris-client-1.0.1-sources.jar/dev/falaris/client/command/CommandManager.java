package dev.falaris.client.command;

import dev.falaris.client.command.commands.*;
import java.util.*;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class CommandManager {
    private static CommandManager instance;
    private final List<Command> commands = new ArrayList<>();

    public CommandManager() {
        instance = this;
    }

    public void registerAll() {
        register(new ToggleCommand());
        register(new BindCommand());
        register(new FriendCommand());
        register(new PanicCommand());
        register(new VClipCommand());
        register(new HClipCommand());
        register(new HelpCommand());
        register(new PresetCommand());
    }

    public void register(Command cmd) {
        commands.add(cmd);
    }

    public boolean execute(String message) {
        if (!message.startsWith(".")) return false;
        String[] parts = message.substring(1).split("\\s+");
        if (parts.length == 0) return false;

        String name = parts[0].toLowerCase();
        String[] args = Arrays.copyOfRange(parts, 1, parts.length);

        for (Command cmd : commands) {
            if (cmd.getName().equals(name) || cmd.getAliases().contains(name)) {
                try {
                    cmd.execute(args);
                } catch (Exception e) {
                    var c = class_310.method_1551();
                    if (c.field_1724 != null) {
                        c.field_1724.method_7353(class_2561.method_43470("§cError executing command: " + e.getMessage()), false);
                    }
                }
                return true;
            }
        }
        return false;
    }

    public List<Command> getCommands() { return List.copyOf(commands); }
    public static CommandManager getInstance() { return instance; }
}
