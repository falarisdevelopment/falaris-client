package dev.falaris.client.util;

import java.util.*;
import net.minecraft.class_1297;
import net.minecraft.class_243;

public final class PositionExtrapolation {
    private static final Map<Integer, List<Snapshot>> history = new HashMap<>();
    private static final int TRAJECTORY_TICKS = 5;

    public static void record(class_1297 entity) {
        long now = System.currentTimeMillis();
        history.computeIfAbsent(entity.method_5628(), k -> new ArrayList<>())
               .add(new Snapshot(now, new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321()), entity.method_18798()));
        long cutoff = now - 2000;
        history.values().forEach(l -> l.removeIf(s -> s.time < cutoff));
    }

    public static class_243 predict(class_1297 entity, int ticksAhead) {
        class_243 pos = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
        class_243 vel = entity.method_18798();
        for (int i = 0; i < ticksAhead; i++) {
            pos = pos.method_1031(vel.field_1352, vel.field_1351, vel.field_1350);
            vel = vel.method_1031(0, -0.08, 0).method_1021(0.98);
        }
        return pos;
    }

    public static boolean willLeaveRange(class_1297 self, class_1297 target, double range, int ticksAhead) {
        class_243 selfFuture = predict(self, ticksAhead);
        class_243 targetFuture = predict(target, ticksAhead);
        return selfFuture.method_1025(targetFuture) > range * range;
    }

    public static void clear() {
        history.clear();
    }

    private record Snapshot(long time, class_243 pos, class_243 vel) {}
}
